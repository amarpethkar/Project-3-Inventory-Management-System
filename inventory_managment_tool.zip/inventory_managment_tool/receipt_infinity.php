<?php
require('fpdf/fpdf.php');

 
class PDF extends FPDF
{ 

// Page header
function Header(){
	global $path_logo,$receiptIdDB,$nameDB,$reciptDateDB,$contactNoDB,$grandTotalDB,$paidAmountDB,$balanceAmountDB,$receiptProduct_info,$i,$loc,$tesho,$productCodeDB,$productDiscrDB,$productQuantityDB,$productUnitPriceDB,$productDiscrDB2,$receipt_idR,$x,$y;
	// Logo
	//$this->Image($path_logo,150,'1','40',40);
	
	//Line 
	$this->Ln(40);
	$this->Cell(80);
    $this->Rect(5,5,125,160,''); // main rectangle box i.e. outer box
	// Title
	//$this->SetFont('Helvetica','B',23);
	//title color
$this->SetFont('Arial','',11);
	$this->Text(7,10,"Ruchi Seth");
	$this->SetFont('Arial','',7);
	$this->Text(7,14,"9821932127");
	$this->Text(7,19,"Shop No. 1 & 2, Shilpali,"); 
	$this->Text(7,23,"Near Prashant Corner,"); 
	$this->Text(7,27,"Panchpakhadi, Thane (W),");
	$this->Text(7,31,"400 602.");
	
	
	// Logo
		$this->Image($path_logo,38,'4','',18);
		
		$this->SetFont('Arial','B',8);
		$this->Text(40,25,"Dress Materials, Designing & Ethnic Sarees"); 
		$this->Line(40,26,99,26);// Underline for above text
		
	// Date receipt and contact no
		
		$this->Line(100,5,100,32);// Verticle 1st section line for right box
		
		$this->SetFont('Arial','',8);
		$this->Text(101,11,"Bill No.:"); 
		$this->Text(112,11,$receiptIdDB); 
		$this->Text(111,12,".......................");// Bill no. wali line
		
		$this->Text(101,17,"Date:"); 
		$this->Text(111,17,$reciptDateDB); 
		$this->Text(111,18,".......................");// Date wali line
	
		$this->Text(101,23,"Phone:"); 
		$this->Text(111,23,$contactNoDB); 
		$this->Text(111,24,".......................");// Contact no. wali line
		
		
		$this->Line(5,32,130,32);// 1st section bottom line
		
		
	// name 
	    $this->SetFont('Arial','',8);
		$this->Text(10,38,"Name:"); 
		$this->Text(22,38,$nameDB); 
		$this->Text(20,40,".............................................................................................................................");	 // blank wali line for name 
		
	

// product list 
   $this->Rect(5,45,125,85,''); // inner box 
   
   $this->SetFont('Arial','',9);
   
    $this->Text(6,51,"Sr. No."); // serial no 
	$this->Text(35,51,"Particulars"); // Particulars
	$this->Text(72,51,"Qty."); //Quantity
	$this->Text(87,51,"Rate"); //Rate
	$this->Text(107,51,"Amount"); //Amount
	  

  for($q=1,$p=0,$y=65;$p<count($receiptProduct_info);$p++,$q++,$y=$y+5)
  {
   
 $this->Text(9,$y,$q);// sr.no
   
 $this->Text(32,$y,$receiptProduct_info[$p][3]);// perticulars
	
 $this->Text(74,$y,$receiptProduct_info[$p][4]);// quantity
   
 $this->Text(87,$y,$receiptProduct_info[$p][5]); //unit price
	
$this->Text(107,$y,$receiptProduct_info[$p][7]); //amount 
  
  
   	}	
		
   $this->Text(87,135,"Total Amt.:");
   $this->Text(106,135,$grandTotalDB);
   $this->Text(104,136,"...................Rs");// total amount wali line
   
   $this->Text(87,142,"Paid Amt.:");
   $this->Text(106,142,$paidAmountDB);
   $this->Text(104,143,"...................Rs");// paid amount wali line
   $this->Text(87,150,"Bal. Amt.:");
   $this->Text(106,150,$balanceAmountDB);
   $this->Text(104,151,"...................Rs");// balance amount wali line
   $this->Text(10,138,"Note:");
   $this->Line(5,155,130,155);// line above authorised signature
   $this->Text(68,162,'Authorised Signatory:');
   
   
   $this->Line(5,55,130,55); // 2nd section bottom line
   $this->Line(17,45,17,130); // sr no wali line verticle 
   $this->Line(70,45,70,130); // perticulars wali line   verticle 
   $this->Line(80,45,80,130); // Quantity wali line  verticle 
   $this->Line(100,45,100,130); // rate wali line  verticle 

	}//
	
	

 }
 

$pdf = new PDF();

$path_logo ='images/logo-02.png';//logo
 
			include_once('classes/query_class.php');
			$qc = new queryClass();			
		$receipt_idR=$_REQUEST['receipt_id'];
		
  if($receipt_idR!=''){
  $receipt_info=$qc->getCustReceiptInfo($receipt_idR);
  
  
  $receiptIdDB=$receipt_info[0][0];
  $nameDB=$receipt_info[0][1];
  $reciptDateDB=$receipt_info[0][2];
  $contactNoDB=$receipt_info[0][3];
  $grandTotalDB=$receipt_info[0][4];
  $paidAmountDB=$receipt_info[0][5];
  $balanceAmountDB=$receipt_info[0][6]; 
  
  $receiptProduct_info=$qc->viewCustReceiptandProdInfo($receipt_idR);
	

}
$pdf->SetLeftMargin(5);
$pdf->AddPage();
//$pdf->FancyTable($header);
$pdf->Output();
?>