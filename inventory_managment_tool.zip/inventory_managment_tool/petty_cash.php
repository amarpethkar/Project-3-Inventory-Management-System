<?php
 include_once('auth.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Add Expenses</title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet" />
<link href="css/style.css" type="text/css" rel="stylesheet" />
<link href="css/menu.css" type="text/css" rel="stylesheet" />
  <link href="css/font-awesome.css" type="text/css" rel="stylesheet" />
<script src="js/menu_script.js" type="text/javascript"></script>


<!--calender code-->
<link rel="stylesheet" href="css/jquery-ui.css">
<script src="js/jquery-1.10.2.js"></script>
<script src="js/jquery-ui.js"></script>
<!--calender code end -->
<script type="text/javascript">
$(function() {
$( "#datepicker" ).datepicker();
  $( "#datepicker" ).datepicker("setDate", new Date());
  
   $( "#datepicker_start_date" ).datepicker();
  $( "#datepicker_start_date" ).datepicker("setDate", new Date());
  
   $( "#datepicker_end_date" ).datepicker();
  $( "#datepicker_end_date" ).datepicker("setDate", new Date());
});
</script>

</head>
<body>
<!-- wrapper start-->
<div class="esya_wrapper">
  <!-- main container-->
  <div class="container">
    <!--herader container -->
 <?php include_once('header.php'); ?>
    <!--header container end-->
    <!--menu container-->
    <div class="menu_container">
      <?php include_once('menu.php'); ?>
    </div>
    <!--menu container end-->
    <!--middle container -->
    <div class="middle_container">
      <div class="middle_header"><span>Add Supplier</span></div>
      <div class="add_dealer">
        <form name="add_supplier" method="post" action="query.php">
          <table align="center" width="98%" class="add_dealer_table">
          <?php
include_once("message.php");
$exp_idDB = $qc->clean($_REQUEST['exp_id']);
if($exp_idDB!=''){
$getExpensesInfo = $qc->getExpensesInfo($exp_idDB);
}

?>
            <tr>
              <td class="add_inputBox"><input type="text" id="datepicker" name="exp_date" value="<?php echo $getExpensesInfo[0][1]; ?>" placeholder="date" required/></td>
               <td class="add_inputBox"><input type="text" name="exp_particulars" value="<?php echo $getExpensesInfo[0][2]; ?>" placeholder="Particulars" required/></td>
              <td class="add_inputBox"><input type="text" name="exp_amount" value="<?php echo $getExpensesInfo[0][3]; ?>" placeholder="Amount"/></td>
        
                                   
                        <td colspan="3">
         
              <input type="hidden" name="function" value="add_expenses" />
              <?php if($exp_idDB!=''){?>
              <input type="submit" class="input_Btn recBtn" name="" value="Save"  />
              <?php }else {?>
               <input type="submit" class="input_Btn recBtn" name="" style="border: medium none;" value="Add"  />
               <?php } ?>
              <input type="hidden" name="exp_idDB" value="<?php echo $exp_idDB; ?>" />
              </td>
         </tr> 
          </table> 
        </form>
      </div>
      <!-- Add Dealer end-->
      <br />
       <div class="middle_header"><div class="col-md-7"><span style="position: relative;">View Expenses</span></div>
         <form name="stock_search" method="post" action="petty_cash.php">
         <div class="col-md-5"><span style="position: relative;  top: -7px;">Search by:&nbsp;
           <input type="text" id="datepicker_start_date" name="search1" style="width: 150px ! important; color: rgb(89, 86, 84) ! important; font-size: 12px;" placeholder="Choose Start Date" /> 
            <input type="text" id="datepicker_end_date" name="search2" style="width: 150px ! important; color: rgb(89, 86, 84) ! important; font-size: 12px;" placeholder="Choose End Date" /> 
           <input type="submit" name="" value="" class="myBtn btn" />
        <input type="hidden" name="function" value="exp_filter_dates" />
           
           </span></div>
         </form>
           </div>
       <div class="view_dealer">
          <table align="center" width="100%" class="ov_table">
           <tr style="background: rgb(241, 241, 241) none repeat scroll 0% 0%;">
          <td width="10px"></td>
             <td><span>Sr. No.</span></td>
             <td><span>Date</span></td>
             <td><span>Particulars</span></td>
             <td><span>Amount</span></td>            
             <td></td>
             <td></td>
            </tr>
             <?php

		$search1 =  $qc->clean($_REQUEST['search1']);
		$search2 =  $qc->clean($_REQUEST['search2']);
		if($search1!='' && $search2!=''){
		
	
	
	$datepicker_start_dateFrormated = explode("/", $search1);
    $exp_start_date = $datepicker_start_dateFrormated[2]."-".$datepicker_start_dateFrormated[1]."-".$datepicker_start_dateFrormated[0];
	
	
	
	$datepicker_end_dateFrormated = explode("/",$search2);
    $exp_end_date = $datepicker_end_dateFrormated[2]."-".$datepicker_end_dateFrormated[1]."-".$datepicker_end_dateFrormated[0];
	
	
	$expensesInfo = $qc->getExpSearchDateInfo($exp_start_date,$exp_end_date);

		
		}else{
		
		
		$expensesInfo = $qc->getExpensesInfo('');
}
		for($i=0,$j=1;$i<count($expensesInfo);$i++,$j++){


if($search1!='' && $search2!=''){

$total = $total+$expensesInfo[$i][3];
}
		?>
            <tr class="recordBox">
            <td></td>
             <td><?php echo $j; ?></td>
             <td><?php echo $expensesInfo[$i][1];?></td>
             <td><?php echo $expensesInfo[$i][2];?></td>
             <td><?php echo $expensesInfo[$i][3];?></td>

            <td><a href="petty_cash.php?exp_id=<?php echo $expensesInfo[$i][0];?>"><img src="images/edit.png" /></a></td>
          <td><a href="query.php?function=delete_petty_cash&exp_id=<?php echo $expensesInfo[$i][0];?>"onclick="return confirm('Are you sure you want to Delete?')"><img src="images/delete.png" /></a></td>
           <td><span></span></td>
            </tr>
            <?php }if($search1!='' && $search2!=''){?>
            
 <tr class="recordBox">
            <td></td>
             <td></td>
             <td></td>
             <td>Total :-</td>
             <td><?php echo $total;?></td>
              <td></td>
             <td></td>
             </tr>
             <?php }?>
          </table>
       </div>
       
    </div>
    <!--middle container end-->
  </div>
  <!--main container end-->
</div>
</div>
<!--wrapper end-->
</body>
</html>
