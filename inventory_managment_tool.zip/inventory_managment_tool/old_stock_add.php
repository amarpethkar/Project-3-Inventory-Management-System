<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Add Stock</title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet" />
<link href="css/style.css" type="text/css" rel="stylesheet" />
<link href="css/menu.css" type="text/css" rel="stylesheet" />
<!--<link href="js/tool.css" type="text/css" rel="stylesheet" />-->
<!--calender code-->
<link rel="stylesheet" href="css/jquery-ui.css">
<script src="js/jquery-1.10.2.js"></script>
<script src="js/jquery-ui.js"></script>
<!--calender code end -->
<script type="text/javascript">
var rowCount = 0;
function addMoreRows(frm) {
rowCount ++;
var rowCount1 = $("#count").val();
var recRow = '<tr id="rowCount'+rowCount+'"><td><input type="text" name="stockDealerCode'+rowCount+'" style="width: 170px !important;"  placeholder="Dealer Code" /></td><td><input type="text" style="width: 170px !important;" name="stockInfinityCode'+rowCount+'" id="stockInfinityCode'+rowCount+'" OnKeyUp="stockInfinityCode('+rowCount+');"  placeholder="Infinity Code" /></td><td><input type="text" style="width: 270px !important;" name="stockDescriptions'+rowCount+'" placeholder="Descriptions" /></td><td><input type="text" name="stockQuantity'+rowCount+'" style="width: 80px !important;" placeholder="Quantity" /></td><td><input type="text" name="stockUnitPriceDealer'+rowCount+'" style="width: 150px !important;"  placeholder="CP Unit Amount"  onkeyUp="calculationAmount('+rowCount+');" id="useramount'+rowCount+'"/></td><td><input type="text" name="stockUnitPrice'+rowCount+'" id="stockUnitPrice'+rowCount+'" style="width: 145px !important;"  placeholder="SP Unit Amount" /></td><!--<td><input type="text" name="stockAmount'+rowCount+'" style="width: 124px !important;" placeholder="Total Amount" /></td>--><td> <a href="javascript:void(0);" onclick="removeRow('+rowCount+');"><input type="button" name="" value=" X " style="width: 40px ! important;" class="myBtn"> </a><td></tr><tr><td style="height:10px;"><input type="hidden" name="flag'+rowCount+'" id="flag'+rowCount+'"></td></tr>';
jQuery('#addedRows').append(recRow);
rowCount1=rowCount;
$("#count").val(rowCount1+1);

}

var toatalVal =0;
var userval = [];

function calculationAmount(key){
var key = key;
//alert(key);
for(var i=0;i<=key;i++){
var values = Number($('#useramount'+i).val());
if(values!=='' || values!=="undefined" || values!=="NaN"){
userval[i] = values;
}
}

userOtherFun(userval);
}
//
function userOtherFun(userval){
var toatalVal=0;
for(var i=0;i<userval.length;i++){
if(userval[i]){
toatalVal = (toatalVal+userval[i]);
}

}

$("#sup_grand_total").val(toatalVal);
}

function removeRow(removeNum) {


jQuery('#rowCount'+removeNum).remove();
var use = $("#count").val();
var rowCount2 = use-1;
$("#count").val(rowCount2);


var toatalVal1=0;
//alert(rowCount);

for(var i=0;i<=rowCount;i++){
var values = Number($('#useramount'+i).val());
userval[i] = values;
if(userval[i]){
toatalVal1 = (toatalVal1+userval[i]);
}
}
//console.log(userval);

$("#sup_grand_total").val(toatalVal1);


}



$(function() {
$( "#datepicker" ).datepicker();
  $( "#datepicker" ).datepicker("setDate", new Date());
  
   $( "#datepicker_filter" ).datepicker();
  $( "#datepicker_filter" ).datepicker("setDate", new Date());
});

function clickhere(){
//alert('jfdg');
	$("#add_StockDetails").addClass("i-hide");
$("#add_newId").html('<div style="width: 40px ! important; border: medium none;line-height: 30px;border-radius: 5px; cursor: pointer;float: right;margin-top: -5px;" onclick="clickhere1();" class="recBtn">+</div>');
    
}

function clickhere1(){
		$("#add_StockDetails").removeClass("i-hide");
		$("#add_newId").html('<div style="width: 40px ! important; border: medium none;line-height: 30px;border-radius: 5px; cursor: pointer; float: right;margin-top: -5px;" onclick="clickhere();" class="recBtn">X</div>');
      
}

function checkBalanceAmountStack(){
var totalBal =0;
var sup_paid_amt =0;
var sup_grand_total =0;
 sup_paid_amt = Number($('#sup_paid_amt').val());
 sup_grand_total = Number($('#sup_grand_total').val());
totalBal = (sup_grand_total - sup_paid_amt);
$('#sup_bal_amt').val(totalBal);

}

$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});

function paymodecheque(val){
if(val==3){
$('#cheque_no').show();
$('#cheque_no1').show();
}else{

  $('#cheque_no').hide();
  $('#cheque_no1').hide();

}
}

function stockInfinityCode(key){

var infitycode =$('#stockInfinityCode'+key).val();
//alert(infitycode);
$.ajax({
     type: 'POST',
     url: 'query.php',
     data: 'function=oldStockInfo&infitycode='+infitycode,
     cache: false,
     success: function(result) {
    var response = result;
  
        var json_obj = $.parseJSON(response);//parse JSON  
    
   if(json_obj!=''){
      for (var i in json_obj){  

        $('#stockUnitPrice'+key).val(json_obj[i].old_sp_amount);     
        $('#flag'+key).val(1); 

      }//for
    }else{
		$('#stockUnitPrice'+key).val(0); 
       $('#flag'+key).val(2); 

    }
  }
   });


}
</script>
<script src="js/menu_script.js" type="text/javascript"></script>
</head>
<body>
<!-- wrapper start-->
<div class="esya_wrapper">
<!-- main container-->
<div class="container">
<!--herader container -->
<?php include_once('header.php'); ?>
<!--header container end-->
<!--menu container-->
<div class="menu_container">
  <?php include_once('menu.php'); 
  include_once("classes/query_class.php");
  $qc = new queryClass();
  $supplierInfo = $qc->getSupplierInfo('');
  $stock_id = $qc->clean($_REQUEST['stock_id']);
  if($stock_id!=''){
  $stockInfo_edit = $qc->getStockInfo($stock_id,'','');
  }
   
  ?>
</div>
<!--menu container end-->
<!--middle container -->
<div class="middle_container">
  <div class="middle_header"><div class="col-md-11">Add Old Stock</div><div class="col-md-1" id="add_newId">
 <div style="width: 40px ! important; border: medium none;line-height: 30px; cursor: pointer;border-radius: 5px;float: right;margin-top: -5px;" onclick="clickhere1();" class="recBtn">+</div></div></div>
 
  <!--chosee dealer start-->
  <div class="i-hide" id="add_StockDetails">
    <form name="add_stock" method="post" action="query.php">
      <div class="middle_stockDealer">
        <table class="chooseDealer" width="100%" align="center">
          <tr>
          <td width="5%"></td>
            <td width="15%">Choose Dealer:</td>
            <td width="15%"><select name="stockChooseDealer" required style="width: 176px !important;">
                <?php 
		if($stock_id!='')
		{	
		$supplierInfo1 = $qc->getSupplierInfo($stockInfo_edit[0][1]);		
		?>
                <option value="<?php echo $supplierInfo1[0][0];?>" selected="selected"><?php echo $supplierInfo1[0][1];?></option>
                <?php }else{ ?>
                <option value="" selected="selected">--Select--</option>
                <?php
		}
		for($i=0;$i<count( $supplierInfo);$i++){
		 ?>
                <option value="<?php echo $supplierInfo[$i][0];?>"><?php echo $supplierInfo[$i][1];?></option>
                <?php }?>
              </select></td>
            <td width="15%">Date:</td>
            <td width="15%"><input type="text" name="stockAddDate" id="datepicker" style="width: 176px !important;" value="<?php echo $stockInfo_edit[0][2]; ?>" /></td>
            <td width="15%">Invoice No.:</td>
            <td width="15%"><input type="text" name="stockInvoiceNo" style="width: 176px !important;" value="<?php echo $stockInfo_edit[0][3]; ?>"/></td>
            <td width="5%"></td>
          </tr>
        </table>
      </div>
      <!--Chosee Dealer End -->
      
      <!--Add Stock start-->
      <div class="stockAdd_div">
      <table width="100%" align="center" class="stockAdd_table">
       
        <td width="5%"></td>
          <td colspan="7"><b>Add Product</b></td>
          <td width="5%"></td>
        </tr>
        <tr>
          <td colspan="7">&nbsp;</td>
        </tr>
 
        <tr>
          <td style="height:10px;"></td>
        </tr>
        <tr>
        <td width="5%"></td>
          <td><input type="text" name="stockDealerCode0" placeholder="Dealer Code" style="width: 170px !important;" value="<?php echo $stockInfo_edit[0][4]; ?>" required/></td>
          <td>
          <input type="text" name="stockInfinityCode0" id="stockInfinityCode0" placeholder="Infinity Code" style="width: 170px !important;" value="<?php echo $stockInfo_edit[0][5]; ?>" OnKeyUp="stockInfinityCode(0);" required/></td>
          <td><input type="text" name="stockDescriptions0" placeholder="Description" style="width: 270px !important;" value="<?php echo $stockInfo_edit[0][6]; ?>" required/></td>
          <td><input type="text" name="stockQuantity0" placeholder="Quantity" style="width: 80px !important;" value="<?php echo $stockInfo_edit[0][7]; ?>" required/></td>
          <td><input type="text" name="stockUnitPriceDealer0" id="useramount0" placeholder="CP Unit Amount" style="width: 150px !important;" value="<?php echo $stockInfo_edit[0][11]; ?>" onkeyUp="calculationAmount(0);" required/></td>
          <td><input type="text" name="stockUnitPrice0" id="stockUnitPrice0" placeholder="SP Unit Amount" style="width: 145px !important;" value="<?php echo $stockInfo_edit[0][8]; ?>" required/></td>
            <input type="hidden" name="flag0" id="flag0">
               
          <td><?php 
			if($stock_id=='')
			{?>
                <a href="#" onclick="addMoreRows(this.form);">
                <input type="button" name="" value=" + " style="width: 40px ! important;" class="myBtn"/>
                </a>
                <?php }?>
          </td>
          <td width="5%"></td>
        </tr>
        <tr>
          <td style="height:10px;"></td>
        </tr>
        <tr>
        <td width="5%"></td>
          <td colspan="7"><table id="addedRows" width="100%" align="center" class="stockAdd_table">
            </table></td>
            <td width="5%"></td>
        </tr>
        <tr>
          <td colspan="4"></td>
          <td>CP Total Amount:</td>
          <td><input type="text" name="sup_grand_total" id="sup_grand_total"/></td>
        </tr>
        <tr>
          <td style="height:10px;"></td>
        </tr>  
        
        <tr>
          <td colspan="4"></td>
          <td>Paid Amount:</td>
          <td><input type="text" name="sup_paid_amt" id="sup_paid_amt" onKeyUp="checkBalanceAmountStack();"  required/></td>
        </tr>
        <tr>
          <td style="height:10px;"></td>
        </tr>
        <tr>
          <td colspan="4"></td>
          <td>Balance Amount:</td>
          <td><input type="text" name="sup_bal_amt" id="sup_bal_amt" required/></td>
        </tr>
         <tr height="15px;">
            <td></td>
          </tr>
      <tr>
        <td colspan="4"></td>
        <td>Payment Mode:</td>
        <td><ul class="input_ul" style="width: auto !important;">
            <li>
              <input name="pay_mode" value="cc" onclick="paymodecheque(1);" type="radio">
              CC</li>
            <li>
              <input name="pay_mode" value="cash" onclick="paymodecheque(2);" type="radio">
              Cash</li>
            <li>
              <input name="pay_mode" value="cheque" onclick="paymodecheque(3);" type="radio">
              Cheque</li>
          </ul></td>
      </tr>
      <tr height="15px;">
        <td></td>
      </tr>
      <tr id="cheque_no" style="display: none;">
      <td colspan="4"></td>
       <td>Cheque No:</td>
            <td><input name="cheque_no" value=""  type="text"></td>
          </tr>
      <tr><td height="15px"></td></tr>
        <tr>
        <td colspan="5">
        <td>
        <input type="submit" value="Submit" class="myBtn" style="width: 142px !important;" style="margin-bottom: 20px;"/>
            <input type="hidden" name="function" value="add_oldItemstock" />
         <input type="hidden" id="count" name="count" value="1" />
            <input type="hidden" id="count" name="stock_id" value="<?php echo $stock_id; ?>" />
            </td>
            <td colspan="2"></td>
            </td>

      </table>
    </form>
  </div>
</div>
<!--view stock start -->
<div class="view_stock">
  <div class="middle_header" style="height: 60px ! important; top: 15px; position: relative;">
    <div style="line-height: 30px;position: relative;
    left: 325px;" class="col-md-4"><span>View Stock</span></div>
	<div class="col-md-8">
    <form name="stock_search" method="post" action="stock_add.php">
      <?php  include_once("classes/query_class.php");
  $qc = new queryClass();
  $supplierInfo = $qc->getSupplierInfo('');
  ?>
      <div style="float: right; ">Select Dealer:&nbsp;
        <select name="choose_dealer" style="width: 142px ! important; color: rgb(51, 51, 51); font-size: 14px;">
          <option value="" selected="selected">--Select Dealer--</option>
          <?php
		for($i=0;$i<count( $supplierInfo);$i++){
		 ?>
          <option value="<?php echo $supplierInfo[$i][0];?>"><?php echo $supplierInfo[$i][1];?></option>
          <?php }?>
        </select>
        <input type="submit" name="" value="" class="myBtn btn" />
        <input type="hidden" name="function" value="add_stock" />
      </div>
    </form>
	</div>
  </div>
</div>
<!--dynamic content start-->

<div style="height: 425px; overflow: scroll; position: relative; top: 20px;">
  <table class="middle_dealerView_table">
    <?php
	 $stock_date='';
	 $choose_dealer = $qc->clean($_REQUEST['choose_dealer']);
	 if($choose_dealer!=''){
	 $date_filter1 = $qc->clean($_REQUEST['date_filter']);
	 if($date_filter1!=''){
	  $stock_date = explode("/", $date_filter1);
 $date_filter = $stock_date[2]."-".$stock_date[1]."-".$stock_date[0];
}
	  ?>
    <tr>
      <td colspan="11"><!--<b>Dealer name: Harsh Fabrics</b>-->
        <form name="date_filter" method="post" action="stock_add.php">
          <span style="margin-left: 699px;"><b>Select Date:</b>&nbsp;
          <input type="text" name="date_filter" style="width: 150px ! important;" id="datepicker_filter" />
          <input type="hidden" name="choose_dealer" id="choose_dealer" value="<?php echo $choose_dealer;?>" />
          <input type="submit" value="" class="myBtn btn1" />
          </span>
        </form></td>
    </tr>
    <?php } ?>
    <tr style="background: rgb(241, 241, 241) none repeat scroll 0% 0%;">
      <td><span style="font-weight: bold;">Sr. No.</span></td>
        <td><span style="font-weight: bold;">D-Name</span></td>
      <td><span style="font-weight: bold;">Invoice No.</span></td>
      <td><span style="font-weight: bold;">Date</span></td>
      <td><span style="font-weight: bold;">D-code</span></td>
      <td><span style="font-weight: bold;">I-code</span></td>
      <td><span style="font-weight: bold;">Description</span></td>
      <td><span style="font-weight: bold;">Quntity</span></td>
      <td><span style="font-weight: bold;">CP Amount</span></td>
      <td><span style="font-weight: bold;">SP Amount</span></td>

    <td></td>
    <td></td>
      <!--  <td></td>-->
    </tr>
    <!--   dealer loop here-->
    <?php
			
	$stockInfo = $qc->getStockInfo('',$choose_dealer,$date_filter);
for($i=0,$j=1;$i<count($stockInfo);$i++,$j++){
if($stockInfo[$i][7]=0)
 $getSupplierInfo = $qc-> getSupplierInfo($stockInfo[$i][1]);
if($stockInfo[$i][12]>0){
	?>
    <tr class="recordBox">
      <td><?php echo $j ;?></td>
       <td><?php echo $getSupplierInfo[0][1];?></td>
      <td><?php echo $stockInfo[$i][3];?></td>
      <td><?php echo $stockInfo[$i][2];?></td>
      <td><?php echo $stockInfo[$i][4];?></td>
      <td><?php echo $stockInfo[$i][5];?></td>
      <td><?php echo $stockInfo[$i][6];?></td>
      <td><?php echo $stockInfo[$i][7];?></td>
      <td><?php echo $stockInfo[$i][11];?></td> 
      <td><?php echo $stockInfo[$i][8];?></td>
      <!--<td><?php echo $stockInfo[$i][9];?></td>-->
      <td><?php if($stockInfo[$i][7]>0){?><a href="stock_query.php?function=supl_prod_return&stock_id=<?php echo $stockInfo[$i][0];?>&sup_id=<?php echo $stockInfo[$i][1];?>&invoice_no=<?php echo $stockInfo[$i][3];?>&quantity=<?php echo $stockInfo[$i][7];?>&sold_quantity=<?php echo $stockInfo[$i][10];?>&unit_price=<?php echo $stockInfo[$i][8];?>&amount=<?php echo $stockInfo[$i][9];?>"onclick="return confirm('Are you sure you want to return?')">GR</a><?php }?></td>

 
</tr>
    <?php } }?>
 
  </table>
</div>
<!--dynamic content end
-->
</div>
<!--middle container end-->
</div>
	<!--main container end-->    
</div>
</div>
<!--wrapper end-->
</body>
</html>
