<?php
 include_once('auth.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Infinity by Ruchi | Add Costomer</title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet" />
<link href="css/style.css" type="text/css" rel="stylesheet" />
<link href="css/menu.css" type="text/css" rel="stylesheet" />
<script src="js/menu_script.js" type="text/javascript"></script>
<script src="js/jquery-1.9.1.min.js" type="text/javascript"></script>
</head>
<body>
<!-- wrapper start-->
<div class="esya_wrapper">
  <!-- main container-->
  <div class="container">
    <!--herader container -->
    <?php include_once('header.php'); ?>
    <!--header container end-->
    <!--menu container-->
    <div class="menu_container">
      <?php include_once('menu.php'); ?>
    </div>
    <!--menu container end-->
    <!--middle container -->
    <div class="middle_container">
      
      
           <?php
			 $cust_id = $qc->clean($_REQUEST['cust_id']);
		$customerDetails = $qc->getCustomerInfo($cust_id);
		?>
      <!-- Add Dealer end-->
      <div class="middle_header"><span style="font-weight: bold;">View Customer</span> <span><?php if($cust_id!=''){ ?><a href="cust_records.php"> <img src="images/back.png"  style="float: right;" /></a></span><?php }?> </span></div>
 
      <div class="view_dealer">
        <table width="100%" class="">
               
        <tr>
            <td><span style="font-weight: bold;">Customer Name</span></td>
            <td><?php echo $customerDetails[0][1];?></td>
             <td><span style="font-weight: bold;">Contact No.</span></td>
            <td><?php echo $customerDetails[0][2];?></td>
          </tr>
          <tr>
             <td><span style="font-weight: bold;">Addres</span></td>
            <td><?php echo $customerDetails[0][3];?></td>
                <td><span style="font-weight: bold;">Tuks Pant</span></td>
            <td><?php echo $customerDetails[0][4];?></td>
          </tr>
          <tr>
           
          </tr>
          <tr>
            <td><span style="font-weight: bold;">Full Length</span></td>
            <td><?php echo $customerDetails[0][6];?></td>
             <td><span style="font-weight: bold;">Body Length</span></td>
            <td><?php echo $customerDetails[0][5];?></td>
          </tr>
          <tr>
           
          </tr>
          <tr>
           <td><span style="font-weight: bold;">Upper Chest</span></td>
            <td><?php echo $customerDetails[0][8];?></td>
              <td><span style="font-weight: bold;">Chest</span></td>
            <td><?php echo $customerDetails[0][7];?></td>
          </tr>
          <tr>
          
          </tr>
          <tr>
            <td><span style="font-weight: bold;">Hips</span></td>
            <td><?php echo $customerDetails[0][10];?></td>
            <td><span style="font-weight: bold;">Waist</span></td>
            <td><?php echo $customerDetails[0][9];?></td>
          </tr>
          <tr>
            
          </tr>
          <tr>
             <td><span style="font-weight: bold;">Cross Front</span></td>
            <td><?php echo $customerDetails[0][12];?></td>
             <td><span style="font-weight: bold;">Shoulder</span></td>
            <td><?php echo $customerDetails[0][11];?></td>
          </tr>
          <tr>
           
          </tr>
          <tr>
             <td><span style="font-weight: bold;">Sleeve</span></td>
            <td><?php echo $customerDetails[0][14];?></td>
             <td><span style="font-weight: bold;">Arm Hole</span></td>
            <td><?php echo $customerDetails[0][13];?></td>
          </tr>
          <tr>
           
          </tr>
          <tr>
          <td><span style="font-weight: bold;">Back Neck</span></td>
            <td><?php echo $customerDetails[0][16];?></td>
            <td><span style="font-weight: bold;">Front Neck</span></td>
            <td><?php echo $customerDetails[0][15];?></td>
          </tr>
          <tr>
            
          </tr>
          <tr>
             <td><span style="font-weight: bold;">Pant</span></td>
            <td><?php echo $customerDetails[0][18];?></td>
             <td><span style="font-weight: bold;">Churidar</span></td>
            <td><?php echo $customerDetails[0][17];?></td>
          </tr>
           <tr>
           
          </tr>
      
        </table>
      </div>
    </div>
    <!--middle container end-->
  </div>
  <!--main container end-->
</div>
</div>
<!--wrapper end-->
</body>
</html>
