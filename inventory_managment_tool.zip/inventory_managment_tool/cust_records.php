<?php
 include_once('auth.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Measurement Details</title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet" />
<link href="css/style.css" type="text/css" rel="stylesheet" />
<link href="css/menu.css" type="text/css" rel="stylesheet" />
<script src="js/menu_script.js" type="text/javascript"></script>
<script src="js/jquery-1.9.1.min.js" type="text/javascript"></script>
<script type="text/javascript">
function clickhere(){
//alert('jfdg');
	$("#add_custDetails").addClass("i-hide");
$("#add_newId").html('<div style="width: 40px ! important; border: medium none;line-height: 30px;border-radius: 5px; cursor: pointer;float: right;margin-top: -5px;" onclick="clickhere1();" class="recBtn">+</div>');
    
}

function clickhere1(){
		$("#add_custDetails").removeClass("i-hide");
		$("#add_newId").html('<div style="width: 40px ! important; border: medium none;line-height: 30px;border-radius: 5px; cursor: pointer; float: right;margin-top: -5px;" onclick="clickhere();" class="recBtn">X</div>');
      
}
</script>
</head>
<body>
<!-- wrapper start-->
<div class="esya_wrapper">
  <!-- main container-->
  <div class="container">
    <!--herader container -->
    <?php include_once('header.php'); ?>
    <!--header container end-->
    <!--menu container-->
    <div class="menu_container">
      <?php include_once('menu.php'); ?>
    </div>
    <!--menu container end-->
    <!--middle container -->
    <?php /*?>          <?php
include_once("message.php");
$sup_idDB = $qc->clean($_REQUEST['sup_id']);
if($sup_idDB!=''){
$supplierDetails = $qc->getSupplierInfo($user_idDB);
}

?><?php */
		$cust_id = $qc->clean($_REQUEST['cust_id']);
if($cust_id!=''){
		$customerViewDetails = $qc->getCustomerInfo($cust_id);
}
			  ?>
    <div class="middle_container">
      <div class="middle_header">
        <div class="col-md-11" style="position: relative;left: 44px;">Add Customer Measurement </div>
        <div class="col-md-1" id="add_newId">
          <?php if($cust_id==''){ 
		  $classes = "i-hide";
		  ?>
          <div style="width: 40px ! important; border: medium none;line-height: 30px; cursor: pointer;border-radius: 5px;float: right;margin-top: -5px;" onclick="clickhere1();" class="recBtn">+</div>
          <?php }else{ $classes = "";}?>
        </div>
      </div>
      <div class="add_customer <?php echo $classes;?>" id="add_custDetails">
        <form name="add_supplier" method="post" action="query.php">
          <table align="center" width="100%" class="add_dealer_table">
            <tr>
              <td width="20px"></td>
              <td colspan="5"><b>Customer Details</b></td>
            </tr>
            <tr>
              <td width="20px"></td>
              <td colspan="5"><input type="text" class="input_width" name="name" value="<?php echo $customerViewDetails[0][1];?>" placeholder="Name" required/>
                <input type="text" class="input_width" name="contact_no" maxlength="10" value="<?php echo $customerViewDetails[0][2]; ?>" placeholder="Contact No."  required/>
                <input type="text" class="input_width" name="address" value="<?php echo $customerViewDetails[0][3]; ?>" placeholder="Address"  required/>
              </td>
            </tr>
            <tr>
              <td width="20px"></td>
              <td colspan="5"><b>Measurement Details</b></td>
            </tr>
            <tr>
              <td width="20px"></td>
              <td><input type="text" name="tuks_pant" placeholder="Tuks Pant" value="<?php echo $customerViewDetails[0][4]; ?>"/></td>
              <td><input type="text" name="body_length" placeholder="Body Length" value="<?php echo $customerViewDetails[0][5]; ?>"/></td>
              <td><input type="text" name="full_length" placeholder="Full Length" value="<?php echo $customerViewDetails[0][6]; ?>"/></td>
              <td><input type="text" name="chest" placeholder="Chest" value="<?php echo $customerViewDetails[0][7]; ?>"/></td>
              <td><input type="text" name="upper_chest" placeholder="Upper Chest" value="<?php echo $customerViewDetails[0][8]; ?>"/></td>
            </tr>
            <tr>
              <td width="20px"></td>
              <td><input type="text" name="waist" placeholder="Waist" value="<?php echo $customerViewDetails[0][9]; ?>"/></td>
              <td><input type="text" name="hips" placeholder="Hips" value="<?php echo $customerViewDetails[0][10]; ?>"/></td>
              <td><input type="text" name="shoulder" placeholder="Shoulder" value="<?php echo $customerViewDetails[0][11]; ?>"/></td>
              <td><input type="text" name="cross_front" placeholder="Cross Front" value="<?php echo $customerViewDetails[0][12]; ?>"/></td>
              <td><input type="text" name="arm_hole" placeholder="Arm Hole"value="<?php echo $customerViewDetails[0][13]; ?>"/></td>
            </tr>
            <tr>
              <td width="20px"></td>
              <td><input type="text" name="sleeve" placeholder="Sleeve" value="<?php echo $customerViewDetails[0][14]; ?>"/></td>
              <td><input type="text" name="front_neck" placeholder="Front Neck" value="<?php echo $customerViewDetails[0][15]; ?>"/></td>
              <td><input type="text" name="back_neck" placeholder="Back Neck" value="<?php echo $customerViewDetails[0][16]; ?>"/></td>
              <td><input type="text" name="churidar" placeholder="Churidar" value="<?php echo $customerViewDetails[0][17]; ?>"/></td>
              <td><input type="text" name="pant" placeholder="Pant" value="<?php echo $customerViewDetails[0][18]; ?>"/></td>
            </tr>
            <tr>
              <td width="20px"></td>
              <td colspan="4"></td>
              <td><input type="submit" class="recBtn" name="add" value="Submit" style="margin-bottom: 25px; border: medium none;" />
                <input type="hidden" name="function" value="add_customer" />
                <input type="hidden" name="cust_id" value="<?php echo $cust_id; ?>" />
              </td>
            </tr>
          </table>
        </form>
      </div>
      <!-- Add Dealer end-->
      <!--<div class="middle_header" style="margin-top: 20px;"><span>Customer Measurement Records</span><span><input type="text" width="50px" /></span></div>-->
      <div class="middle_header" style="margin-top: 30px;">
        <div class="col-md-7"><span style="position: relative;left: 184px;">Customer Measurement Records</span></div>
        <form name="search" method="post" action="cust_records.php">
          <div class="col-md-5"><span style="position: relative;  top: -7px;">Search by:&nbsp;
            <input name="measurement_search" style="width: 200px ! important; color: rgb(89, 86, 84) ! important; font-size: 12px;" placeholder="Name" type="text">
            <input name="" value="" class="myBtn btn" type="submit">
            </span></div>
        </form>
      </div>
      <div class="view_dealer">
        <table align="center" width="100%" class="ov_table">
          <tr style="background: rgb(241, 241, 241) none repeat scroll 0% 0%;">
            <td width="10px"></td>
            <td><span>Sr. No.</span></td>
            <td><span>Name</span></td>
            <td><span>Contact No.</span></td>
            <td><span>Addres</span></td>
            <td><span></span></td>
            <td><span></span></td>
            <td><span></span></td>
          </tr>
          <?php
		  $measurement_search = $qc->clean($_REQUEST['measurement_search']);
		  if($measurement_search!=''){
		  $customerDetails = $qc->getCustomerInfoSearch($measurement_search);
		  }else{
		$customerDetails = $qc->getCustomerInfo('');
		}
for($i=0,$j=1;$i<count($customerDetails);$i++,$j++){
		?>
          <tr class="recordBox">
            <td></td>
            <td><?php echo $j; ?></td>
            <td><?php echo $customerDetails[$i][1];?></td>
            <td><?php echo $customerDetails[$i][2];?></td>
            <td><?php echo $customerDetails[$i][3];?></td>
            <td><a href="cust_records_view.php?cust_id=<?php echo $customerDetails[$i][0];?>"><img src="images/view.png" /></a></td>
            <td><a href="cust_records.php?cust_id=<?php echo $customerDetails[$i][0];?>"><img src="images/edit.png" /></a></td>
              <td><a href="query.php?function=delete_customer_info&cust_id=<?php echo $customerDetails[$i][0];?>"onclick="return confirm('Are you sure you want to Delete?')"><img src="images/delete.png" /></a></td>
          </tr>
          <?php }?>
        </table>
      </div>
    </div>
    <!--middle container end-->
  </div>
  <!--main container end-->
</div>
</div>
<!--wrapper end-->
</body>
</html>
