<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php  
require_once('auth.php');
include_once("classes/query_class.php");
	  $qc = new queryClass();
	  ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Customer Details</title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet" />
<link href="css/style.css" type="text/css" rel="stylesheet" />
<link href="css/menu.css" type="text/css" rel="stylesheet" />
<link href="css/pop_up_user_profile.css" type="text/css" rel="stylesheet" />
<!--calender code-->
<link rel="stylesheet" href="css/jquery-ui.css">
<style>
.m-hide {
	display:none;
}
</style>
<script src="js/jquery-1.10.2.js"></script>
<script src="js/jquery-ui.js"></script>
<!--calender code end -->
<script src="js/menu_script.js" type="text/javascript"></script>
<?php $receipt_idR = $qc->clean($_REQUEST[receipt_id]);
if($receipt_idR==''){$receipt_idR=0;}
?>
<script type="text/javascript">
var rowCount = 0;
var rowCount1;
function addMoreRows(frm) {

rowCount ++;
 rowCount1 = $("#count").val();

var recRow = '<tr id="rowCount'+rowCount+'"><td>\
<input type="text" id="infitycode'+rowCount+'"  onkeyup="return infinityCodeuse('+rowCount+');" placeholder="Infinity Code"/>\
<input type="hidden" id="product'+rowCount+'" name="product'+rowCount+'" />';
<?php  
	  $stockInfo = $qc->getStockInfo('','','');
	  for($i=0;$i<count($stockInfo); $i++){
	  if($stockInfo[$i][7]>0){
	  ?>
	 
//recRow += '<option value="<?php echo $stockInfo[$i][0]; ?>"><?php echo $stockInfo[$i][5]; ?></option>';
<?php }}?>
recRow +='</td><td><input type="text" id="description'+rowCount+'" name="description'+rowCount+'"  placeholder="description" /></td><td><input type="text" id="quantity'+rowCount+'" name="quantity'+rowCount+'" placeholder="quantity" /></td><td><input id="unit_price'+rowCount+'" type="text" name="unit_price'+rowCount+'" placeholder="Unit Price" readonly /></td><td><input type="text" name="discount'+rowCount+'" placeholder="Discount" /></td><td><input type="text" name="total'+rowCount+'" placeholder="total" /></td><td><a href="javascript:void(0);" onclick="removeRow('+rowCount+');"><input type="button" style="width: 40px ! important; border: medium none;" value=" X " class="recBtn" /></a></td></tr><tr height="15px;"><td></td></tr>';


jQuery('#addedRows').append(recRow);
rowCount1=rowCount;
$("#count").val(rowCount1+1);

}

function removeRow(removeNum) {
$('#rowCount'+removeNum).remove();
var use = $("#count").val();
var rowCount2 = use-1;
$("#count").val(rowCount2);

}

function chooseIcode(){
var receipt_id = <?php echo $receipt_idR; ?>;
if(receipt_id!=''){
	var mycout = $('#count').val()-1;
	//alert(mycout);
	
}else{
var mycout = rowCount;
}
//alert(mycout);
for(var i=0; i<=mycout; i++){
var code = $('#i_code'+i).val();

if(code!='')
{
   <?php 
 
	  $stockInfo = $qc->getStockInfo('','','');
	  for($i=0;$i<count($stockInfo); $i++){
	  ?>
	  var newcode = "<?php echo $stockInfo[$i][0];?>";
	  if(code == newcode){
	  $('#show_unitprice'+i).val(<?php echo $stockInfo[$i][8];?>);
	  $('#i_code'+i+'').css("border-color","black"); 
	  }
	 <?php  }
	  ?>
    }else{
	
	$('#i_code'+i+'').css("border-color","red");
	
	}
	
	}//this for loop check mycout

}

$(function() {
    $( "#datepicker" ).datepicker();
     // $( "#datepicker" ).datepicker("setDate", new Date());
	  
  });
function clickhere(){
//alert('jfdg');
	$("#add_receiptDetails").addClass("i-hide");
$("#add_newId").html('<div style="width: 40px ! important; border: medium none;line-height: 30px;border-radius: 5px; cursor: pointer;float: right;margin-top: -5px;" onclick="clickhere1();" class="recBtn">+</div>');
    
}

function clickhere1(){
		$("#add_receiptDetails").removeClass("i-hide");
		$("#add_newId").html('<div style="width: 40px ! important; border: medium none;line-height: 30px;border-radius: 5px; cursor: pointer; float: right;margin-top: -5px;" onclick="clickhere();" class="recBtn">X</div>');
      
}

function infinityCodeuse(no) {
		var no = no;
		//alert(no);
		var infitycode = $('#infitycode'+no).val(); 
		//alert(infitycode);
		var tabaledata=' ';
		if(infitycode!=''){
		//alert(infitycode);
			
								          
		$.ajax({
				   type: 'POST',
				   url: 'query.php',
				   data: 'function=username_checjinfintycode&infitycode='+infitycode,
				   cache: false,
				   success: function(result) {
					var	response = result;
					//alert(response);   
					console.log(response); 		
	   				var json_obj = $.parseJSON(response);//parse JSON  
					
         if(json_obj!=''){
            for (var i in json_obj) 
            {
				$('#description'+no).css('border-color','#DADADA');
			$('#quantity'+no).css('border-color','#DADADA');
			$('#unit_price'+no).css('border-color','#DADADA');
				
			$('#product'+no).val(json_obj[i].stock_id);			
			$('#description'+no).val(json_obj[i].description);
			$('#quantity'+no).val(json_obj[i].quantity);
			$('#unit_price'+no).val(json_obj[i].unit_price);
			
			}
			}else{
			$('#description'+no).css('border-color','red');
			$('#quantity'+no).css('border-color','red');
			$('#unit_price'+no).css('border-color','red');
			
			}
					}
				 });
			}else{
			$('#shoe_rec_inficode').html(tabaledata);
			}
		
	}
	
function showontextboxivalues(stock_id,discr,i_code){
alert(stock_id+"-"+discr+"-"+i_code);

}	

function userIdinfo(userName){

	var userName = userName;
	if(userName!=''){
	//alert(userName);	
	$("#rec_name").val(userName); 
	$("#profile_cam").show();
	}
}
$(function() {    
	  
	 $( "#datepicker_cust" ).datepicker();
      $( "#datepicker_cust" ).datepicker( "setDate", new Date());
  });
  
$(document).ready(function(){
$('#UserPoupclose').click(function(e){  
  
      $("#profile_cam").hide(); 
     });  // open  profile img popup
   
   
    });


function paymodecheque(val){
if(val==3){
$('#cheque_no').show();
$('#cheque_no1').show();
}else{

  $('#cheque_no').hide();
  $('#cheque_no1').hide();

}
}
</script>
</head>
<body>
<!-- wrapper start-->
<div class="esya_wrapper"> 
  <!-- main container-->
  <div class="container"> 
    <!--herader container -->
    <?php include_once('header.php'); ?>
  <!--header container end--> 
  <!--menu container-->
  <div class="menu_container">
    <?php include_once('menu.php'); ?>
  </div>
  <!--menu container end--> 
  <!--middle container -->
  <div class="middle_container">
   
    <div class="view_receiptTable">
    
      <div class="middle_header"><span style="float:left; margin-left:500px">Customer Personal Account</span></div>
      <div class="view_dealer">
        <table align="center" width="100%" class="ov_table">
          <tr style="background: rgb(241, 241, 241) none repeat scroll 0% 0%;">
            
             <td><span>Sr.No.</span></td>      
            <td><span>Name</span></td>
            <td><span>Mobile No.</span></td>
			<td><span>Total Amount&nbsp;(&nbsp;<img src="images/rupee.png" width="10"/>&nbsp;)</span></td>
			<td><span>Paid Amount&nbsp;(&nbsp;<img src="images/rupee.png" width="10"/>&nbsp;)</span></td>
			<td><span>Amount Due&nbsp;(&nbsp;<img src="images/rupee.png" width="10"/>&nbsp;)</span></td>          
            <td><span>Record Payments</span></td>
   			<td><span>View</span></td>
          </tr>
    
    <?php 
    $getDistinctCustRecInfo = $qc-> getDistinctCustRecInfo('');
	for($i=0;$i<count($getDistinctCustRecInfo);$i++){
	$userAmountetails = $qc->getDistinctCustRecInfoForTotal($getDistinctCustRecInfo[$i][1]);
    ?>
          <tr class="recordBox">
           
            <td><?php echo $i+1; ?></td>    <!-- Sr. No. -->      
            
            <td><?php echo $getDistinctCustRecInfo[$i][1]; ?></td> <!-- Name --> 
            <td><?php echo $userAmountetails[0][7]; ?></td><!-- Mobile No. --> 
			<td><?php echo $userAmountetails[0][4]; ?></td><!-- Total Amount  --> 
			<td><?php echo $userAmountetails[0][5]; ?></td><!-- Paid Amount --> 
			<td><?php echo $userAmountetails[0][6]; ?></td><!-- Amount due  --> 
          <td><a onclick=" userIdinfo('<?php echo $getDistinctCustRecInfo[$i][1];?>');" style="cursor: pointer;"><img src="images/pay.png" /></a></td>
            <td><a href="receipt_view.php?user_name=<?php echo $getDistinctCustRecInfo[$i][1];?>&total_amount=<?php echo $userAmountetails[0][4]; ?>"><img src="images/view.png" /></a></td>
           
         
          </tr>
     <?php } ?>
        </table>
      </div>
    </div>
    <!--middle container end--> 
  </div>
  <!--main container end--> 
</div>
</div>
<!--wrapper end-->


<!-- popup1 start-->
<div class="c-pro-sp-PopupWrap m-hide" id="profile_cam">
  <div class="c-pro-sp-PopupNew">
    <!-- Header Text -->
    <div class="c-pro-sp-PpTxt">
      <div class="c-pro-sp-form"> <span class="c-pro-sp-closePp">
        <button type="button" class="close" id="UserPoupclose">×</button>
        </span>
        <div class="c-pro-sp-Info">
          <div id="t-pro-sp-popup-image"  >
            <form name="userpayment" action="query.php" method="post" enctype="multipart/form-data">
              <table>
                <tr>
                   <td width="30%">Name</td>
                  <td width="20%">Date</td>
                 <!-- <td width="20%">Receipt No.</td>-->
               
                  <!--<td width="20%">Amount Due</td>-->
                  <td width="20%">New Payment</td>
                </tr>
                <tr>
                  <td><input type="text" name="rec_name" id="rec_name" readonly="readonly"/></td>
                  <td><input type="text" name="rec_date" id="datepicker_cust" required/></td>
                  <!--<td><input type="text" name="rec_num" id="rec_num" readonly="readonly"/></td>-->
                
                  <!--<td><input type="text" name="balance_amount" id="balance_amount" readonly="readonly"/></td>-->
                  <td><input type="text" name="new_pay" required/></td>
                </tr>
                <tr><td colspan="3" height="20"></td></tr>
                <tr>
                <td><div class="col-md-6">Payment Mode:</div><div class="col-md-6"><ul class="input_ul">
            <li>
              <input name="pay_mode" value="cc" onclick="paymodecheque(1);" type="radio">
              CC</li>
            <li>
              <input name="pay_mode" value="cash" onclick="paymodecheque(2);" type="radio">
              Cash</li>
            <li>
              <input name="pay_mode" value="cheque" onclick="paymodecheque(3);" type="radio">
              Cheque</li>
          </ul></div></td>
          <td id="cheque_no" style="display: none;">Cheque No:</td>
          <td id="cheque_no1" style="display: none;"><input name="cheque_no" value=""  type="text"></td>
                </tr>
                <tr>
                  <td colspan="5" style="text-align: center;"><input type="hidden" name="paid_amount" id="paid_amount" />
                    <input type="hidden" name="receipt_id" id="user_rec_id" />
                    <input type="hidden" name="function" value="add_user_new_payment_newchanges"  />
                    <input type="submit" name="Submit" value="Submit" title="Submit"  class="submit" style="width:200px!important;"/></td>
                </tr>
              </table>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<!--popup1 end-->


</body>
</html>
