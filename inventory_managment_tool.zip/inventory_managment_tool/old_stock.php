<?php
 include_once('auth.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Add Old Stock</title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet" />
<link href="css/style.css" type="text/css" rel="stylesheet" />
<link href="css/menu.css" type="text/css" rel="stylesheet" />
  <link href="css/font-awesome.css" type="text/css" rel="stylesheet" />
<script src="js/menu_script.js" type="text/javascript"></script>
<script src="js/jquery-1.9.1.min.js" type="text/javascript"></script>

</head>
<body>
<!-- wrapper start-->
<div class="esya_wrapper">
  <!-- main container-->
  <div class="container">
    <!--herader container -->
 <?php include_once('header.php'); ?>
    <!--header container end-->
    <!--menu container-->
    <div class="menu_container">
      <?php include_once('menu.php'); ?>
    </div>
    <!--menu container end-->
    <!--middle container -->
    <div class="middle_container">
      <div class="middle_header"><span style="float:left; margin-left:429px">Add Old Stock&nbsp;&nbsp;(2015-16)</span></div>
      <div class="add_dealer">
        <form name="add_old_stock" method="post" action="query.php">
          <table align="center" width="98%" class="add_dealer_table">
          <?php
include_once("message.php");
$sr_noDB = $qc->clean($_REQUEST['sr_no']);
if($sr_noDB!=''){
$getOldStockInfo = $qc->getOldStockInfo($sr_noDB);
}

?>
            <tr>
              <td class="add_inputBox"><input type="text" name="old_infinity_code" value="<?php echo $getOldStockInfo[0][1]; ?>" placeholder="Infinity Code" required/></td>
            
               <td class="add_inputBox"><input type="text" name="old_sp_amount" value="<?php echo $getOldStockInfo[0][2]; ?>" placeholder="SP Amount"  required/></td>
       
                                   
                        <td colspan="3">
         
              <input type="hidden" name="function" value="add_old_stock" />
              <?php if($sr_noDB!=''){?>
              <input type="submit" class="input_Btn recBtn" name="" value="Save"  />
              <?php }else {?>
               <input type="submit" class="input_Btn recBtn" name="" style="border: medium none;" value="Submit"  />
               <?php } ?>
              <input type="hidden" name="sr_noDB" value="<?php echo $sr_noDB; ?>" />
              </td>
         </tr> 
          </table> 
        </form>
      </div>
      <!-- Add Dealer end-->
      <br />
       <div class="middle_header"><div class="col-md-7"><span style="position: relative;left: 184px;">View Old Stock&nbsp;&nbsp;(2015-16)</span>
       <!--<span style="float: inherit;">
       <a href="query.php?function=update_stock">Trigger</a></span>--></div>
               <?php
			 
		$getOldStockInfo = $qc->getOldStockInfo('');
		
		$grand_total=0;
		
		for($i=0,$j=1;$i<count($getOldStockInfo);$i++,$j++){
		$grand_total= $grand_total+$getOldStockInfo[$i][2];
		}

		?>
       <div class="col-md-5" style="padding-right: 96px;">Total SP Cost:&nbsp;Rs.&nbsp;<?php echo $grand_total ;?>&nbsp; Only.</span></div>
       
         <!--<form name="stock_search" method="post" action="supplier_add.php">
         <div class="col-md-5"><span style="position: relative;  top: -7px;">Search by:&nbsp;
           <input type="text" name="search" style="width: 200px ! important; color: rgb(89, 86, 84) ! important; font-size: 12px;" placeholder="ARE WE REMOVING IT?" /> 
           <input type="submit" name="" value="" class="myBtn btn" />
        <input type="hidden" name="function" value="add_old_stock" />
           
           </span></div-->
         </form>
           </div>
       <div class="view_dealer" style="width: 1139px;
    height: 400px;
    overflow: scroll;">
          <table align="center" width="100%" class="ov_table">
           <tr style="background: rgb(241, 241, 241) none repeat scroll 0% 0%;">
          <td width="10px"></td>
             <td><span>Sr. No.</span></td>
             <td><span>Infinity Code</span></td>
         
             <td><span>SP Amount</span></td>
    
             
             <td><span></span></td>
                     <td><span></span></td>
            </tr>
             <?php
			 
		$getOldStockInfo = $qc->getOldStockInfo('');

		for($i=0,$j=1;$i<count($getOldStockInfo);$i++,$j++){

		?>
            <tr class="recordBox">
            <td></td>
           <td><?php echo $j; ?></td>
            <td><?php echo $getOldStockInfo[$i][1];?></td>
            
             <td><?php echo $getOldStockInfo[$i][2];?></td>
           
         
            <td><a href="old_stock.php?sr_no=<?php echo $getOldStockInfo[$i][0];?>"><img src="images/edit.png" /></a></td>
            <td><a href="query.php?function=delete_old_stock&sr_no=<?php echo $getOldStockInfo[$i][0];?>"onclick="return confirm('Are you sure you want to Delete?')"><img src="images/delete.png" /></a></td>
     
           <td><span></span></td>
            </tr>
            <?php }?>
            

          </table>
       </div>
       
    </div>
    <!--middle container end-->
  </div>
  <!--main container end-->
</div>
</div>
<!--wrapper end-->
</body>
</html>
