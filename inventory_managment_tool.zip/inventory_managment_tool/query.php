<?php 
	require_once('auth.php');
	
	$function = $_REQUEST['function'];
	
	//change Password
	if($function=='change_password'){
		$new_user_name   =  $qc->clean($_REQUEST['new_user_name']);
		$old_user_name   =  $qc->clean($_REQUEST['old_user_name']);
		$password_new   =  $qc->clean($_REQUEST['new_password']);
		$old_password   =  $qc->clean($_REQUEST['old_password']);
		//$id =  $qc->clean($_REQUEST['SESS_USER_ID']);
		if($old_password == $password_new || $old_user_name == $new_user_name ){
			//header("Location:change_password.php?msg=3");
		}
		else{
			$pass   =  $qc->change_password($id,$password_new,$old_password,$new_user_name,$old_user_name);
			//echo $pass." ".$id." ".$password_new." ".$old_password;
			if($pass==1){    
				header("Location: setting.php?msg=2");
			}
			if($pass==2){    
				header("Location: setting.php?msg=4");
			}
			if($pass==3){    
				header("Location:setting.php?msg=1Enter Old Password");
			}
		}
	} //change_password end
	
	/*.................................... trigger event .....................................*/
	
	/*if($function == 'update_stock'){
	
	$getOldStockToNewStockInfo = $qc->getOldStockToNewStockInfo('');
	for($i=0;$i<count($getOldStockToNewStockInfo);$i++){
	
	$update_new_stock = $qc->addOldToStockInfo($getOldStockToNewStockInfo[$i][1],$getOldStockToNewStockInfo[$i][2]);
	
	
	$update_old_stock_flag = $qc->editOldStockAftrnfo($getOldStockToNewStockInfo[$i][0]);
	
	}
	
	if($update_old_stock_flag==true){
		header("Location: overview.php?status=Done");
	}
	else{
    	header("Location: overview.php?status=not_done");
	}
	
	}*/
	
	/*.................................... trigger event end .....................................*/
	
	/*..................................... Supplier Start ...................................*/
	
	//add and edit supplier
if($function == 'add_supplier')	{
	$name =  $qc->clean($_REQUEST['name']);
	$contact_no =  $qc->clean($_REQUEST['contact_no']);
	$mobile_no =  $qc->clean($_REQUEST['mobile_no']);
	$email_id =  $qc->clean($_REQUEST['email_id']);
	$address =  $qc->clean($_REQUEST['address']);
	$sup_idDB = $qc->clean($_REQUEST['sup_idDB']);
	
	if($sup_idDB!=''){
	$iso = $qc->editSupplierInfo($name,$contact_no,$mobile_no,$email_id,$address,$sup_idDB);
	
	}
	else{
	
	$iso = $qc->addSupplierInfo($name,$contact_no,$mobile_no,$email_id,$address);
	}
	if($iso == true)
	{
		header("Location:supplier_add.php?status=6");
	}
	else
	{
		header("Location: supplier_add.php?status=2");
	}
	}//add supplier end
	
	//add sup installments
	if($function == 'add_supl_new_payment'){
	
	$invo_date = $qc->clean($_REQUEST['invo_date']);
	  $paid_date = explode("/", $invo_date);
     $installment_date = $paid_date[2]."-".$paid_date[1]."-".$paid_date[0];
	
	 $invo_num = $qc->clean($_REQUEST['invo_num']);
	 $invo_total_amt = $qc->clean($_REQUEST['invo_total_amt']);	
	 $invo_amt_paid = $qc->clean($_REQUEST['invo_amt_paid']);
	 $invo_bal_amt = $qc->clean($_REQUEST['invo_bal_amt']);
	 $invo_new_pay = $qc->clean($_REQUEST['invo_new_pay']);
	 $sup_idDB = $qc->clean($_REQUEST['sup_id']);
	 $invoice_code = $qc->clean($_REQUEST['supplier_invoice_code']);
	
	if($sup_idDB!='' && $invo_new_pay!=''){
	
	$newPaid_amount = $invo_amt_paid + $invo_new_pay;
	
	$newbalance_amount = $invo_bal_amt - $invo_new_pay;	
	  
 $sup_bal_id = $qc->editNewSupInvoiceInfo($newPaid_amount,$newbalance_amount,$sup_idDB,$invoice_code); //inital entery  and after installment updted info 
 
	if($invo_new_pay!=''&& $installment_date!='' && $sup_bal_id!=''){
		
		$add_userPay = $qc->addSuplBalAmtInfo($sup_bal_id,$installment_date,$invo_new_pay);
		$invo_new_pay='';
		$installment_date='';
	}
	 
		
	if($add_userPay == true){
			header("Location: overview.php?status=6");
		}else{
			header("Location: overview.php?status=2");
		}
		
		}else{
		
		header("Location:overview.php?status=2");
		
		}
	
	}

	
	
	
	//delete supplier
	
if($function=='delete_supplier_info'){
	
	$sup_id =  $qc->clean($_REQUEST['sup_id']);
	
	 $iso =  $qc->deleteSupplierInfo($sup_id);
	
	if($iso==true){
		header("Location: supplier_add.php?status=deleted");
	}
	else{
    	header("Location: supplier_add.php?status=not_deleted");
	}
	}// if end 
	
	/*..................................... Expenses Start ...................................*/
	
	//add and edit expenses 
if($function == 'add_expenses')	{
	$exp_dateOG =  $qc->clean($_REQUEST['exp_date']);
	
	$exp_dateFrormated = explode("/", $exp_dateOG);
     $exp_date = $exp_dateFrormated[2]."-".$exp_dateFrormated[1]."-".$exp_dateFrormated[0];
	
	$exp_particulars =  $qc->clean($_REQUEST['exp_particulars']);
	$exp_amount =  $qc->clean($_REQUEST['exp_amount']);
	
	$exp_idDB = $qc->clean($_REQUEST['exp_idDB']);
	
	if($exp_idDB!=''){
	$iso = $qc->editExpensesInfo($exp_date,$exp_particulars,$exp_amount,$exp_idDB);
	
	}
	else{
	
	$iso = $qc->addExpensesInfo($exp_date,$exp_particulars,$exp_amount);
	}
	if($iso == true)
	{
		header("Location:petty_cash.php?status=successful");
	}
	else
	{
		header("Location: petty_cash.php?status=fail");
	}
	}//add expenses end
	
	//expenses filter dates
	if($function == 'exp_filter_dates')	{
 $datepicker_start_dateOG =  $qc->clean($_REQUEST['search1']);
	
	$datepicker_start_dateFrormated = explode("/", $datepicker_start_dateOG);
    $exp_start_date = $datepicker_start_dateFrormated[2]."-".$datepicker_start_dateFrormated[1]."-".$datepicker_start_dateFrormated[0];
	
	 $datepicker_end_dateOG =  $qc->clean($_REQUEST['search2']);
	
	$datepicker_end_dateFrormated = explode("/", $datepicker_end_dateOG);
    $exp_end_date = $datepicker_end_dateFrormated[2]."-".$datepicker_end_dateFrormated[1]."-".$datepicker_end_dateFrormated[0];
	
	
	$iso = $qc->getExpSearchDateInfo($exp_start_date,$exp_end_date);

	if($iso == true)
	{
		header("Location:petty_cash.php?status=successful");
	}
	else
	{
		header("Location: petty_cash.php?status=fail");
	}
	}//add expenses end
	
		//delete expenses
	
if($function=='delete_petty_cash'){
	
	$exp_id =  $qc->clean($_REQUEST['exp_id']);
	
	 $iso =  $qc->deleteExpensesInfo($exp_id);
	
	if($iso==true){
		header("Location: petty_cash.php?status=deleted");
	}
	else{
    	header("Location: petty_cash.php?status=not_deleted");
	}
	}// if end 
	
	
//............................................... expenses end ......................................................................//	
	
	
	//add sup installments
	if($function == 'add_supl_new_payment'){
	
	$invo_date = $qc->clean($_REQUEST['invo_date']);
	  $paid_date = explode("/", $invo_date);
     $installment_date = $paid_date[2]."-".$paid_date[1]."-".$paid_date[0];
	
	 $invo_num = $qc->clean($_REQUEST['invo_num']);
	 $invo_total_amt = $qc->clean($_REQUEST['invo_total_amt']);	
	 $invo_amt_paid = $qc->clean($_REQUEST['invo_amt_paid']);
	 $invo_bal_amt = $qc->clean($_REQUEST['invo_bal_amt']);
	 $invo_new_pay = $qc->clean($_REQUEST['invo_new_pay']);
	 $sup_idDB = $qc->clean($_REQUEST['sup_id']);
	 $invoice_code = $qc->clean($_REQUEST['supplier_invoice_code']);
	
	if($sup_idDB!='' && $invo_new_pay!=''){
	
	$newPaid_amount = $invo_amt_paid + $invo_new_pay;
	
	$newbalance_amount = $invo_bal_amt - $invo_new_pay;	
	  
 $sup_bal_id = $qc->editNewSupInvoiceInfo($newPaid_amount,$newbalance_amount,$sup_idDB,$invoice_code); //inital entery  and after installment updted info 
 
	if($invo_new_pay!=''&& $installment_date!='' && $sup_bal_id!=''){
		
		$add_userPay = $qc->addSuplBalAmtInfo($sup_bal_id,$installment_date,$invo_new_pay);
		$invo_new_pay='';
		$installment_date='';
	}
	 
		
	if($add_userPay == true){
			header("Location: overview.php?status=6");
		}else{
			header("Location: overview.php?status=2");
		}
		
		}else{
		
		header("Location:overview.php?status=2");
		
		}
	
	}

	
	
	
	//delete supplier
	
if($function=='delete_supplier_info'){
	
	$sup_id =  $qc->clean($_REQUEST['sup_id']);
	
	 $iso =  $qc->deleteSupplierInfo($sup_id);
	
	if($iso==true){
		header("Location: supplier_add.php?status=deleted");
	}
	else{
    	header("Location: supplier_add.php?status=not_deleted");
	}
	}// if end 
	
	
	/*..................................... Customer Start ...................................*/
	
	//add and edit customer
	if($function == 'add_customer')	{
	$name =  $qc->clean($_REQUEST['name']);
	$contact_no =  $qc->clean($_REQUEST['contact_no']);
	$address =  $qc->clean($_REQUEST['address']);
	$tuks_pant =  $qc->clean($_REQUEST['tuks_pant']);
	$body_length =  $qc->clean($_REQUEST['body_length']);
	$full_length =  $qc->clean($_REQUEST['full_length']);
	$chest =  $qc->clean($_REQUEST['chest']);
	$upper_chest =  $qc->clean($_REQUEST['upper_chest']);
	$waist =  $qc->clean($_REQUEST['waist']);
	$hips =  $qc->clean($_REQUEST['hips']);
	$shoulder =  $qc->clean($_REQUEST['shoulder']);
	$cross_front =  $qc->clean($_REQUEST['cross_front']);
	$arm_hole =  $qc->clean($_REQUEST['arm_hole']);
	$sleeve =  $qc->clean($_REQUEST['sleeve']);	
	$front_neck =  $qc->clean($_REQUEST['front_neck']);	
	$back_neck =  $qc->clean($_REQUEST['back_neck']);	
	$churidar =  $qc->clean($_REQUEST['churidar']);	
	$pant =  $qc->clean($_REQUEST['pant']);	
	

	$cust_idDB = $qc->clean($_REQUEST['cust_id']);
	
	if($cust_idDB!=''){
	$iso = $qc->editCustomerInfo($name,$contact_no,$address,$tuks_pant,$body_length,$full_length,$chest,$upper_chest,$waist,$hips,$shoulder,$cross_front,$arm_hole,$sleeve,$front_neck,$back_neck,$churidar,$pant,$cust_idDB);
	
	}
	else{
	
	$iso = $qc->addCustomerInfo($name,$contact_no,$address,$tuks_pant,$body_length,$full_length,$chest,$upper_chest,$waist,$hips,$shoulder,$cross_front,$arm_hole,$sleeve,$front_neck,$back_neck,$churidar,$pant);
	}
	if($iso == true)
	{
		header("Location: cust_records.php?status=6");
	}
	else
	{
		header("Location: cust_records.php?status=2");
	}
	}//add supplier end
	
	
	//delete Customer
if($function=='delete_customer_info'){
	
	$cust_id =  $qc->clean($_REQUEST['cust_id']);
	
	 $iso =  $qc->deleteCustomernfo($cust_id);
	
	if($iso==true){
		header("Location: cust_records.php?status=deleted");
	}
	else{
    	header("Location: cust_records.php?status=not_deleted");
	}
	}// if end 
	
	
	
	
	
	/*..................................... Stock Start ...................................*/
	
	//add and edit stock
	
if($function =='add_stock')
	{
			$stock_id = $qc->clean($_REQUEST['stock_id']);
			 $stockChooseDealer = $qc->clean($_REQUEST['stockChooseDealer']);
			 $stockAddDate1 = $qc->clean($_REQUEST['stockAddDate']);
			 $stock_date = explode("/", $stockAddDate1);
			 $stockAddDate = $stock_date[2]."-".$stock_date[1]."-".$stock_date[0];
			 
			 $stockInvoiceNo = $qc->clean($_REQUEST['stockInvoiceNo']);
			 $sup_grand_total = $qc->clean($_REQUEST['sup_grand_total']);
			 $sup_paid_amt = $qc->clean($_REQUEST['sup_paid_amt']);
			 $sup_bal_amt = $qc->clean($_REQUEST['sup_bal_amt']);

			 $pay_mode = $qc->clean($_REQUEST['pay_mode']);
			 $cheque_no = $qc->clean($_REQUEST['cheque_no']);
			if($stock_id!=''){ 
				$oldCPPrice = $qc->clean($_REQUEST['oldstockUnitPriceDealer']);
				$newCPPrice = $qc->clean($_REQUEST['stockUnitPriceDealer0']);
			$supBalDetailsUsingInvoice = $qc->getSupBalDetailsUsingINvoice($stockInvoiceNo);// get value using invoice no for edit.
	
			if($supBalDetailsUsingInvoice[0][2]==0){
				if($oldCPPrice>=$newCPPrice){
					$sup_grand_total = ($supBalDetailsUsingInvoice[0][0]-$oldCPPrice)+$newCPPrice;
					$sup_paid_amt	= ($supBalDetailsUsingInvoice[0][1]-$oldCPPrice)+$newCPPrice;
				}else{
					$sup_grand_total	= ($supBalDetailsUsingInvoice[0][0]+$newCPPrice)-$oldCPPrice;
					$sup_bal_amt	= ($supBalDetailsUsingInvoice[0][2]+$newCPPrice)-$oldCPPrice;
				}
				
			}else{			
				if($oldCPPrice>=$newCPPrice){
					$sup_grand_total	= ($supBalDetailsUsingInvoice[0][0]-$oldCPPrice)+$newCPPrice;
					$sup_bal_amt	= ($supBalDetailsUsingInvoice[0][2]-$oldCPPrice)+$newCPPrice;
				}else{
						$sup_grand_total	= ($supBalDetailsUsingInvoice[0][0]+$newCPPrice)-$oldCPPrice;
						$sup_bal_amt	= ($supBalDetailsUsingInvoice[0][2]+$newCPPrice)-$oldCPPrice;
				}//end else if	
				
			}//end else if balance amount is equal to zero
			
			 $supBalnAmountInitial = $qc->editSupBalAmtInfo($stockChooseDealer,$stockAddDate,$stockInvoiceNo,$sup_grand_total,$sup_paid_amt,$sup_bal_amt,$pay_mode,$cheque_no); //edit total price 
			}else{
				$sameButItemChangeInvoice = $qc->getSupBalDetailsUsingINvoice($stockInvoiceNo);
				if($sameButItemChangeInvoice==''){
				$supBalnAmountInitial = $qc->addSupBalAmtInfo($stockChooseDealer,$stockAddDate,$stockInvoiceNo,$sup_grand_total,$sup_paid_amt,$sup_bal_amt,$pay_mode,$cheque_no); //inital entery 	
					}else{
					
					$sup_grand_total = $sameButItemChangeInvoice[0][0] + $sup_grand_total;
					$sup_paid_amt = $sameButItemChangeInvoice[0][1] + $sup_paid_amt;
					$sup_bal_amt = $sameButItemChangeInvoice[0][2] + $sup_bal_amt;
				$supBalnAmountInitial = $qc->editByMoreItemSupBalAmtInfo($stockChooseDealer,$stockAddDate,$stockInvoiceNo,$sup_grand_total,$sup_paid_amt,$sup_bal_amt,$pay_mode,$cheque_no);	
					}
			}
			 $countR = $qc->clean($_REQUEST['count']);
			 for($i=0;$i<$countR;$i++){
			 
				 $stockDealerCode = $qc->clean($_REQUEST['stockDealerCode'.$i]);
				 $stockInfinityCode = $qc->clean($_REQUEST['stockInfinityCode'.$i]);
				 $stockDescriptions = $qc->clean($_REQUEST['stockDescriptions'.$i]);		
				 $stockQuantity = $qc->clean($_REQUEST['stockQuantity'.$i]);
				 $stockUnitPriceDealer = $qc->clean($_REQUEST['stockUnitPriceDealer'.$i]);
				 $stockUnitPrice = $qc->clean($_REQUEST['stockUnitPrice'.$i]);
				 $stockAmount = $qc->clean($_REQUEST['stockAmount'.$i]);
			 
			 if($stockDealerCode!='' && $stockInfinityCode!='' && $stockQuantity!='' && $stockUnitPrice!=''){
		if($stock_id!=''){

		$stock_add = $qc->editStockInfo($stockChooseDealer,$stockAddDate,$stockInvoiceNo,$stockDealerCode,$stockInfinityCode,$stockDescriptions,$stockQuantity,$stockUnitPriceDealer,$stockUnitPrice,$stockAmount,$stock_id);

		}else{
		$stock_add = $qc->addStockInfo($stockChooseDealer,$stockAddDate,$stockInvoiceNo,$stockDealerCode,$stockInfinityCode,$stockDescriptions,$stockQuantity,$stockUnitPriceDealer,$stockUnitPrice,$stockAmount,0);
			 }	
				}//if end 
			
			 }// for loop end
			
			if($stock_add == true)
			{
				header("Location: stock_add.php?status=6");
			}
			else
			{
				header("Location: stock_add.php?status=2");
			}
			
}//if end
	
//delete stock
	
if($function=='delete_stock'){
	
	$stock_id =  $qc->clean($_REQUEST['stock_id']);
	
	 $iso =  $qc->deleteStockInfo($stock_id);
	
	if($iso==true){
		header("Location: stock_add.php?status=deleted");
	}
	else{
    	header("Location: stock_add.php?status=not_deleted");
	}
	}// if end 
			

/*..................................... Receipt Start ...................................*/		
			
	
	//add and edit receipt
	
	if($function =='add_user_receipt')	{
	
	$receipt_id = $qc->clean($_REQUEST['receipt_id']);
	$receipt_date = $qc->clean($_REQUEST['receipt_date']);
	 
	  $stock_date = explode("/", $receipt_date);
     $recipient_date = $stock_date[2]."-".$stock_date[1]."-".$stock_date[0];
	 
	 $recipient_name = $qc->clean($_REQUEST['recipient_name']);
	 $recipient_cont_no = $qc->clean($_REQUEST['recipient_cont_no']);
	 $grand_total = $qc->clean($_REQUEST['grand_total']);	  
	 $paid_amount = $qc->clean($_REQUEST['paid_amount']);
	 $bal_amount = $qc->clean($_REQUEST['bal_amount']);
	 $pay_mode = $qc->clean($_REQUEST['pay_mode']);
	 $cheque_no = $qc->clean($_REQUEST['cheque_no']);
	 
		if($receipt_id>0){
		
			$qc->editCustReceiptInfo($recipient_date,$recipient_name,$recipient_cont_no,$grand_total,$paid_amount,$bal_amount,$receipt_id);// insert all data and and return user or recipit id.
	 
			//$custBalnAmountInitial = $qc->editCustBalAmtInfo($recipient_date,$receipt_id,$bal_amount,$paid_amount); //inital entery. and new payment details added .
		
		}else{
	 
	$receipt_idDBRR = $qc->addCustReceiptInfo($recipient_date,$recipient_name,$recipient_cont_no,$grand_total,$paid_amount,$bal_amount,$pay_mode,$cheque_no);// insert all data and and return user or recipit id.
	 
	//$custBalnAmountInitial = $qc->addCustBalAmtInfo($recipient_date,$receipt_idDBRR,$bal_amount,$paid_amount); //inital entery, and new payment details added .
		}
	 
	 $countR = $qc->clean($_REQUEST['count']);
	 
	 for($i=0;$i<$countR;$i++){
	 
		$product = $qc->clean($_REQUEST['product'.$i]);
		 $description = $qc->clean($_REQUEST['description'.$i]);
		 $quantity = $qc->clean($_REQUEST['quantity'.$i]);
		 $unitprice = $qc->clean($_REQUEST['unit_price'.$i]);
		 $discount = $qc->clean($_REQUEST['discount'.$i]);
		 $total = $qc->clean($_REQUEST['total'.$i]);
		 $infitycode = $qc->clean($_REQUEST['infitycode'.$i]);
		 
		 /*this all fields use for the editing info */
		 
		 $product_old = $qc->clean($_REQUEST['product_old'.$i]);
		 $old_quantity = $qc->clean($_REQUEST['old_quantity'.$i]);
		 $prod_id = $qc->clean($_REQUEST['prod_id'.$i]);
		
	 
	 if($product!='' && $description!='' && $quantity!='' && $unitprice!='' && $discount!='' && $total!=''){
	 
	
if($receipt_id>0){
	
$qc->infinitySupplierSlodIteamsReturn($product_old,$old_quantity);// this is for the return sold 		

$qc->infinitySupplierSlodIteams($product,$quantity,$infitycode);// this is for the sold 
	
$stock_add = $qc->editCustReceiptProdInfo($receipt_id,$product,$description,$quantity,$unitprice,$discount,$total,$prod_id);

}else{



$stock_add = $qc->addCustReceiptProdInfo($receipt_idDBRR,$product,$description,$quantity,$unitprice,$discount,$total);
	
	$qc->infinitySupplierSlodIteams($product,$quantity,$infitycode);// this is for the sold 
	
	 }	
		}//if end 
	
	 }// for loop end
	
	if($stock_add == true)
	{
		header("Location: receipt_add.php?status=6");
	}
	else
	{
		header("Location: receipt_add.php?status=2");
	}
	
	}


	if($function =='edit_user_receipt')	{
	
	$receipt_id = $qc->clean($_REQUEST['receipt_id']);	
	$prod_id = $qc->clean($_REQUEST['prod_id']);
	
	$receipt_date = $qc->clean($_REQUEST['receipt_date']);
	 
	  $stock_date = explode("/", $receipt_date);
     $recipient_date = $stock_date[2]."-".$stock_date[1]."-".$stock_date[0];
	 
	 $recipient_name = $qc->clean($_REQUEST['recipient_name']);
	 $recipient_cont_no = $qc->clean($_REQUEST['recipient_cont_no']);
	  $grand_total = $qc->clean($_REQUEST['grand_total']);
	 $paid_amount = $qc->clean($_REQUEST['paid_amount']);
	 $bal_amount = $qc->clean($_REQUEST['bal_amount']);
	 
	 
	 $old_quantity = $qc->clean($_REQUEST['old_quantity']);
	 $i_code_old = $qc->clean($_REQUEST['i_code_old']);
	 
	$receipt_idDB = $qc->editCustReceiptInfo($recipient_date,$recipient_name,$recipient_cont_no,$grand_total,$paid_amount,$bal_amount,$receipt_id);
	 
	$custBalnAmountInitial = $qc->addCustBalAmtInfo($recipient_date,$receipt_idDB,$bal_amount,$paid_amount); //inital entery  
	 
		 $product = $qc->clean($_REQUEST['product0']);
		 $description = $qc->clean($_REQUEST['description0']);
		 $quantity = $qc->clean($_REQUEST['quantity0']);
		 $unitprice = $qc->clean($_REQUEST['unit_price0']);
		 $discount = $qc->clean($_REQUEST['discount0']);
		 $total = $qc->clean($_REQUEST['total0']);
		
	 
	 if($product!='' && $description!='' && $quantity!='' && $unitprice!='' && $discount!='' && $total!=''){
$qc->infinitySupplierSlodIteams($product,$quantity);
$qc->editStockInfo($recipient_date,$recipient_name,$recipient_cont_no,$product,$description,$quantity,$total,$sub_total,$discount,$grand_total,$receipt_id);
	
	 }// for loop end
	
	if($stock_add == true)
	{
		header("Location: receipt_add.php?status=6");
	}
	else
	{
		header("Location: receipt_add.php?status=2");
	}
	
	}
	
		
//delete receipt
	
if($function=='delete_receipt'){
	
	$receipt_id =  $qc->clean($_REQUEST['receipt_id']);
	
	 $iso =  $qc->deleteReceiptInfo($receipt_id);
	 $iso =  $qc->deleteReceiptProInfo($receipt_id);
	
	if($iso==true){
		header("Location: cust_personal_acc.php?status=deleted");
	}
	else{
    	header("Location: cust_personal_acc.php?status=not_deleted");
	}
	}// if end 


	
/**~~~~~~~~~~~~~~~~~~~~~~~~~**/
	
if($function=='pya_user_remAmount_permonth'){ 	
		$noticeInfo='';
	$userId = $qc->clean($_REQUEST['userId']);
	
	  
	echo  $noticeInfo = $qc->pyaUserRemAmountPermonth($userId);
	
 
}	

if($function == 'add_user_new_payment'){
	
	$rec_date = $qc->clean($_REQUEST['rec_date']);
	  $paid_date = explode("/", $rec_date);
     $recipient_date = $paid_date[2]."-".$paid_date[1]."-".$paid_date[0];
	
	 $receipt_idDB = $qc->clean($_REQUEST['receipt_id']);
	 $balance_amount = $qc->clean($_REQUEST['balance_amount']);	
	 $paid_amount = $qc->clean($_REQUEST['paid_amount']);
	 $new_pay = $qc->clean($_REQUEST['new_pay']);
	
	if($receipt_idDB!='' && $new_pay!=''){
	
	$newPaid_amount = $paid_amount + $new_pay;
	
	$newbalance_amount = $balance_amount - $new_pay;	 
	  
	$add_userPay = $qc->editNewCustReceiptInfo($newPaid_amount,$newbalance_amount,$receipt_idDB); //inital entery   
	
	 $qc->addCustBalAmtInfo($recipient_date,$receipt_idDB,$newbalance_amount,$new_pay);
	 
	
	if($add_userPay == true)
		{
			header("Location: cust_personal_acc.php?status=6");
		}
		else
		{
			header("Location: cust_personal_acc.php?status=2");
		}
		
		}else{
		
		header("Location: cust_personal_acc.php?status=2");
		
		}
	
	}

if($function=='pya_supplier_remAmount_permonth'){ 	
		
	$suppId = $qc->clean($_REQUEST['suppId']);
	
	  
	echo  $suppInfo = $qc->pyaSupplierRemAmountPermonth($suppId);	
 
}	

if($function=='getvalues_invice'){ 	
		
	$sup_bal_id = $qc->clean($_REQUEST['sup_bal_id']);
	
	  
	echo  $getInviceInfo = $qc->getvaluesInviceInfo($sup_bal_id);
	
 
}

/*====================================================================================================*/	

if($function == 'username_checjinfintycode')	{

	$infitycode =  $qc->clean($_REQUEST['infitycode']);
	
	 $iso = $qc->checkInfifnityCodeInfo($infitycode);
	
	echo  json_encode( $iso);
	}//cearch infinity code.
	
/*---------------------------------------------------------- Customer Product Return ----------------------------------*/

	
	if($function =='cust_prod_return')	{

	$receipt_id = $qc->clean($_REQUEST['receipt_id']);
	$prod_id = $qc->clean($_REQUEST['prod_id']);
	$prod_code = $qc->clean($_REQUEST['prod_code']);
	$prod_quantity = $qc->clean($_REQUEST['prod_quantity']);
	$prod_unit_price = $qc->clean($_REQUEST['prod_unit_price']);
	$prod_discount = $qc->clean($_REQUEST['prod_discount']);
	$total = $qc->clean($_REQUEST['total']);
	
	// Get currect Grand total and paid amount from Customer receipt info table. 
	
	$getCustReceiptInfo = $qc->getCustReceiptInfo($receipt_id);
	
	
	$newGrandTotal = $getCustReceiptInfo[0][4] - $total ;
	//$newPaidAmount = $getCustReceiptInfo[0][5] - $total ; 
	
	
	//if($newPaidAmount <0){
		//$balanceAmount = $getCustReceiptInfo[0][6]; 
		//$newPaidAmount = ($balanceAmount) + ($newPaidAmount);
		//$newBalanceAmount = $balanceAmount - $balanceAmount;
	
		
		//GT= Grand Total PA= Paid Amount BA= Balance Amount 
			$updateNewGTandPAandBA = $qc->updateNewGTandPAandBA($receipt_id,$newGrandTotal,$newPaidAmount,$newBalanceAmount);
	  // This function to update @ infinity_cust_bal_amt_details table
		//	$updateNewPAandBA = $qc->updateNewPAandBA($receipt_id,$newPaidAmount,$newBalanceAmount);
	//}
	
	//GT= Grand Total PA= Paid Amount
	$updateNewGTandPA = $qc->updateNewGTandPA($receipt_id,$newGrandTotal,$newPaidAmount);
	
	// This function to update @ infinity_cust_bal_amt_details table
	
	$updateNewPA = $qc->updateNewPA($receipt_id,$newPaidAmount);
	
	// get current total stock count and product sold count 
	
	$getStockInfo = $qc->getStockInfo($prod_code); // Note here product code as a stock id i.e. primary key of that perticular paroduct
	
	$newProdStock = $getStockInfo[0][7] + $prod_quantity; 
	$newProdSold =  $getStockInfo[0][10] - $prod_quantity; 
	
	// PS= Product Stock SP= Sold Product 	
	$updateNewPSandSP = $qc->updateNewPSandSP($prod_code,$newProdStock,$newProdSold);
	
	// finaly delete the product from receipt. 
	
	$deleteCustReceiptProd = $qc->deleteCustReceiptProd($receipt_id,$prod_id);


	if($deleteCustReceiptProd==true){
		header("Location: cust_personal_acc.php?status=successful");
	}
	else{
    	header("Location: cust_personal_acc.php?status=fail");
	}
	
	}
	/*---------------------------------------------------------- Customer Product Return end ----------------------------------*/
	
	/*---------------------------------------------------------- Suplier Product Return end ----------------------------------*/
	
	
	/*-----------------------------------------------------OLd stock srtat------------------------------------------------------*/
	
	
	
	//add and edit old stock
if($function == 'add_old_stock')	{
	$old_infinity_code =  $qc->clean($_REQUEST['old_infinity_code']);
	$old_sp_amount =  $qc->clean($_REQUEST['old_sp_amount']);

	$sr_noDB = $qc->clean($_REQUEST['sr_noDB']);
	
	if($sr_noDB!=''){
	$iso = $qc->editOldStocknfo($old_infinity_code,$old_sp_amount, $sr_noDB);
	
	}
	else{
	
	$iso = $qc->addOldStockInfo($old_infinity_code,$old_sp_amount);
	}
	if($iso == true)
	{
		header("Location:old_stock.php?status=successful");
	}
	else
	{
		header("Location: old_stock.php?status=fail");
	}
	}//add supplier end
	
	//delete supplier
	
if($function=='delete_old_stock'){
	
	$sr_no =  $qc->clean($_REQUEST['sr_no']);
	
	 $iso =  $qc->deleteOldStockInfo($sr_no);
	
	if($iso==true){
		header("Location: old_stock.php?status=deleted");
	}
	else{
    	header("Location: old_stock.php?status=not_deleted");
	}
	}// if end


/****Old stock****/	

	if($function =='add_oldItemstock')	{
	$stock_id = $qc->clean($_REQUEST['stock_id']);
	 $stockChooseDealer = $qc->clean($_REQUEST['stockChooseDealer']);
	 $stockAddDate1 = $qc->clean($_REQUEST['stockAddDate']);
	 $stock_date = explode("/", $stockAddDate1);
     $stockAddDate = $stock_date[2]."-".$stock_date[1]."-".$stock_date[0];
	 
	 $stockInvoiceNo = $qc->clean($_REQUEST['stockInvoiceNo']);
	 $sup_grand_total = $qc->clean($_REQUEST['sup_grand_total']);
	 $sup_paid_amt = $qc->clean($_REQUEST['sup_paid_amt']);
	 $sup_bal_amt = $qc->clean($_REQUEST['sup_bal_amt']);

	 $pay_mode = $qc->clean($_REQUEST['pay_mode']);
	 $cheque_no = $qc->clean($_REQUEST['cheque_no']);
	 
	 $supBalnAmountInitial = $qc->addSupBalAmtInfo($stockChooseDealer,$stockAddDate,$stockInvoiceNo,$sup_grand_total,$sup_paid_amt,$sup_bal_amt,$pay_mode,$cheque_no); //inital entery 
	 
	 $countR = $qc->clean($_REQUEST['count']);
	 for($i=0;$i<$countR;$i++){
	 
		 $stockDealerCode = $qc->clean($_REQUEST['stockDealerCode'.$i]);
		 $stockInfinityCode = $qc->clean($_REQUEST['stockInfinityCode'.$i]);
		 $stockDescriptions = $qc->clean($_REQUEST['stockDescriptions'.$i]);		
		 $stockQuantity = $qc->clean($_REQUEST['stockQuantity'.$i]);
		 $stockUnitPriceDealer = $qc->clean($_REQUEST['stockUnitPriceDealer'.$i]);
		 $stockUnitPrice = $qc->clean($_REQUEST['stockUnitPrice'.$i]);
		 $stockAmount = $qc->clean($_REQUEST['stockAmount'.$i]);
		 $flag = $qc->clean($_REQUEST['flag'.$i]);
	 
	 if($stockDealerCode!='' && $stockInfinityCode!='' && $stockQuantity!='' && $stockUnitPrice!=''){
if($stock_id!=''){

$stock_add = $qc->editStockInfo($stockChooseDealer,$stockAddDate,$stockInvoiceNo,$stockDealerCode,$stockInfinityCode,$stockDescriptions,$stockQuantity,$stockUnitPriceDealer,$stockUnitPrice,$stockAmount,$stock_id);

}else{
	if($flag==2){

		$stock_add = $qc->addOldSoldStockInfo($stockChooseDealer,$stockAddDate,$stockInvoiceNo,$stockDealerCode,$stockInfinityCode,$stockDescriptions,$stockQuantity,$stockUnitPriceDealer,$stockUnitPrice,$stockAmount,$flag);

	}else{

$qc->oldStockInfoFlag($stockInfinityCode,1);
		
$stock_add = $qc->addStockInfo($stockChooseDealer,$stockAddDate,$stockInvoiceNo,$stockDealerCode,$stockInfinityCode,$stockDescriptions,$stockQuantity,$stockUnitPriceDealer,$stockUnitPrice,$stockAmount,$flag);
	


	 }
	 }	
		}//if end 
	
	 }// for loop end
	
	if($stock_add == true)
	{
		header("Location: old_stock_add.php?status=6");
	}
	else
	{
		header("Location: old_stock_add.php?status=2");
	}
	

	}//if end





	if($function == 'add_user_new_payment_newchanges'){
	
	$rec_date = $qc->clean($_REQUEST['rec_date']);
	  $paid_date = explode("/", $rec_date);
     $recipient_date = $paid_date[2]."-".$paid_date[1]."-".$paid_date[0];
	
	$rec_name = $qc->clean($_REQUEST['rec_name']);
	
	$new_pay = $qc->clean($_REQUEST['new_pay']);
	$pay_mode = $qc->clean($_REQUEST['pay_mode']);
	$cheque_no = $qc->clean($_REQUEST['cheque_no']);


	if($rec_name!='' && $new_pay!=''){
	
		$userPaymentbyname = $qc->getDistinctCustRecInfoForPayments($rec_name);                 
		
		for($i=0;$i<count($userPaymentbyname);$i++){

			  		if($userPaymentbyname[$i][6]<0){
					
					$receipt_idDB = $userPaymentbyname[$i][0];
					
					$newbalance_amount = $userPaymentbyname[$i][6]-$new_pay;
					
					$add_userPay = $qc->editNewCustReceiptInfoIfminus($newbalance_amount,$receipt_idDB); //inital entery 
					
					if($add_userPay == true)
		{
			header("Location: cust_personal_acc.php?status=6");
		}
		else
		{
			header("Location: cust_personal_acc.php?status=2");
		}
	
					
					
					}

			  		if($userPaymentbyname[$i][6]>0 && $userPaymentbyname[$i][6]>=$new_pay){

			  		$receipt_idDB = $userPaymentbyname[$i][0];
			  			
			  		$lastBal = $userPaymentbyname[$i][6]-$new_pay;
			  		
			  		$newPaid_amount = $userPaymentbyname[$i][5] + $new_pay;
			  		$newbalance_amount = $lastBal;

			  		$new_pay = 0;

			  		if($userPaymentbyname[$i][7]!=''){

			  				$paymode = $userPaymentbyname[$i][7].", ".$pay_mode;
			  		}else{

			  				$paymode = $pay_mode;

			  		}

			  		if($userPaymentbyname[$i][8]!=''){

			  				$chequeno = $userPaymentbyname[$i][8].", ".$cheque_no;
			  		}else{

			  				$chequeno = $cheque_no;

			  		}

			  		$add_userPay = $qc->editNewCustReceiptInfo($newPaid_amount,$newbalance_amount,$receipt_idDB,$paymode,$chequeno); //inital entery 
			  		//breack;

			  		}else{
			  		if($userPaymentbyname[$i][6]>0){
			  		$receipt_idDB = $userPaymentbyname[$i][0];

			  		$lastBal1 = $new_pay - $userPaymentbyname[$i][6];
			  		$newPaid_amount = $userPaymentbyname[$i][5] + $new_pay;
			  		$newbalance_amount = $lastBal1;	

			  		if($userPaymentbyname[$i][7]!=''){

			  				$paymode = $userPaymentbyname[$i][7].", ".$pay_mode;
			  		}else{

			  				$paymode = $pay_mode;

			  		}

			  		if($userPaymentbyname[$i][8]!=''){

			  				$chequeno = $userPaymentbyname[$i][8].", ".$cheque_no;
			  		}else{

			  				$chequeno = $cheque_no;

			  		}

			  		$add_userPay = $qc->editNewCustReceiptInfo($newPaid_amount,$newbalance_amount,$receipt_idDB,$paymode,$chequeno);

			  		$new_pay = $lastBal1;
			  	}
			  		}//else end


			  }

		
		}

		if($add_userPay == true)
		{
			header("Location: cust_personal_acc.php?status=6");
		}
		else
		{
			header("Location: cust_personal_acc.php?status=2");
		}
	
	}





	if($function == 'add_supl_newpaymentNEW'){
	
	$invo_date = $qc->clean($_REQUEST['invo_date']);
	$paid_date = explode("/", $invo_date);
    $installment_date = $paid_date[2]."-".$paid_date[1]."-".$paid_date[0];
	
	$invo_new_pay = $qc->clean($_REQUEST['invo_new_pay']);
	$supplier_name = $qc->clean($_REQUEST['supplier_name']);
	$pay_mode = $qc->clean($_REQUEST['pay_mode']);
	$cheque_no = $qc->clean($_REQUEST['cheque_no']); 	

		$supplier_info = $qc->calculationSupplierInfo($supplier_name);

		$sup_id = $supplier_info[0][0];


	
	if($invo_new_pay!='' && $supplier_name!='' && $sup_id!=''){

		$supplierTotalAmountInfo = $qc->getSupplierInvoiceInfo($sup_id);

		for($i=0; $i<count($supplierTotalAmountInfo);$i++){
		
		

if($supplierTotalAmountInfo[$i][6]>0 && $supplierTotalAmountInfo[$i][6]>=$invo_new_pay){

	$invoice_code = $supplierTotalAmountInfo[$i][3];		  		
			  			
			  		$lastBal = $supplierTotalAmountInfo[$i][6]-$invo_new_pay;
			  		
			  		$newPaid_amount = $supplierTotalAmountInfo[$i][5] + $invo_new_pay;
			  		$newbalance_amount = $lastBal;

			  		$invo_new_pay = 0;
			  		if($supplierTotalAmountInfo[$i][7]!=''){

			  			$paymode = $supplierTotalAmountInfo[$i][7].", ".$pay_mode;

			  		}else{

			  			$paymode = $pay_mode;
			  		}

			  		if($supplierTotalAmountInfo[$i][8]!=''){

			  			$ChequeNo = $supplierTotalAmountInfo[$i][8].", ".$cheque_no;

			  		}else{

			  			$ChequeNo = $cheque_no;
			  		}

			  		$add_userPay = $qc->editNewSupInvoiceInfoNewCal($newPaid_amount,$newbalance_amount,$sup_id,$invoice_code,$paymode,$ChequeNo); //inital entery 
			  		

			  		}else{
			  		if($supplierTotalAmountInfo[$i][6]>0){

			  		$invoice_code = $supplierTotalAmountInfo[$i][3];

			  		$lastBal1 = $invo_new_pay - $supplierTotalAmountInfo[$i][6];
			  		$newPaid_amount = $supplierTotalAmountInfo[$i][5] + $supplierTotalAmountInfo[$i][6];
					if($supplierTotalAmountInfo[$i][4]==$newPaid_amount){						
						$invo_new_pay =0;						
					}else{
			  		$invo_new_pay = $lastBal1;	
					}
			  		if($supplierTotalAmountInfo[$i][7]!=''){

			  			$paymode = $supplierTotalAmountInfo[$i][7].", ".$pay_mode;

			  		}else{

			  			$paymode = $pay_mode;
			  		}

			  		if($supplierTotalAmountInfo[$i][8]!=''){

			  			$ChequeNo = $supplierTotalAmountInfo[$i][8].", ".$cheque_no;

			  		}else{

			  			$ChequeNo = $cheque_no;
			  		}

			  		$add_userPay = $qc->editNewSupInvoiceInfoNewCal($newPaid_amount,$invo_new_pay,$sup_id,$invoice_code,$paymode,$ChequeNo); //inital entery 

			  		

			  		$invo_new_pay = $lastBal1;
			  	}
			  		}//else end



		}
	
	 
		
	 if($add_userPay == true){
			header("Location: dealer_finances.php?status=6");
		}else{
			header("Location: dealer_finances.php?status=2");
 	}
		
 	}else{
		
		header("Location:dealer_finances.php?status=2");
		
	 	} 
	
	}


	if($function == 'oldStockInfo')	{

	$infitycode =  $qc->clean($_REQUEST['infitycode']);
	
	 $iso = $qc->checkInfifnityOldStockCodeInfo($infitycode);
	
	echo  json_encode( $iso);
	}//cearch infinity code.oldStockInfo
	
	
	?>
