<?php
 include_once('auth.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Infinity by Ruchi | Receipt View</title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet" />
<link href="css/style.css" type="text/css" rel="stylesheet" />
<link href="css/menu.css" type="text/css" rel="stylesheet" />
<script src="js/menu_script.js" type="text/javascript"></script>
<script src="js/jquery-1.9.1.min.js" type="text/javascript"></script>
<link rel="stylesheet" href="css/jquery-ui.css">
<script src="js/jquery-1.10.2.js"></script>
<script src="js/jquery-ui.js"></script>
<script>
$(function() {
    $( "#datepicker" ).datepicker();
      $( "#datepicker" ).datepicker("setDate", new Date());
	  
  });
 function chooseIcode(){


var code = $('#i_code0').val();
//alert(code);
if(code!='')
{
   <?php 
 
	  $stockInfo = $qc->getStockInfo('','','');
	  for($i=0;$i<count($stockInfo); $i++){
	  ?>
	  var newcode = "<?php echo $stockInfo[$i][0];?>";
	  if(code == newcode){
	  $('#show_unitprice0').val(<?php echo $stockInfo[$i][8];?>);
	  $('#i_code0').css("border-color","black"); 
	  }
	 <?php  }
	  ?>
    }else{
	
	$('#i_code0').css("border-color","red");
	
	}
	
	//}//this for loop check mycout

}
</script>
</head>
<body>
<!-- wrapper start-->
<div class="esya_wrapper">
  <!-- main container-->
  <div class="container">
    <!--herader container -->
    <?php include_once('header.php'); ?>
    <!--header container end-->
    <!--menu container-->
    <div class="menu_container">
      <?php include_once('menu.php'); ?>
    </div>
    <!--menu container end-->
    
    <!--middle container start -->
    
    <div class="middle_container">
    <?php   
	$user_name = $qc->clean($_REQUEST['user_name']);
	$total_amount = $qc->clean($_REQUEST['total_amount']);
	?>

      <div class="middle_header" style="margin-top: 20px;"><div class="col-md-6">Name:&nbsp;<?php echo $user_name ;?></div><div class="col-md-6">Total Amt.:&nbsp;<?php echo $total_amount;?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="cust_personal_acc.php"><span style="margin-left:120px;color:#FFFFFF;">Back</span></a></div></div>
      <div class="view_dealer">
        <table align="center" width="100%" class="ov_table">
          <tr style="background: rgb(241, 241, 241) none repeat scroll 0% 0%;">
          <td><span>Sr. No.</span></td>
            <td><span>Rec. No.</span></td>
            <td><span>Date</span></td>        
             <td><span>Amount</span></td>
             <td><span>Print</span></td>
             <td><span>View</span></td>
             <td><span></span></td>
          </tr>
       <?php 
	   $user_name = $qc->clean($_REQUEST['user_name']);
	   if($user_name!=''){
	  $userNameAndinfo = $qc->getDistinctCustRecInfoForPerticularTotal($user_name);
	  for($i=0; $i<count($userNameAndinfo);$i++){
	   ?>
          <tr class="recordBox">
           <td><?php echo $i+1;?></td>
           <td><?php echo $userNameAndinfo[$i][0];?></td>
            <td><?php echo $userNameAndinfo[$i][2];?></td>
            <td><?php echo $userNameAndinfo[$i][4];?></td>
             <td><a href="receipt_infinity.php?receipt_id=<?php echo $userNameAndinfo[$i][0];?>" target="_blank"><img src="images/print.png" /></a></td>
             <td><a href="single_receipt_view.php?receipt_id=<?php echo $userNameAndinfo[$i][0];?>&amount=<?php echo $userNameAndinfo[$i][4];?>&total_amount=<?php echo $total_amount;?>&user_name=<?php echo $user_name ;?>"><img src="images/view.png" /></a></td>
             <td><a href="query.php?function=delete_receipt&receipt_id=<?php echo $userNameAndinfo[$i][0];?>"onclick="return confirm('Are you sure you want to Delete?')"><img src="images/delete.png" /></a></td>
                      
          </tr>
  <?php }}?>
        </table>
      </div>
    </div>
    <!--middle container end-->
  </div>
  <!--main container end-->
</div>
</div>
<!--wrapper end-->
</body>
</html>
