<?php 
require_once('conn_obj.php');

class queryClass{

	function queryClass(){}
	
	//Function to sanitize values received from the form. Prevents SQL injection
	function clean($str) 
	{
	global $con;
		$str = @trim($str);
		if(get_magic_quotes_gpc()) {
			$str = stripslashes($str);
		}
		return mysqli_real_escape_string($con,$str);
	}

//chang password
function change_password($id,$password_new,$old_password,$new_user_name,$old_user_name){
	global $con;
		try{
			$query_log="SELECT password, username FROM admin WHERE sr_no='$id'";
			$rs_log= mysqli_query($con,$query_log) or die(mysqli_error($con));
			if($ru_log=mysqli_fetch_assoc($rs_log)) 
			{
				$password = $ru_log['password'];
				$username = $ru_log['username'];
			}	
			
		  if($old_password==$password){
			$sql_login =  "UPDATE admin SET password='$password_new' , username ='$new_user_name' WHERE sr_no='$id'";
			$rs_login  = mysqli_query($con,$sql_login) or die(mysqli_error($con));
					
			if($rs_login){    
				return 1;
			}
			else{
				return 2;
			}
		  }
		  else{
		  	return 3;
		  }
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs_log);
		mysqli_close($rs_login);
		mysqli_close($con);
		//}		
	} //change_password

/*--***********************************-Supplier Info-*****************************************/
// Get Supplier
function getSupplierInfo($sup_id){
	global $con;
		try{ 
			if($sup_id!=''){
			
				$s =" WHERE sup_id='$sup_id'";
			}
			 
			$sql = "SELECT * FROM  infinity_supplier_info".$s; 	
			 $rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
			 $i=0;
			 while($row = mysqli_fetch_array($rs)){
                 $supplierInfo[$i][0] = $row['sup_id'];
                 $supplierInfo[$i][1] = $row['sup_name'];
				 $supplierInfo[$i][2] = $row['contact_no'];				 
				 $supplierInfo[$i][3] = $row['email_id'];
			     $supplierInfo[$i][4] = $row['address'];
			 	 $supplierInfo[$i][5] = $row['mobile_no'];			    
			     $i++;
	
			}
			return $supplierInfo;	
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}
	//
	
	function getSupplierByNameInfo($search){
	global $con;
		try{ 			
			 
			$sql = "SELECT * FROM  infinity_supplier_info WHERE sup_name LIKE  \"%$search%\"  OR contact_no LIKE  \"%$search%\"  "; 	
			 $rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
			 $i=0;
			 while($row = mysqli_fetch_array($rs)){
                 $supplierInfo[$i][0] = $row['sup_id'];
                 $supplierInfo[$i][1] = $row['sup_name'];
				 $supplierInfo[$i][2] = $row['contact_no'];				 
				 $supplierInfo[$i][3] = $row['email_id'];
			     $supplierInfo[$i][4] = $row['address'];
			 	 $supplierInfo[$i][5] = $row['mobile_no'];			    
			     $i++;
	
			}
			return $supplierInfo;	
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}

//

	function getSupplierInvoiceInfo($sup_id){
	global $con;
		try{ 			
			 	if($sup_id!=''){
			
				$s =" WHERE sup_id='$sup_id'";
			}
			$sql = "SELECT * FROM  infinity_sup_bal_amt_details". $s; 	
			 $rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
			 $i=0;
			 while($row = mysqli_fetch_array($rs)){
                 $supplierInvoiceInfo[$i][0] = $row['sup_bal_id'];
             	 $supplierInvoiceInfo[$i][1] = $row['sup_id'];
				 $supplierInvoiceInfo[$i][2] = $row['date'];
				 $supplierInvoiceInfo[$i][3] = $row['invoice_no'];
				 $supplierInvoiceInfo[$i][4] = $row['sup_grand_total'];	
				 $supplierInvoiceInfo[$i][5] = $row['sup_paid_amount'];
				 $supplierInvoiceInfo[$i][6] = $row['sup_bal_amount'];
			     $supplierInvoiceInfo[$i][7] = $row['pay_mode'];
				 $supplierInvoiceInfo[$i][8] = $row['cheque_no'];
			     $i++;
	
			}
			return $supplierInvoiceInfo;	
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}



//get Supplier total balance amount 

function supBalAmtInfo($sup_id){
	global $con;               
		try{ 	 			 	
	
		$sql = "SELECT SUM(sup_grand_total) AS sup_grand_total, SUM(sup_paid_amount) AS sup_paid_amount, SUM(sup_bal_amount) AS sup_bal_amount FROM infinity_sup_bal_amt_details WHERE sup_id= '$sup_id'"; 	
		$rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
		
 		
			 if($row = mysqli_fetch_array($rs)){
                 $supBalInfo[0][0] = $row['sup_grand_total'];
				 $supBalInfo[0][1] = $row['sup_paid_amount'];
                 $supBalInfo[0][2] = $row['sup_bal_amount'];
				 
				 		    
			     $i++;
	
			}
			return $supBalInfo;	
		
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}	
	
function supBalAmtFinancesInfo($sup_id){
	global $con;               
		try{ 	 			 	
	
		$sql = "SELECT SUM(sup_grand_total) AS sup_grand_total, SUM(sup_paid_amount) AS sup_paid_amount, SUM(sup_bal_amount) AS sup_bal_amount FROM infinity_sup_bal_amt_details WHERE sup_id= '$sup_id'  ORDER BY  sup_bal_amount DESC"; 	
		$rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
		
 		
			 if($row = mysqli_fetch_array($rs)){
                 $supBalInfo[0][0] = $row['sup_grand_total'];
				 $supBalInfo[0][1] = $row['sup_paid_amount'];				 
                 $supBalInfo[0][2] = $row['sup_bal_amount'];		    
			     $i++;
	
			}
			return $supBalInfo;	
		
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}		
	
	
//add supplier
function addSupplierInfo($name,$contact_no,$mobile_no,$email_id,$address){
	global $con;
		try{	 
			$sql=  "INSERT INTO infinity_supplier_info (sup_name,contact_no,mobile_no,email_id,address,added_date) VALUES('$name','$contact_no','$mobile_no','$email_id','$address',NOW())";
			
			$rs = mysqli_query($con,$sql) or die( mysqli_error($con));
			if($rs){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}
	
	
	//add supplier balance amount 
function addSupBalAmtInfo($stockChooseDealer,$stockAddDate,$stockInvoiceNo,$sup_grand_total,$sup_paid_amt,$sup_bal_amt,$pay_mode,$cheque_no){
	global $con;
		try{	 
			$sql=  "INSERT INTO infinity_sup_bal_amt_details (sup_id,date,invoice_no,sup_grand_total,sup_paid_amount,sup_bal_amount,added_date,pay_mode,cheque_no) 
													   VALUES('$stockChooseDealer','$stockAddDate','$stockInvoiceNo','$sup_grand_total','$sup_paid_amt','$sup_bal_amt',NOW(),'$pay_mode','$cheque_no')";
			
			$rs = mysqli_query($con,$sql) or die( mysqli_error($con));
			if($rs){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}
function editSupBalAmtInfo($sup_id,$date,$invoice_no,$sup_grand_total,$sup_paid_amount,$sup_bal_amount,$pay_mode,$cheque_no){
global $con;
		try{	 
			$sqlInter =  "UPDATE infinity_sup_bal_amt_details SET sup_id = '$sup_id', date = '$date', invoice_no = '$invoice_no' , sup_grand_total = '$sup_grand_total', sup_paid_amount = '$sup_paid_amount', sup_bal_amount='$sup_bal_amount', added_date=NOW() WHERE invoice_no = '$invoice_no' ";
			//echo $sql_photos;
			$rsInt = mysqli_query($con,$sqlInter) or die( mysqli_error($con));
			if($rsInt){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsInt);
	mysqli_connect($con);

}	


function editByMoreItemSupBalAmtInfo($sup_id,$date,$invoice_no,$sup_grand_total,$sup_paid_amount,$sup_bal_amount,$pay_mode,$cheque_no){
global $con;
		try{	 
			$sqlInter =  "UPDATE infinity_sup_bal_amt_details SET sup_id = '$sup_id', date = '$date', invoice_no = '$invoice_no' , sup_grand_total = '$sup_grand_total', sup_paid_amount = '$sup_paid_amount', sup_bal_amount='$sup_bal_amount', pay_mode='$pay_mode' , cheque_no='$cheque_no',  added_date=NOW() WHERE invoice_no = '$invoice_no' ";
			//echo $sql_photos;
			$rsInt = mysqli_query($con,$sqlInter) or die( mysqli_error($con));
			if($rsInt){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsInt);
	mysqli_connect($con);

}	
//edit Supplier

function editSupplierInfo($name,$contact_no,$mobile_no,$email_id,$address,$sup_idDB){
global $con;
		try{	 
			$sqlInter =  "UPDATE infinity_supplier_info SET sup_name = '$name', contact_no = '$contact_no', mobile_no = '$mobile_no' , email_id = '$email_id', address = '$address' WHERE sup_id = '$sup_idDB' ";
			//echo $sql_photos;
			$rsInt = mysqli_query($con,$sqlInter) or die( mysqli_error($con));
			if($rsInt){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsInt);
	mysqli_connect($con);

}

//delete Supplier
function deleteSupplierInfo($sup_id){
	global $con;
		try{	 
			$sqlDel=  "DELETE FROM infinity_supplier_info WHERE sup_id='$sup_id'";
			
			$rsDel = mysqli_query($con,$sqlDel) or die( mysqli_error($con));
			if($rsDel){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsDel);
		mysqli_close($con);
	}

/*--***********************************-Customer Info-*****************************************/
// Get Customer Info
function getCustomerInfo($cust_id){
	global $con;
		try{ 
			if($cust_id!=''){
			
				$s =" WHERE cust_id='$cust_id'";
			}
			 
			$sql = "SELECT * FROM  infinity_customer_info".$s; 	
			 $rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
			 $i=0;
			 while($row = mysqli_fetch_array($rs)){
                 $customerInfo[$i][0] = $row['cust_id'];
                 $customerInfo[$i][1] = $row['cust_name'];
				 $customerInfo[$i][2] = $row['cust_contact'];
				 $customerInfo[$i][3] = $row['cust_address'];
				 $customerInfo[$i][4] = $row['tuks_pant'];
			     $customerInfo[$i][5] = $row['body_length'];
			     $customerInfo[$i][6] = $row['full_length'];			 
			     $customerInfo[$i][7] = $row['chest'];
			     $customerInfo[$i][8] = $row['upper_chest'];
				 $customerInfo[$i][9] = $row['waist'];		 
				 $customerInfo[$i][10] = $row['hips'];
				 $customerInfo[$i][11] = $row['shoulder'];		 
				 $customerInfo[$i][12] = $row['cross_front'];
				 $customerInfo[$i][13] = $row['arm_hole'];		 
				 $customerInfo[$i][14] = $row['sleeve'];
				 $customerInfo[$i][15] = $row['front_neck'];
				 $customerInfo[$i][16] = $row['back_neck'];	 
				 $customerInfo[$i][17] = $row['churidar'];	
				 $customerInfo[$i][18] = $row['pant'];	
					 	 			    
			     $i++;
	
			}
			return $customerInfo;	
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}

function getCustomerInfoSearch($name){
	global $con;
		try{ 
						 
			$sql = "SELECT * FROM  infinity_customer_info WHERE cust_name='$name'"; 	
			 $rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
			 $i=0;
			 while($row = mysqli_fetch_array($rs)){
                 $customerInfo[$i][0] = $row['cust_id'];
                 $customerInfo[$i][1] = $row['cust_name'];
				 $customerInfo[$i][2] = $row['cust_contact'];
				 $customerInfo[$i][3] = $row['cust_address'];
				 $customerInfo[$i][4] = $row['tuks_pant'];
			     $customerInfo[$i][5] = $row['body_length'];
			     $customerInfo[$i][6] = $row['full_length'];			 
			     $customerInfo[$i][7] = $row['chest'];
			     $customerInfo[$i][8] = $row['upper_chest'];
				 $customerInfo[$i][9] = $row['waist'];		 
				 $customerInfo[$i][10] = $row['hips'];
				 $customerInfo[$i][11] = $row['shoulder'];		 
				 $customerInfo[$i][12] = $row['cross_front'];
				 $customerInfo[$i][13] = $row['arm_hole'];		 
				 $customerInfo[$i][14] = $row['sleeve'];
				 $customerInfo[$i][15] = $row['front_neck'];
				 $customerInfo[$i][16] = $row['back_neck'];	 
				 $customerInfo[$i][17] = $row['churidar'];	
				 $customerInfo[$i][18] = $row['pant'];	
					 	 			    
			     $i++;
	
			}
			return $customerInfo;	
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}
	
//add Customer
function addCustomerInfo($name,$contact_no,$address,$tuks_pant,$body_length,$full_length,$chest,$upper_chest,$waist,$hips,$shoulder,$cross_front,$arm_hole,$sleeve,$front_neck,$back_neck,$churidar,$pant){
	global $con;
		try{	 
			$sql=  "INSERT INTO infinity_customer_info (cust_name,cust_contact,cust_address,tuks_pant,body_length,full_length,chest,upper_chest,waist,hips,shoulder,	cross_front,arm_hole,sleeve,front_neck,back_neck,churidar,pant,added_date) VALUES('$name','$contact_no','$address','$tuks_pant','$body_length','$full_length','$chest','$upper_chest','$waist','$hips','$shoulder','$cross_front','$arm_hole','$sleeve','$front_neck','$back_neck','$churidar','$pant',NOW())";
			
			$rs = mysqli_query($con,$sql) or die( mysqli_error($con));
			if($rs){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}
	
//edit Supplier

function editCustomerInfo($name,$contact_no,$address,$tuks_pant,$body_length,$full_length,$chest,$upper_chest,$waist,$hips,$shoulder,$cross_front,$arm_hole,$sleeve,$front_neck,$back_neck,$churidar,$pant,$cust_idDB){
global $con;
		try{	 
			$sqlInter =  "UPDATE infinity_customer_info SET cust_name='$name', cust_contact='$contact_no', cust_address='$address', tuks_pant='$tuks_pant', body_length='$body_length', full_length='$full_length', chest='$chest', upper_chest='$upper_chest', waist='$waist', hips='$hips', shoulder='$shoulder', cross_front='$cross_front', arm_hole='$arm_hole', sleeve='$sleeve', front_neck='$front_neck', back_neck='$back_neck', churidar='$churidar', pant='$pant' WHERE cust_id ='$cust_idDB'";
			//echo $sql_photos;
			$rsInt = mysqli_query($con,$sqlInter) or die( mysqli_error($con));
			if($rsInt){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsInt);
	mysqli_connect($con);

}

//delete Supplier
function deleteCustomernfo($cust_id){
	global $con;
		try{	 
			$sqlDel=  "DELETE FROM infinity_customer_info WHERE cust_id='$cust_id'";
			
			$rsDel = mysqli_query($con,$sqlDel) or die( mysqli_error($con));
			if($rsDel){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsDel);
		mysqli_close($con);
	}

/************************************-Stock Info-*****************************************/

// Get Stock Info
function getStockInfo($stock_id, $choose_dealer,$date_filter){
	global $con;
		try{ 
			if($stock_id!=''){
			
				$s =" WHERE stock_id='$stock_id'";
			}
			 if($choose_dealer!=''){
			
				$s =" WHERE sup_id='$choose_dealer'";
			}
			 if($date_filter!=''){
			
				$a =" AND date='$date_filter'";
			}
			$sql = "SELECT * FROM  infinity_stock_info".$s.$a." ORDER BY stock_id ASC "; 	
			 $rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
			 $i=0;
			 while($row = mysqli_fetch_array($rs)){
                 $stockInfo[$i][0] = $row['stock_id'];
                 $stockInfo[$i][1] = $row['sup_id'];
				 $stockInfo[$i][2] = $row['date'];
				 $stockInfo[$i][3] = $row['invoice_no'];
			     $stockInfo[$i][4] = $row['d_code'];
				 $stockInfo[$i][5] = $row['i_code'];
				 $stockInfo[$i][6] = $row['description'];
				 $stockInfo[$i][7] = $row['quantity'];
				 $stockInfo[$i][8] = $row['unit_price'];   // i.e. SP amount
				 $stockInfo[$i][9] = $row['amount'];
				 $stockInfo[$i][10] = $row['sold_quantity'];
				 $stockInfo[$i][11] = $row['unit_price_dealer'];  // i.e. CP amount
				 $stockInfo[$i][12] = $row['flag'];
				 
			 	 			    
			     $i++;
	
			}
			return $stockInfo;	
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}
	
	
function getStockInfoHome(){
	global $con;
		try{ 
			
			$sql = "SELECT * FROM  infinity_stock_info WHERE quantity='1' ORDER BY stock_id DESC "; 	
			 $rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
			 $i=0;
			 while($row = mysqli_fetch_array($rs)){
                 $stockInfo[$i][0] = $row['stock_id'];
                 $stockInfo[$i][1] = $row['sup_id'];
				 $stockInfo[$i][2] = $row['date'];
				 $stockInfo[$i][3] = $row['invoice_no'];
			     $stockInfo[$i][4] = $row['d_code'];
				 $stockInfo[$i][5] = $row['i_code'];
				 $stockInfo[$i][6] = $row['description'];
				 $stockInfo[$i][7] = $row['quantity'];
				 $stockInfo[$i][8] = $row['unit_price'];   // i.e. SP amount
				 $stockInfo[$i][9] = $row['amount'];
				 $stockInfo[$i][10] = $row['sold_quantity'];
				 $stockInfo[$i][11] = $row['unit_price_dealer'];  // i.e. CP amount
				 $stockInfo[$i][12] = $row['flag'];
				 
			 	 			    
			     $i++;
	
			}
			return $stockInfo;	
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}	
	
	
	
	
// Get  invoice wise Stock Info
function getInvoiceStockInfo($invoice_no){
	global $con;
		try{ 
			if($invoice_no!=''){
			
				$s =" WHERE invoice_no='$invoice_no' ";
			}
	
			$sql = "SELECT * FROM  infinity_stock_info".$s; 	
			 $rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
			 $i=0;
			 while($row = mysqli_fetch_array($rs)){
            
			     $InvoiceStockInfo[$i][0] = $row['d_code'];			
				 $InvoiceStockInfo[$i][1] = $row['description'];
				 $InvoiceStockInfo[$i][2] = $row['quantity'];			
				 $InvoiceStockInfo[$i][3] = $row['unit_price_dealer'];
				 $InvoiceStockInfo[$i][4] = $row['stock_id'];
				 $InvoiceStockInfo[$i][5] = $row['sup_id'];
				 $InvoiceStockInfo[$i][6] = $row['invoice_no'];
				 $InvoiceStockInfo[$i][7] = $row['sold_quantity'];
				 $InvoiceStockInfo[$i][8] = $row['amount'];

				 
			 	 			    
			     $i++;
	
			}
			return $InvoiceStockInfo;	
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}
	
	
//add stock 
function addStockInfo($stockChooseDealer,$stockAddDate,$stockInvoiceNo,$stockDealerCode,$stockInfinityCode,$stockDescriptions,$stockQuantity,$stockUnitPriceDealer,$stockUnitPrice,$stockAmount,$flag){
	global $con;
		try{	 
			$sql=  "INSERT INTO infinity_stock_info (sup_id,date,invoice_no,d_code,i_code,description,quantity,unit_price_dealer,unit_price,amount,added_date,flag) VALUES('$stockChooseDealer','$stockAddDate','$stockInvoiceNo','$stockDealerCode','$stockInfinityCode','$stockDescriptions','$stockQuantity','$stockUnitPriceDealer','$stockUnitPrice','$stockAmount',NOW(),'$flag')";
			
			$rs = mysqli_query($con,$sql) or die( mysqli_error($con));
			if($rs){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}
// ................................. insert old stock to new stock ..........................	
	//add stock 
/*function addOldToStockInfo($i_code,$sp_amount){
	global $con;
		try{	 
			$sql=  "INSERT INTO infinity_stock_info (i_code,description,quantity,sold_quantity,unit_price,added_date,flag) VALUES('$i_code','$i_code','1','0','$sp_amount',NOW(),'1')";
			
			$rs = mysqli_query($con,$sql) or die( mysqli_error($con));
			if($rs){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}*/
//........................................................... trigger event end ............................................//	
	
/*//get total new stock i.e. add stock only

function stockInOutInfo($sup_id){
	global $con;               
		try{ 	 			 	
	
		$sql = "SELECT SUM(quantity) AS quantity, SUM(sold_quantity) AS sold_quantity, invoice_no FROM infinity_stock_info WHERE sup_id= '$sup_id' AND 	flag = '0'"; 	
		$rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
		
 		
			 if($row = mysqli_fetch_array($rs)){
                 $totalInOutStockInfo[0][0] = $row['quantity'];
                 $totalInOutStockInfo[0][1] = $row['sold_quantity'];
				  
						    
			     $i++;
	
			}
			return $totalInOutStockInfo;	
		
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}	
	*/
	
	// get all stock i.e. OLD + NEW
	
	function stockInOutInfo($sup_id){
	global $con;               
		try{ 	 			 	
	
		$sql = "SELECT SUM(quantity) AS quantity, SUM(sold_quantity) AS sold_quantity, invoice_no FROM infinity_stock_info WHERE sup_id= '$sup_id' "; 	
		$rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
		
 		
			 if($row = mysqli_fetch_array($rs)){
                 $totalInOutStockInfo[0][0] = $row['quantity'];
                 $totalInOutStockInfo[0][1] = $row['sold_quantity'];
				  
						    
			     $i++;
	
			}
			return $totalInOutStockInfo;	
		
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}	
	


function stockInOutInfoPerInvoice($sup_id,$invoice_no){
	global $con;               
		try{ 	 			 	
	
		$sql = "SELECT SUM(quantity) AS quantity, SUM(sold_quantity) AS sold_quantity, invoice_no FROM infinity_stock_info WHERE sup_id= '$sup_id' AND invoice_no='$invoice_no' "; 	
		$rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
		
 		
			 if($row = mysqli_fetch_array($rs)){
                 $totalInOutStockInfo[0][0] = $row['quantity'];
                 $totalInOutStockInfo[0][1] = $row['sold_quantity'];
				  
						    
			     $i++;
	
			}
			return $totalInOutStockInfo;	
		
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}


	
//edit Stock

function editStockInfo($stockChooseDealer,$stockAddDate,$stockInvoiceNo,$stockDealerCode,$stockInfinityCode,$stockDescriptions,$stockQuantity,$stockUnitPriceDealer,$stockUnitPrice,$stockAmount,$stock_id){
global $con;
		try{	 
			$sqlInter =  "UPDATE infinity_stock_info SET sup_id='$stockChooseDealer', date='$stockAddDate', invoice_no='$stockInvoiceNo', d_code='$stockDealerCode', 	i_code='$stockInfinityCode', description='$stockDescriptions', quantity='$stockQuantity', unit_price_dealer='$stockUnitPriceDealer', unit_price='$stockUnitPrice', amount='$stockAmount' WHERE stock_id ='$stock_id'";
			//echo $sql_photos;
			$rsInt = mysqli_query($con,$sqlInter) or die( mysqli_error($con));
			if($rsInt){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsInt);
	mysqli_connect($con);

}


/****~~~~~~~~~~~~~~~~~~~~~~~~~~~****~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*****/

function infinitySupplierSlodIteams($product,$quantity,$infitycode){
global $con;
		try{	 
			$sqlInter =  "UPDATE infinity_stock_info SET quantity= quantity - '$quantity', sold_quantity = sold_quantity + '$quantity' WHERE stock_id ='$product' OR i_code='$infitycode'";
			//echo $sql_photos;
			$rsInt = mysqli_query($con,$sqlInter) or die( mysqli_error($con));
			if($rsInt){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsInt);
	mysqli_connect($con);

}

	function infinitySupplierSlodIteamsReturn($product,$quantity){
global $con;
		try{	 
			$sqlInter =  "UPDATE infinity_stock_info SET quantity= quantity + '$quantity', sold_quantity = sold_quantity - '$quantity' WHERE stock_id ='$product' ";
			//echo $sql_photos;
			$rsInt = mysqli_query($con,$sqlInter) or die( mysqli_error($con));
			if($rsInt){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsInt);
	mysqli_connect($con);

}
	
//delete Stock
function deleteStockInfo($stock_id){
	global $con;
		try{	 
			$sqlDel=  "DELETE FROM infinity_stock_info WHERE stock_id='$stock_id'";
			
			$rsDel = mysqli_query($con,$sqlDel) or die( mysqli_error($con));
			if($rsDel){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsDel);
		mysqli_close($con);
	}

/************************************-Receipt Info-*****************************************/

// Get Customer Receipt Info
function getCustReceiptInfo($receipt_id){
	global $con;
		try{ 
			if($receipt_id!=''){
			
				$s =" WHERE receipt_id='$receipt_id'";
			}
			
			$sql = "SELECT * FROM infinity_cust_receipt_info ".$s; 	
			 $rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
			 $i=0;
			 while($row = mysqli_fetch_array($rs)){
                 $receiptInfo[$i][0] = $row['receipt_id'];
                 $receiptInfo[$i][1] = $row['name'];
				 $receiptInfo[$i][2] = $row['receipt_date'];
				 $receiptInfo[$i][3] = $row['contact_no'];
			     $receiptInfo[$i][4] = $row['grand_total'];
				 $receiptInfo[$i][5] = $row['paid_amount'];
				 $receiptInfo[$i][6] = $row['balance_amount'];
				 $receiptInfo[$i][7] = $row['contact_no'];
			
			     $i++;
	
			}
			return $receiptInfo;	
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}
	
	
	// Get Distinct Customer Receipt Info
function getDistinctCustRecInfo($receipt_id){
	global $con;
		try{ 
			if($receipt_id!=''){
			
				$s =" WHERE receipt_id='$receipt_id'";
			}
			
			$sql = "SELECT DISTINCT name FROM infinity_cust_receipt_info ".$s; 	
			 $rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
			 $i=0;
			 while($row = mysqli_fetch_array($rs)){                
                 $distinctReceiptInfo[$i][1] = $row['name'];			 
			
			     $i++;
	
			}
			return $distinctReceiptInfo;	
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}


function getDistinctCustRecInfoForTotal($name){
	global $con;
		try{ 			
			
			$sql = "SELECT contact_no,SUM(grand_total) AS grand_total, SUM(paid_amount) AS paid_amount, SUM(balance_amount) AS balance_amount FROM infinity_cust_receipt_info WHERE name='$name' "; 	
			 $rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
			 $i=0;
			 while($row = mysqli_fetch_array($rs)){
                 $distinctReceiptInfo[$i][0] = $row['receipt_id'];
                 $distinctReceiptInfo[$i][1] = $row['name'];
				 $distinctReceiptInfo[$i][2] = $row['receipt_date'];
				 $distinctReceiptInfo[$i][3] = $row['contact_no'];
			     $distinctReceiptInfo[$i][4] = $row['grand_total'];
				 $distinctReceiptInfo[$i][5] = $row['paid_amount'];
				 $distinctReceiptInfo[$i][6] = $row['balance_amount'];
				 $distinctReceiptInfo[$i][7] = $row['contact_no'];
			
			     $i++;
	
			}
			return $distinctReceiptInfo;	
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}

function getDistinctCustRecInfoForPerticularTotal($name){
	global $con;
		try{ 			
			
			$sql = "SELECT * FROM infinity_cust_receipt_info WHERE name='$name' ORDER BY receipt_id DESC "; 	
			 $rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
			 $i=0;
			 while($row = mysqli_fetch_array($rs)){
                 $distinctReceiptInfo[$i][0] = $row['receipt_id'];
                 $distinctReceiptInfo[$i][1] = $row['name'];
				 $distinctReceiptInfo[$i][2] = $row['receipt_date'];
				 $distinctReceiptInfo[$i][3] = $row['contact_no'];
			     $distinctReceiptInfo[$i][4] = $row['grand_total'];
				 $distinctReceiptInfo[$i][5] = $row['paid_amount'];
				 $distinctReceiptInfo[$i][6] = $row['balance_amount'];
				 $distinctReceiptInfo[$i][7] = $row['contact_no'];
			
			     $i++;
	
			}
			return $distinctReceiptInfo;	
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}	
//add customer's receipt date, contact no, name, grand total, paid, balance amount.  
function addCustReceiptInfo($recipient_date,$recipient_name,$recipient_cont_no,$grand_total,$paid_amount,$bal_amount,$pay_mode,$cheque_no){
	global $con;
		try{	 
			$sql=  "INSERT INTO infinity_cust_receipt_info (name,receipt_date,contact_no,grand_total,paid_amount,balance_amount,pay_mode,added_date,cheque_no) VALUES('$recipient_name','$recipient_date','$recipient_cont_no','$grand_total','$paid_amount','$bal_amount','$pay_mode',NOW(),'$cheque_no')";
			$rs = mysqli_query($con,$sql) or die( mysqli_error($con));
			if($rs){
					$reSql = "SELECT receipt_id FROM infinity_cust_receipt_info WHERE name='$recipient_name' AND receipt_date ='$recipient_date' AND contact_no ='$recipient_cont_no' AND grand_total='$grand_total' AND paid_amount='$paid_amount' AND balance_amount='$bal_amount' AND pay_mode='$pay_mode' AND cheque_no='$cheque_no'";
			$rsCon = mysqli_query($con,$reSql) or die(mysqli_error($con));
			$row_con = mysqli_fetch_assoc($rsCon);
			$receipt_id = $row_con['receipt_id'];
        return $receipt_id;	
			}
			else{
				return 0;
			}
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}
//

	function editCustReceiptInfo($recipient_date,$recipient_name,$recipient_cont_no,$grand_total,$paid_amount,$bal_amount,$receipt_id){
global $con;
		try{	 
			$sqlInter =  "UPDATE infinity_cust_receipt_info SET receipt_date='$recipient_date',name='$recipient_name',contact_no ='$recipient_cont_no',grand_total='$grand_total' ,paid_amount='$paid_amount', balance_amount='$bal_amount', added_date =NOW() WHERE receipt_id ='$receipt_id'";
			//echo $sql_photos;
			$rsInt = mysqli_query($con,$sqlInter) or die( mysqli_error($con));
			if($rsInt){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsInt);
	mysqli_connect($con);

}
	
	
//add Customer balance amount  
function addCustBalAmtInfo($recipient_date,$receipt_idDB,$newbalance_amount,$new_pay){
	global $con;
		try{	 
			$sql=  "INSERT INTO infinity_cust_bal_amt_details (receipt_id,bal_amount,paid_amount,added_date,installment_date) 
			VALUES('$receipt_idDB','$newbalance_amount','$new_pay',NOW(),'$recipient_date')";
			
			$rs = mysqli_query($con,$sql) or die( mysqli_error($con));
			if($rs){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}	
//
	function editCustBalAmtInfo($recipient_date,$receipt_idDB,$bal_amount,$paid_amount){
global $con;
		try{	 
			$sqlInter =  "UPDATE  infinity_cust_bal_amt_details SET bal_amount='$bal_amount',paid_amount = '$paid_amount',added_date = NOW() WHERE receipt_id ='$receipt_idDB' ";
			//echo $sql_photos;
			$rsInt = mysqli_query($con,$sqlInter) or die( mysqli_error($con));
			if($rsInt){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsInt);
	mysqli_connect($con);

}
	//add Customer Receipt Product   
function addCustReceiptProdInfo($receipt_idDBRR,$product,$description,$quantity,$unitprice,$discount,$total){
	global $con;
		try{	 
			$sql=  "INSERT INTO infinity_cust_receipt_prod_info (receipt_id,prod_code,prod_discription,prod_quantity,prod_unit_price,prod_discount,total,added_date) VALUES('$receipt_idDBRR','$product','$description','$quantity','$unitprice','$discount','$total',NOW())";
			
			$rs = mysqli_query($con,$sql) or die( mysqli_error($con));
			if($rs){
				return true;	
			}
			else{
			
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}	
	
//
	
function editCustReceiptProdInfo($receipt_id,$product,$description,$quantity,$unitprice,$discount,$total,$prod_id){
		global $con;
		try{	 
			$sqlInter =  "UPDATE infinity_cust_receipt_prod_info SET prod_code='$product',prod_discription='$description',prod_quantity ='$quantity',prod_unit_price='$unitprice' ,prod_discount='$discount', total='$total', added_date =NOW() WHERE receipt_id ='$receipt_id' ";
			//echo $sql_photos;
			$rsInt = mysqli_query($con,$sqlInter) or die( mysqli_error($con));
			if($rsInt){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsInt);
	mysqli_connect($con);

}



//delete receipt info 

function deleteReceiptInfo($receipt_id){
	global $con;
		try{	 
			$sqlDel=  "DELETE FROM infinity_cust_receipt_info WHERE receipt_id='$receipt_id'";
			
			$rsDel = mysqli_query($con,$sqlDel) or die( mysqli_error($con));
			if($rsDel){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsDel);
		mysqli_close($con);
	}
	
	

	
		//delete receipt Product info  

function deleteReceiptProInfo($receipt_id){
	global $con;
		try{	 
			$sqlDel=  "DELETE FROM infinity_cust_receipt_prod_info WHERE receipt_id='$receipt_id'";
			
			$rsDel = mysqli_query($con,$sqlDel) or die( mysqli_error($con));
			if($rsDel){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsDel);
		mysqli_close($con);
	}
	
	
//get total amount and amount due of perticular customer  

function custGrandBalAmtInfo($receipt_id){
	global $con;               
		try{ 	 			 	
	
		$sql = "SELECT 	name, contact_no, SUM(grand_total) AS grand_total, SUM(balance_amount) AS balance_amount FROM infinity_cust_receipt_info WHERE receipt_id= '$receipt_id' AND  balance_amount > 0 ORDER BY balance_amount  DESC "; 	
		$rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
		
 		
			 if($row = mysqli_fetch_array($rs)){
			     $custTransactionInfo[0][0] = $row['name'];
				  $custTransactionInfo[0][1] = $row['contact_no'];
                 $custTransactionInfo[0][2] = $row['grand_total'];
                 $custTransactionInfo[0][3] = $row['balance_amount'];		    
			     $i++;
	
			}
			return $custTransactionInfo;	
		
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}	
		
	
function pyaUserRemAmountPermonth($receipt_id){
	global $con;
		try{  

			$sql = "SELECT * FROM infinity_cust_receipt_info WHERE receipt_id='$receipt_id'"; 	
			 $rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
 			 if($row = mysqli_fetch_array($rs)){
                 $bill_info .= $row['receipt_id']."##".$row['name']."##".$row['receipt_date']."##".$row['contact_no']."##".$row['grand_total']."##".$row['balance_amount']."##".$row['paid_amount']; 
			}
			return $bill_info;	
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}

function editNewCustReceiptInfo($newPaid_amount,$newbalance_amount,$receipt_idDB,$paymode,$chequeno){
global $con;
		try{	 
			$sqlInter =  "UPDATE infinity_cust_receipt_info SET paid_amount = '$newPaid_amount', balance_amount = '$newbalance_amount',pay_mode='$paymode', cheque_no='$chequeno' WHERE receipt_id ='$receipt_idDB'";
			//echo $sql_photos;
			$rsInt = mysqli_query($con,$sqlInter) or die( mysqli_error($con));
			if($rsInt){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsInt);
	mysqli_connect($con);

}

//........................................................................................................

// for client receipt where AD<0


function editNewCustReceiptInfoIfminus($newbalance_amount,$receipt_idDB){
global $con;
		try{	 
			$sqlInter =  "UPDATE infinity_sup_bal_amt_details SET  balance_amount = '$newbalance_amount' WHERE receipt_id ='$receipt_idDB'";
			//echo $sql_photos;
			$rsInt = mysqli_query($con,$sqlInter) or die( mysqli_error($con));
			if($rsInt){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsInt);
	mysqli_connect($con);

}




//........................................................................................................
function pyaSupplierRemAmountPermonth($suppId){
	global $con;
		try{  

			$sql = "SELECT * FROM infinity_sup_bal_amt_details WHERE sup_id = '$suppId'"; 	
			 $rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
 			 while($row = mysqli_fetch_array($rs)){
                 $bill_info .= $row['sup_bal_id']."##".$row['invoice_no']."@~@"; 
			}
			return $bill_info;	
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}
	
	
function getvaluesInviceInfo($sup_bal_id){
	global $con;
		try{  

			$sql = "SELECT * FROM infinity_sup_bal_amt_details WHERE sup_bal_id = '$sup_bal_id'"; 	
			 $rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
 			 if($row = mysqli_fetch_array($rs)){
                 $bill_info .= $row['sup_bal_id']."##".$row['sup_id']."##".$row['date'].'##'.$row['invoice_no'].'##'.$row['sup_grand_total'].'##'.$row['sup_paid_amount'].'##'.$row['sup_bal_amount']; 
			}
			return $bill_info;	
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}	

function editNewSupInvoiceInfo($newPaid_amount,$newbalance_amount,$sup_idDB,$invoice_code){
global $con;
		try{	 
			$sqlInter =  "UPDATE infinity_sup_bal_amt_details SET sup_paid_amount = '$newPaid_amount', 	sup_bal_amount = '$newbalance_amount' WHERE sup_id ='$sup_idDB' AND sup_bal_id='$invoice_code'";
			//echo $sql_photos;
			$rsInt = mysqli_query($con,$sqlInter) or die( mysqli_error($con));
			if($rsInt){
								$reSql = "SELECT sup_bal_id FROM infinity_sup_bal_amt_details WHERE sup_id='$sup_idDB' AND sup_paid_amount ='$newPaid_amount' AND sup_bal_amount ='$newbalance_amount'";
  $rsCon = mysqli_query($con,$reSql) or die(mysqli_error($con));
  
  $row_con = mysqli_fetch_assoc($rsCon);
  $sup_bal_id = $row_con['sup_bal_id'];
  
    
   return $sup_bal_id;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsInt);
	mysqli_connect($con);

}
			//add supplier invoice installment  
function addSuplBalAmtInfo($sup_bal_id,$installment_date,$invo_new_pay){
	global $con;
		try{	 
			$sql=  "INSERT INTO infinity_sup_pay_installment (sup_bal_id,installment_date,sup_new_paid_amt,added_date) VALUES('$sup_bal_id','$installment_date','$invo_new_pay',NOW())";
			
			$rs = mysqli_query($con,$sql) or die( mysqli_error($con));
			if($rs){
				return true;	
			}
			else{
			
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.$e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}	
	
function viewCustReceiptandProdInfo($receipt_id){
	global $con;
		try{ 
						
			$sql = "SELECT * FROM infinity_cust_receipt_prod_info WHERE receipt_id='$receipt_id' ";
			 	
			 $rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
			 $i=0;
			 while($row = mysqli_fetch_array($rs)){
                 $receiptInfo[$i][0] = $row['prod_id'];
                 $receiptInfo[$i][1] = $row['receipt_id'];
				 $receiptInfo[$i][2] = $row['prod_code'];
				 $receiptInfo[$i][3] = $row['prod_discription'];
			     $receiptInfo[$i][4] = $row['prod_quantity'];
				 $receiptInfo[$i][5] = $row['prod_unit_price'];
				 $receiptInfo[$i][6] = $row['prod_discount'];
				 $receiptInfo[$i][7] = $row['total'];
				 $receiptInfo[$i][8] = $row['added_date'];
			
			     $i++;
	
			}
			return $receiptInfo;	
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}	
	
	
function checkInfifnityCodeInfo($infitycode){
         global $con;
         try{
        
            $resultArray = array();
            $tempArray = array();        
            
              $sql_st="SELECT * FROM infinity_stock_info WHERE i_code = '$infitycode' AND quantity > 0";
            $result_st=mysqli_query($con,$sql_st) or die(mysqli_error($con));
       
             // Loop through each row in the result set
            while($row = mysqli_fetch_assoc($result_st))
            {
                // Add each row into our results array
                foreach ($row as $key => $value) {
                    $tempArray[$key] = $value;
                }
                array_push($resultArray, $tempArray);
                $tempArray = array();
            }

            return $resultArray;
        }
        catch(Exception $e){
            echo 'Caught exception: '.  $e->getMessage(). "\n";
        }
        mysqli_close($result_st);
        mysqli_close($con);
    }	
	
/******************************************************** Customer Product Return ************************************************************/

// update Infinity_customer_receipt_info i.e. New Graand total and New Paid Amout

function updateNewGTandPA($receipt_id,$newGrandTotal,$newPaidAmount){
global $con;
		try{	 
			$sqlInter =  "UPDATE infinity_cust_receipt_info SET grand_total='$newGrandTotal',paid_amount='$newPaidAmount' WHERE receipt_id ='$receipt_id'";
			//echo $sql_photos;
			$rsInt = mysqli_query($con,$sqlInter) or die( mysqli_error($con));
			if($rsInt){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsInt);
	mysqli_connect($con);

}

// update @ infinity_cust_bal_amt_details i.e. New Paid Amout

function updateNewPA($receipt_id,$newPaidAmount){
global $con;
		try{	 
			$sqlInter =  "UPDATE infinity_cust_bal_amt_details SET paid_amount='$newPaidAmount' WHERE receipt_id ='$receipt_id'";
			//echo $sql_photos;
			$rsInt = mysqli_query($con,$sqlInter) or die( mysqli_error($con));
			if($rsInt){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsInt);
	mysqli_connect($con);

}

// update Infinity_customer_receipt_info i.e. New Graand total and New Paid Amout and Balance amount in case of last product is being return.

function updateNewGTandPAandBA($receipt_id,$newGrandTotal,$newPaidAmount,$newBalanceAmount){
global $con;
		try{	 
			$sqlInter =  "UPDATE infinity_cust_receipt_info SET grand_total='$newGrandTotal', paid_amount='$newPaidAmount', balance_amount='$newBalanceAmount' WHERE receipt_id ='$receipt_id'";
			//echo $sql_photos;
			$rsInt = mysqli_query($con,$sqlInter) or die( mysqli_error($con));
			if($rsInt){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsInt);
	mysqli_connect($con);

}


// update @ infinity_cust_bal_amt_details i.e. New Paid Amout and Balance amount 

function updateNewPAandBA($receipt_id,$newPaidAmount,$newBalanceAmount){
global $con;
		try{	 
			$sqlInter =  "UPDATE infinity_cust_bal_amt_details SET paid_amount='$newPaidAmount', bal_amount='$newBalanceAmount' WHERE receipt_id ='$receipt_id'";
			//echo $sql_photos;
			$rsInt = mysqli_query($con,$sqlInter) or die( mysqli_error($con));
			if($rsInt){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsInt);
	mysqli_connect($con);

}



// update  infinity_stock_info i.e. New Product Stock and New Sold Product 

function updateNewPSandSP($prod_code,$newProdStock,$newProdSold){
global $con;
		try{	 
			$sqlInter =  "UPDATE infinity_stock_info SET quantity='$newProdStock',sold_quantity='$newProdSold' WHERE stock_id ='$prod_code'";
			//echo $sql_photos;
			$rsInt = mysqli_query($con,$sqlInter) or die( mysqli_error($con));
			if($rsInt){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsInt);
	mysqli_connect($con);

}

//delete Product from receipt while return 
function deleteCustReceiptProd($receipt_id,$prod_id){
	global $con;
		try{	 
			$sqlDel=  "DELETE FROM  infinity_cust_receipt_prod_info WHERE receipt_id='$receipt_id' AND prod_id='$prod_id'";
			
			$rsDel = mysqli_query($con,$sqlDel) or die( mysqli_error($con));
			if($rsDel){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsDel);
		mysqli_close($con);
	}
	 	
/******************************************************** Customer Product Return End ************************************************************/	
	

/********************************************************  Suplier Product Return ************************************************************/	

// Get Supplier invoice wise and producct wise Toatl,Paid and Balnce Amount.
function getSupBlnsDetails($sup_id,$invoice_no){
	global $con;
		try{ 
			if($sup_id!=''&&$invoice_no!=''){
			
				$s ="WHERE sup_id='$sup_id' AND invoice_no='$invoice_no'";
			}
			
			$sql = "SELECT * FROM infinity_sup_bal_amt_details ".$s; 	
			 $rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
			 $i=0;
			 while($row = mysqli_fetch_array($rs)){
                 $supAmountDetails[$i][0] = $row['sup_grand_total'];
				 $supAmountDetails[$i][1] = $row['sup_paid_amount'];
				 $supAmountDetails[$i][2] = $row['sup_bal_amount'];           			
			     $i++;
	
			}
			return $supAmountDetails;	
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}
	
// update  infinity_sup_bal_amt_details i.e. New Grand Total and New Paid Amount 

function updateGTandPAandBA($sup_id,$invoice_no,$newSupGrandTotal,$newSupPaidAmount,$newSupBalAmount){
global $con;
		try{	 
			$sqlInter =  "UPDATE infinity_sup_bal_amt_details SET sup_grand_total='$newSupGrandTotal',sup_paid_amount='$newSupPaidAmount', sup_bal_amount='$newSupBalAmount' WHERE sup_id ='$sup_id' AND invoice_no='$invoice_no'";
			//echo $sql_photos;
			$rsInt = mysqli_query($con,$sqlInter) or die( mysqli_error($con));
			if($rsInt){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsInt);
	mysqli_connect($con);

}	


// update  infinity_sup_bal_amt_details i.e. New Grand Total and New Balance Amount 

function updateGTandAD($sup_id,$invoice_no,$newSupGrandTotal,$newSupBalAmount){
global $con;
		try{	 
			$sqlInter =  "UPDATE infinity_sup_bal_amt_details SET sup_grand_total='$newSupGrandTotal' , sup_bal_amount='$newSupBalAmount' WHERE sup_id ='$sup_id' AND invoice_no='$invoice_no'";
			//echo $sql_photos;
			$rsInt = mysqli_query($con,$sqlInter) or die( mysqli_error($con));
			if($rsInt){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsInt);
	mysqli_connect($con);

}	




// update  infinity_sup_bal_amt_details i.e. New Grand Total and New balance Amount if cp of product is less than paid amount.

function updateGTandPA($sup_id,$invoice_no,$newSupGrandTotal,$newSupPaidAmount){
global $con;
		try{	 
			$sqlInter =  "UPDATE infinity_sup_bal_amt_details SET sup_grand_total='$newSupGrandTotal',sup_paid_amount='$newSupPaidAmount' WHERE sup_id ='$sup_id' AND invoice_no='$invoice_no'";
			//echo $sql_photos;
			$rsInt = mysqli_query($con,$sqlInter) or die( mysqli_error($con));
			if($rsInt){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsInt);
	mysqli_connect($con);

}	

// update  infinity_sup_bal_amt_details i.e. New Grand Total and New Paid Amount  and New Balnace Amount 

function updateGTandPAandBALastProd($sup_id,$invoice_no,$newSupGrandTotal,$newSupPaidAmount,$newSupBalAmount){
global $con;
		try{	 
			$sqlInter =  "UPDATE infinity_sup_bal_amt_details SET sup_grand_total='$newSupGrandTotal',sup_paid_amount='$newSupPaidAmount', sup_bal_amount='$newSupBalAmount' WHERE sup_id ='$sup_id' AND invoice_no='$invoice_no'";
			//echo $sql_photos;
			$rsInt = mysqli_query($con,$sqlInter) or die( mysqli_error($con));
			if($rsInt){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsInt);
	mysqli_connect($con);

}		

//delete Stock while returning it back to dealer 
function returnSupProduct($stock_id){
	global $con;
		try{	 
			$sqlDel=  "DELETE FROM infinity_stock_info WHERE stock_id='$stock_id'";
			
			$rsDel = mysqli_query($con,$sqlDel) or die( mysqli_error($con));
			if($rsDel){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsDel);
		mysqli_close($con);
	}


/*--***********************************-Expenses Info-*****************************************/
// Get Expenses
function getExpensesInfo($exp_id){
	global $con;
		try{ 
			if($exp_id!=''){
			
				$s =" WHERE exp_id='$exp_id'";
			}
			 
			$sql = "SELECT * FROM  infinity_expenses".$s." ORDER BY exp_date DESC"; 	
			 $rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
			 $i=0;
			 while($row = mysqli_fetch_array($rs)){
			     $expensesInfo[$i][0] = $row['exp_id'];
                 $expensesInfo[$i][1] = $row['exp_date'];
                 $expensesInfo[$i][2] = $row['exp_particulars'];
				 $expensesInfo[$i][3] = $row['exp_amount'];				 
					    
			     $i++;
	
			}
			return $expensesInfo;	
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}
	//
	
	// Get Expenses by search date
function getExpSearchDateInfo($exp_start_date,$exp_end_date){
	global $con;
		try{ 
			if($exp_start_date!='' &&  $exp_end_date!=''){
			
				$s =" WHERE exp_date BETWEEN'$exp_start_date' AND 'exp_end_date'";
			}
			 
			$sql = "SELECT * FROM  infinity_expenses".$s; 	
			 $rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
			 $i=0;
			 while($row = mysqli_fetch_array($rs)){
			     $expensesInfo[$i][0] = $row['exp_id'];
                 $expensesInfo[$i][1] = $row['exp_date'];
                 $expensesInfo[$i][2] = $row['exp_particulars'];
				 $expensesInfo[$i][3] = $row['exp_amount'];				 
					    
			     $i++;
	
			}
			return $expensesInfo;	
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}
	//

	
		
//add expenses
function addExpensesInfo($exp_date,$exp_particulars,$exp_amount){
	global $con;
		try{	 
			$sql=  "INSERT INTO infinity_expenses (exp_date,exp_particulars,exp_amount,added_date) VALUES('$exp_date','$exp_particulars','$exp_amount',NOW())";
			
			$rs = mysqli_query($con,$sql) or die( mysqli_error($con));
			if($rs){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}
	

//edit expenses 

function editExpensesInfo($exp_date,$exp_particulars,$exp_amount,$exp_idDB){
global $con;
		try{	 
			$sqlInter =  "UPDATE infinity_expenses SET exp_date = '$exp_date', exp_particulars = '$exp_particulars', exp_amount = '$exp_amount' WHERE exp_id = '$exp_idDB' ";
			//echo $sql_photos;
			$rsInt = mysqli_query($con,$sqlInter) or die( mysqli_error($con));
			if($rsInt){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsInt);
	mysqli_connect($con);

}

//delete expenses 
function deleteExpensesInfo($exp_id){
	global $con;
		try{	 
			$sqlDel=  "DELETE FROM infinity_expenses WHERE exp_id='$exp_id'";
			
			$rsDel = mysqli_query($con,$sqlDel) or die( mysqli_error($con));
			if($rsDel){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsDel);
		mysqli_close($con);
	}

/*--------------------------------------------- Old stock start ------------------------------------------------*/

// Get old stcok 
function getOldStockInfo($sr_no){
	global $con;
		try{ 
			if($sr_no!=''){
			
				$s =" WHERE sr_no='$sr_no'";
			}
			 
			$sql = "SELECT * FROM  infinity_old_stock".$s." ORDER BY sr_no DESC"; 	
			 $rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
			 $i=0;
			 while($row = mysqli_fetch_array($rs)){
                 $oldStockInfo[$i][0] = $row['sr_no'];
                 $oldStockInfo[$i][1] = $row['old_infinity_code'];
				 $oldStockInfo[$i][2] = $row['old_sp_amount'];				 
				 $oldStockInfo[$i][3] = $row['flag'];
			   		    
			     $i++;
	
			}
			return $oldStockInfo;	
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}
	//
	
	// .............................. trigger event pickup old stock how's flag is 0 ..................................//
	
	// Get old stcok 
/*function getOldStockToNewStockInfo($sr_no){
	global $con;
		try{ 
						 
			$sql = "SELECT * FROM  infinity_old_stock WHERE flag = '0'"; 	
			 $rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
			 $i=0;
			 while($row = mysqli_fetch_array($rs)){
                 $oldStockInfo[$i][0] = $row['sr_no'];
                 $oldStockInfo[$i][1] = $row['old_infinity_code'];
				 $oldStockInfo[$i][2] = $row['old_sp_amount'];				 
				 $oldStockInfo[$i][3] = $row['flag'];
			   		    
			     $i++;
	
			}
			return $oldStockInfo;	
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}
	//
	
	//edit old stock  

function editOldStockAftrnfo($sr_noDB){
global $con;
		try{	 
			$sqlInter =  "UPDATE infinity_old_stock SET flag = '1' WHERE sr_no = '$sr_noDB' ";
			//echo $sql_photos;
			$rsInt = mysqli_query($con,$sqlInter) or die( mysqli_error($con));
			if($rsInt){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsInt);
	mysqli_connect($con);

}*/
	
	
	
	// ...............................Trigger event end ................................................................//
	

	
	//add old stock
	
function addOldStockInfo($old_infinity_code,$old_sp_amount){
	global $con;
		try{	 
			$sql=  "INSERT INTO infinity_old_stock (old_infinity_code,old_sp_amount,added_date) VALUES('$old_infinity_code','$old_sp_amount',NOW())";
			
			$rs = mysqli_query($con,$sql) or die( mysqli_error($con));
			if($rs){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}
	

//edit old stock  

function editOldStocknfo($old_infinity_code,$old_sp_amount, $sr_noDB){
global $con;
		try{	 
			$sqlInter =  "UPDATE infinity_old_stock SET old_infinity_code = '$old_infinity_code', old_sp_amount = '$old_sp_amount' WHERE sr_no = '$sr_noDB' ";
			//echo $sql_photos;
			$rsInt = mysqli_query($con,$sqlInter) or die( mysqli_error($con));
			if($rsInt){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsInt);
	mysqli_connect($con);

}

//delete old stock   //Note we have only declare this function but not used anywere yet.
function deleteOldStockInfo($sr_no){
	global $con;
		try{	 
			$sqlDel=  "DELETE FROM infinity_old_stock WHERE sr_no='$sr_no'";
			
			$rsDel = mysqli_query($con,$sqlDel) or die( mysqli_error($con));
			if($rsDel){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsDel);
		mysqli_close($con);
	}
	

	
// Get  invoice wise Stock Info
function getInvoiceStockInfoSatish($invoice_no,$sup_id){
	global $con;
		try{
	
			$sql = "SELECT * FROM  infinity_stock_info  WHERE invoice_no='$invoice_no' AND sup_id='$sup_id'"; 	
			 $rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
			 $i=0;
			 while($row = mysqli_fetch_array($rs)){
            
			     $InvoiceStockInfo[$i][0] = $row['d_code'];			
				 $InvoiceStockInfo[$i][1] = $row['description'];
				 $InvoiceStockInfo[$i][2] = $row['quantity'];			
				 $InvoiceStockInfo[$i][3] = $row['unit_price_dealer']; //cp 
				 $InvoiceStockInfo[$i][4] = $row['stock_id'];
				 $InvoiceStockInfo[$i][5] = $row['sup_id'];
				 $InvoiceStockInfo[$i][6] = $row['invoice_no'];
				 $InvoiceStockInfo[$i][7] = $row['sold_quantity'];
				 $InvoiceStockInfo[$i][8] = $row['unit_price'];    // sp

				 
			 	 			    
			     $i++;
	
			}
			return $InvoiceStockInfo;	
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}	

function getDistinctCustRecInfoForPayments($name){
	global $con;
		try{ 			
			
			$sql = "SELECT * FROM infinity_cust_receipt_info WHERE name='$name' ORDER BY receipt_id ASC "; 	
			 $rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
			 $i=0;
			 while($row = mysqli_fetch_array($rs)){
                 $distinctReceiptInfo[$i][0] = $row['receipt_id'];                 
			     $distinctReceiptInfo[$i][4] = $row['grand_total'];
				 $distinctReceiptInfo[$i][5] = $row['paid_amount'];
				 $distinctReceiptInfo[$i][6] = $row['balance_amount'];
				 $distinctReceiptInfo[$i][7] = $row['pay_mode'];
				 $distinctReceiptInfo[$i][8] = $row['cheque_no'];
				 
			
			     $i++;
	
			}
			return $distinctReceiptInfo;	
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}



function calculationSupplierInfo($sup_name){
	global $con;
		try{ 
			
			 
			$sql = "SELECT * FROM  infinity_supplier_info WHERE sup_name='$sup_name'"; 	
			 $rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
			 $i=0;
			 if($row = mysqli_fetch_array($rs)){
                 $supplierInfo[$i][0] = $row['sup_id'];
                 $supplierInfo[$i][1] = $row['sup_name'];						    
			     //$i++;
	
			}
			return $supplierInfo;	
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}




	function editNewSupInvoiceInfoNewCal($newPaid_amount,$newbalance_amount,$sup_idDB,$invoice_code,$paymode,$ChequeNo){
global $con;
		try{	 
			$sqlInter =  "UPDATE infinity_sup_bal_amt_details SET sup_paid_amount = '$newPaid_amount', 	sup_bal_amount = '$newbalance_amount',pay_mode='$paymode',cheque_no='$ChequeNo' WHERE sup_id ='$sup_idDB' AND invoice_no = '$invoice_code'";
			//echo $sql_photos;
			$rsInt = mysqli_query($con,$sqlInter) or die( mysqli_error($con));
			if($rsInt){
				
				return true;				
    
   return $sup_bal_id;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsInt);
	mysqli_connect($con);

}	

function checkInfifnityOldStockCodeInfo($infitycode){
         global $con;
         try{
        
            $resultArray = array();
            $tempArray = array();        
            
              $sql_st="SELECT * FROM infinity_old_stock WHERE old_infinity_code = '$infitycode' AND  flag = 0 ";
            $result_st=mysqli_query($con,$sql_st) or die(mysqli_error($con));
       
             // Loop through each row in the result set
            while($row = mysqli_fetch_assoc($result_st))
            {
                // Add each row into our results array
                foreach ($row as $key => $value) {
                    $tempArray[$key] = $value;
                }
                array_push($resultArray, $tempArray);
                $tempArray = array();
            }

            return $resultArray;
        }
        catch(Exception $e){
            echo 'Caught exception: '.  $e->getMessage(). "\n";
        }
        mysqli_close($result_st);
        mysqli_close($con);
    }



    function addOldSoldStockInfo($stockChooseDealer,$stockAddDate,$stockInvoiceNo,$stockDealerCode,$stockInfinityCode,$stockDescriptions,$stockQuantity,$stockUnitPriceDealer,$stockUnitPrice,$stockAmount,$flag){
	global $con;
		try{	 
			$sql=  "INSERT INTO infinity_stock_info (sup_id,date,invoice_no,d_code,i_code,description,sold_quantity,unit_price_dealer,unit_price,amount,added_date,flag,quantity) VALUES('$stockChooseDealer','$stockAddDate','$stockInvoiceNo','$stockDealerCode','$stockInfinityCode','$stockDescriptions','$stockQuantity','$stockUnitPriceDealer','$stockUnitPrice','$stockAmount',NOW(),'$flag','0')";
			
			$rs = mysqli_query($con,$sql) or die( mysqli_error($con));
			if($rs){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}

function oldStockInfoFlag($stockInfinityCode,$flag){
global $con;
		try{	 
		$sqlInter =  "UPDATE infinity_old_stock SET flag = '$flag' WHERE old_infinity_code = '$stockInfinityCode' ";
			//echo $sql_photos;
			$rsInt = mysqli_query($con,$sqlInter) or die( mysqli_error($con));
			if($rsInt){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rsInt);
	mysqli_connect($con);

}



/*
this area for satish and delete after testing this all functions 20-07-2016

*/	




function checkUserTotalPriceInfo32($invoice_no){
	global $con;               
		try{ 	 			 	
	
		$sql = "SELECT SUM(sup_grand_total) AS sup_grand_total, SUM(sup_paid_amount) AS sup_paid_amount, SUM(sup_bal_amount) AS sup_bal_amount, sup_id, date, 	invoice_no, cheque_no, pay_mode FROM infinity_sup_bal_amt_details WHERE invoice_no= '$invoice_no'"; 	
		$rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
		
 		
			 if($row = mysqli_fetch_array($rs)){
                 $supBalInfo[0][0] = $row['sup_grand_total'];
				 $supBalInfo[0][1] = $row['sup_paid_amount'];
                 $supBalInfo[0][2] = $row['sup_bal_amount'];				 
				 $supBalInfo[0][3] = $row['sup_id'];
				 $supBalInfo[0][4] = $row['date'];
				 $supBalInfo[0][5] = $row['invoice_no'];
				 $supBalInfo[0][6] = $row['pay_mode'];
				 $supBalInfo[0][7] = $row['cheque_no'];				 		    
			     $i++;	
			}
			return $supBalInfo;	
		
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}
	

	
	function getDistinctCustRecInfoForPayments1(){
	global $con;
		try{ 			
			
			$sql = "SELECT * FROM infinity_sup_bal_amt_details"; 	
			 $rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
			 $i=0;
			 while($row = mysqli_fetch_array($rs)){
                 $supBalInfo[$i][0] = $row['sup_grand_total'];
				 $supBalInfo[$i][1] = $row['sup_paid_amount'];
                 $supBalInfo[$i][2] = $row['sup_bal_amount'];				 
				 $supBalInfo[$i][3] = $row['sup_id'];
				 $supBalInfo[$i][4] = $row['date'];
				 $supBalInfo[$i][5] = $row['invoice_no'];
				 $supBalInfo[$i][6] = $row['pay_mode'];
				 $supBalInfo[$i][7] = $row['cheque_no'];
				 
			
			     $i++;
	
			}
			return $supBalInfo;	
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}


function addUserTotalPriceInfo($sup_id,$date,$invoice_no,$sup_grand_total,$sup_paid_amount,$sup_bal_amount,$pay_mode,$cheque_no){
	global $con;
		try{	 
			$sql=  "INSERT INTO infinity_sup_bal_amt_details1 (sup_id,date,invoice_no,sup_grand_total,sup_paid_amount,sup_bal_amount,added_date,pay_mode,cheque_no) 
													   VALUES('$sup_id','$date','$invoice_no','$sup_grand_total','$sup_paid_amount','$sup_bal_amount',NOW(),'$pay_mode','$cheque_no')";
			
			$rs = mysqli_query($con,$sql) or die( mysqli_error($con));
			if($rs){
				return true;	
			}
			else{
				return false;
			}
			
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}	


function getSupBalDetailsUsingINvoice($invoice_no){
	global $con;
		try{ 
			
			
			$sql = "SELECT * FROM infinity_sup_bal_amt_details WHERE invoice_no='$invoice_no'"; 	
			 $rs =mysqli_query($con,$sql) or die ( mysqli_error($con));
			 $i=0;
			 while($row = mysqli_fetch_array($rs)){
                 $supAmountDetails[$i][0] = $row['sup_grand_total'];
				 $supAmountDetails[$i][1] = $row['sup_paid_amount'];
				 $supAmountDetails[$i][2] = $row['sup_bal_amount'];           			
			     $i++;
	
			}
			return $supAmountDetails;	
		}
		catch(Exception $e){
			echo 'Caught exception Main: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($rs);
		mysqli_close($con);
	}	
	
}//class end...
?>
