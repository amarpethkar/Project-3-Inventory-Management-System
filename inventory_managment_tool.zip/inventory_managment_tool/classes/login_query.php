<?php
require_once('conn_obj.php');

class loginModule{

	function loginModule(){}

	function getLoginInfo($username,$password){
		//$password = md5($pass);
		global $con;
		try{			
			$check =mysqli_query($con,"SELECT * FROM admin WHERE username ='$username' AND password ='$password'") or die(mysqli_error());
			
			if(mysqli_num_rows($check)>0) {
				//Login Successful
			
				$admin = mysqli_fetch_assoc($check);
						
				$_SESSION['SESS_USER_NAME'] = $admin['name'];
				$_SESSION['SESS_USER_EMAIL'] = $username;
				$_SESSION['SESS_DATE'] = $admin['last_login'];	
				$_SESSION['SESS_USER_ID'] = $admin['sr_no'];
				
				$sql_log =  mysqli_query($con,"UPDATE admin SET last_login=NOW() WHERE username='$username'") or die(mysqli_error());		
				return true;
			}
			else{
				return false;
			}
		}
		catch(Exception $e){
			echo 'Caught exception: '.  $e->getMessage(). "\n";
		}
		//finally{
		mysqli_close($check);
		mysqli_close($con);
		//$Connect->close();
		//}
	}
}

?>