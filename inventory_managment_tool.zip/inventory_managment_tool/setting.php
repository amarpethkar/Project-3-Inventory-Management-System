<?php
 include_once('auth.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Infinity by Ruchi | Home Page</title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet" />
<link href="css/style.css" type="text/css" rel="stylesheet" />
<link href="css/menu.css" type="text/css" rel="stylesheet" />
<!--<script src="js/menu_script.js" type="text/javascript"></script>-->
<script type="text/javascript" src="js/jquery.min.js"></script>
 <script type="text/javascript" src="js/validate.js"></script>
<script type="text/javascript" src="js/check_form.js"></script>
<script type="text/javascript">
    $(function () {
        $("#btnSubmit").click(function () {
            var password = $("#txtPassword").val();
            var confirmPassword = $("#txtConfirmPassword").val();
            if (password != confirmPassword) {
                alert("Passwords do not match.");
                return false;
            }
			var username = $("#txtUsername").val();
            return true;
        });
		   $("#btnSubmit").click(function () {
            var username = $("#txtUsername").val();
            var confirmUsername = $("#txtConfirmUsername").val();
            if (username != confirmUsername) {
                alert("Username do not match.");
                return false;
            }
			
            return true;
        });
    });
	function check_form(form_name) {
  if (submitted == true) {
    alert("This form has already been submitted. Please press Ok and wait for this process to be completed.");
    return false;
  }

  error = false;
  form = form_name;
  error_message = "Please make the following corrections:\n\n";
  
  check_input("old_password", 3, "Old Password");
  check_input("new_password",3, "New Password");
  check_input("retype_password", 3, "Retype Password");
  check_input("retype_password", 3, "Current Username");
  check_input("retype_password", 3, "New Username");  
  check_input("retype_password", 3, "Retype Username");  
  
  if (error == true) {
    alert(error_message);
    return false;
  } else {
   
    submitted = true;
    return true;
  }
}
</script>
</head>
<body>
<!-- wrapper start-->
<div class="esya_wrapper">
  <!-- main container-->
  <div class="container">
    <!--herader container -->
    <?php include_once('header.php'); ?>
    <!--header container end-->
    <!--menu container-->
    <div class="menu_container">
      <?php include_once('menu.php'); ?>
    </div>
    <!--menu container end-->
    <!--middle container -->
    <div class="middle_container_setting">
      <div class="middle_header"><span>Change Password</span></div>
      <br/>
      <div>
        <?php
				$msg=$_REQUEST['msg'];
				if($msg==1){ 
			?>
        <font class="alert_red"><img src="images/no.png" align="absmiddle" />&nbsp;Old password is wrong, Retry.</font>
        <?php } 
			if($msg==2){ 
			?>
        <font class="alert_green"><img src="images/yes.png" align="absmiddle" />&nbsp;New password is updated successfully.</font>
        <?php }if($msg==3){ 
			?>
        <font class="alert_red"><img src="images/no.png" align="absmiddle" />&nbsp;New password and Old Password must be different.</font>
        <?php }if($msg==4){ 
			?>
        <font class="alert_red"><img src="images/no.png" align="absmiddle" />&nbsp;Try Again.</font>
        <?php } ?>
      </div>
      <form name="change_pass" action="query.php" method="post" onSubmit="return check_form(change_pass);">
        <table width="90%" align="center" style="height: 125px; text-align:left;">
          <tr>
            <td height="15px"></td>
          </tr>
          <tr>
            <td>Current Username:</td>
            <td><input type="text" name="old_user_name"  style="width: 185px;" placeholder="Current Usename here" required/></td>
            <td>Old Password:</td>
            <td><input type="text" name="old_password" placeholder="Type old password here" style="width: 185px;" required/></td>
          </tr>
          <tr>
            <td height="10px"></td>
          </tr>
          <tr>
            <td>New Username:</td>
            <td><input type="text" name="new_user_name" id="txtUsername" style="width: 185px;" placeholder="New Usename here" required/></td>
            <td>New Password:</td>
            <td><input type="password" name="new_password" id="txtPassword" placeholder="Type new password here" style="width: 185px;" required/></td>
          </tr>
          <tr>
            <td height="10px"></td>
          </tr>
          <tr>
            <td>Confirm Username:</td>
            <td><input type="text" name="conf_user_name" id="txtConfirmUsername" placeholder="Re-type new Username here" style="width: 185px;" required/></td>
            <td>Confirm password:</td>
            <td><input type="password" name="retype_password" id="txtConfirmPassword" placeholder="Re-type new password here" style="width: 185px;" required/></td>
          </tr><tr>
            <td height="15px"></td>
          </tr>
          
          <tr>
            <td colspan="3"></td><td><input type="submit" class="supBtn_setting" name="change_pass" value="SAVE" id="btnSubmit" style="width: 110px;"/>
              <input type="hidden" name="function" value="change_password"></td>
          </tr>
          </tr>
          
          <tr>
            <td height="15px"></td>
          </tr>
          <tr>
        </table>
      </form>
      <!--middle container end-->
    </div>
    <!--main container end-->
  </div>
</div>
<!--wrapper end-->
</body>
</html>
