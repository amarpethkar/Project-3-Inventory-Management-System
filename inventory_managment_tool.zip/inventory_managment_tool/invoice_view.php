<?php
 include_once('auth.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Infinity by Ruchi | Home</title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet" />
<link href="css/style.css" type="text/css" rel="stylesheet" />
<link href="css/menu.css" type="text/css" rel="stylesheet" />
<link href="css/pop_up_user_profile.css" type="text/css" rel="stylesheet" />
<!--calender code-->
<link rel="stylesheet" href="css/jquery-ui.css">
<script src="js/jquery-1.10.2.js"></script>
<script src="js/jquery-ui.js"></script>
<!--calender code end -->
<script src="js/menu_script.js" type="text/javascript"></script>
<script type="text/javascript">
$(document).ready(function(){

$('#show_pay1').click(function(e){  
  
      $("#profile_cam").show(); 
      
    });// open  profile img popup
$('#close').click(function(e){  
  
      $("#profile_cam").hide(); 
      
    });// open  profile img popup
	
	$('#show_supPayRecord').click(function(e){  
  
      $("#profile_supl").show(); 
      
    });
	$('#close1').click(function(e){  
  						$("#sup_id").val('');				
						$("#invo_date").val('');
						$("#invo_num").val('');
						$("#invo_total_amt").val('');
						$("#invo_amt_paid").val('');
					    $("#invo_bal_amt").val('');	
      $("#profile_supl").hide(); 
      
    });// open  profile img popup

});

function userIdinfo(userId){

 var userId = userId;
	 
	 $.ajax({
				   type: 'POST',
				   url: 'query.php',
				   data: 'function=pya_user_remAmount_permonth&userId=' + userId,
				   cache: false,
				   success: function(result) {
					var	response = result;
						//alert(response);					
						var values = response.split("##");						
						$("#user_rec_id").val(values[0]);				
						$("#rec_date").val(values[2]);
						$("#rec_num").val(values[0]);
						$("#rec_name").val(values[1]);
						$("#balance_amount").val(values[5]);
						$("#grand_total").val(values[4]);
						$("#paid_amount").val(values[6]);		   
					  
					 
					}
					
				 });
				 
$("#profile_cam").show();
}
/*****************************************************************************************/

function supplierPayInfo(supId,name){

 var supId = supId;
	var userName = name;
	
	$('#supplier_name').val(userName);
	
	 var temp='<option value="">~~Select Invoice~~</option>';
	 $.ajax({
				   type: 'POST',
				   url: 'query.php',
				   data: 'function=pya_supplier_remAmount_permonth&suppId=' + supId,
				   cache: false,
				   success: function(result) {
					var	response = result;
						//alert(response);			   
					var values = response.split("@~@");	
					  for(var i=0; i<values.length-1; i++){
						  
						  var lastval = values[i].split('##');
						  //alert(lastval);
						  temp +='<option value="'+ lastval[0] +'">' + lastval[1] + '</option>';	
					   
					  
					}
					$("#supplier_invoice_code").html(temp);
				   }
				 });
	
	$("#profile_supl").show();
}

	function suppInvoiceValuesSelect(){

 var suppInvoiceId = $('#supplier_invoice_code').val();
	 //alert(suppInvoiceId);
		if(suppInvoiceId!=''){
	
			$('#supplier_invoice_code').css('border-color','#DADADA');
			
	 $.ajax({
				   type: 'POST',
				   url: 'query.php',
				   data: 'function=getvalues_invice&sup_bal_id=' + suppInvoiceId,
				   cache: false,
				   success: function(result) {
					var	response = result;
						//alert(response);					
						var values = response.split("##");						
						$("#sup_id").val(values[0]);				
						$("#invo_date").val(values[2]);
						$("#invo_num").val(values[3]);
						$("#invo_total_amt").val(values[4]);
						$("#invo_amt_paid").val(values[5]);
					    $("#invo_bal_amt").val(values[6]);	
					  
					 
					}
					
				 });
		}else{
						$("#sup_id").val('');				
						$("#invo_date").val('');
						$("#invo_num").val('');
						$("#invo_total_amt").val('');
						$("#invo_amt_paid").val('');
					    $("#invo_bal_amt").val('');	
		$('#supplier_invoice_code').css('border-color','red');
			
		
		}
				 

}

$(function() {
    $( "#datepicker" ).datepicker();
      $( "#datepicker" ).datepicker("setDate", new Date());
	  
	 $( "#datepicker_cust" ).datepicker();
      $( "#datepicker_cust" ).datepicker( "setDate", new Date());
  });
  
</script>
<style>
.m-hide {
	display:none;
}
</style>
</head>
<body style="color:#">
<!-- wrapper start-->
<div class="esya_wrapper">
  <!-- main container-->
  <div class="container">
    <!--herader container -->
    <?php include_once('header.php'); ?>
    <!--header container end-->
    <!--menu container-->
    <div class="menu_container">
      <?php include_once('menu.php'); ?>
    </div>
    <!--menu container end-->
    <!--middle container -->
    <?php
      $name = $qc->clean($_REQUEST['name']); ?>
    <div class="middle_container_overview">
      <div class="middle_header"><span style="float:left; margin-left:30px;">Dealer Name:&nbsp;<?php echo $name ;?></span> <a href="dealer_finances.php" style="float:right; margin-right:30px; color:#fff;">Back</a></span></div>
      <div class="view_dealer">
        <table align="center" width="100%" class="ov_table">
          <tr style="background: rgb(241, 241, 241) none repeat scroll 0% 0%;">
          <td width="10px"></td>
            <td><span>Sr. No.</span></td>
            <td><span>Invoice NO.</span></td>
           <td><span>Invoice Date</span></td>
           <td><span>Available Stock</span></td>
         
            <td><span>Total Amount&nbsp;(&nbsp;<img src="images/rupee.png" width="10"/>&nbsp;)</span></td>
			<td><span>Paid Amount&nbsp;(&nbsp;<img src="images/rupee.png" width="10"/>&nbsp;)</span></td>
            <td><span>Amount Due&nbsp;(&nbsp;<img src="images/rupee.png" width="10"/>&nbsp;)</span></td>
       
          	<td><span></span></td>
          </tr>
          <?php 
  $sup_id = $qc->clean($_REQUEST['sup_id']);
  $getSupplierInvoiceInfo = $qc-> getSupplierInvoiceInfo($sup_id);
  for($i=0,$j=1;$i<count($getSupplierInvoiceInfo);$i++,$j++)
  {
  $totalProductInInvoice =$qc-> stockInOutInfoPerInvoice($sup_id,$getSupplierInvoiceInfo[$i][3]);
  ?>
          <tr class="recordBox">
          <td></td>
            <td><?php echo $j ; ?></td>
            
            <td><?php echo $getSupplierInvoiceInfo[$i][3]; ?></td>  <!-- Invoice No. -->
          
            <td><?php echo $getSupplierInvoiceInfo[$i][2]; ?></td>  <!-- Invoice Date -->
          
            <td><?php echo  $totalProductInInvoice[0][0];?></td>  <!--  Total product -->
      
            <td><?php echo $getSupplierInvoiceInfo[$i][4]; ?></td>  <!--Toatal amount -->
           
			<td><?php echo $getSupplierInvoiceInfo[$i][5]; ?></td>  <!--Paid amount -->
      
            <td><?php echo $getSupplierInvoiceInfo[$i][6]; ?></td>  <!--Amount Due-->
           
       
           
           <td><a href="single_invoice_view.php?invoice_no=<?php echo $getSupplierInvoiceInfo[$i][3]; ?>&name=<?php echo $name ;?>&invoice_date=<?php echo $getSupplierInvoiceInfo[$i][2] ;?>&invoice_amt=<?php echo $getSupplierInvoiceInfo[$i][4] ;?>&sup_id=<?php echo $sup_id;?>"><img src="images/view.png" /></a></td>
          </tr>
     <?php } ?>
        </table>
      </div>
      <br/>
      <br />
   
    </div>
    <!--middle container end-->
  </div>
  <!--main container end-->
</div>
</div>
<!--wrapper end-->

</body>
</html>
