<?php 
	require_once('auth.php');
	
	$function = $_REQUEST['function'];	
	
	/*---------------------------------------------------------- Suplier Product Return ----------------------------------*/
	
	if($function='supl_prod_return'){
	
		$stock_id = $qc->clean($_REQUEST['stock_id']);
		$sup_id = $qc->clean($_REQUEST['sup_id']);
		$invoice_no = $qc->clean($_REQUEST['invoice_no']);
		$quantity = $qc->clean($_REQUEST['quantity']);
		$sold_quantity = $qc->clean($_REQUEST['sold_quantity']);
		$unit_price = $qc->clean($_REQUEST['sp_amount']); 
	 	$cp_amount = $qc->clean($_REQUEST['cp_amount']);
		
				
	// get infinity_sup_bal_amt_details and update it
	
	$getSupBlnsDetails = $qc->getSupBlnsDetails($sup_id,$invoice_no);
	
	$TA = $getSupBlnsDetails[0][0];
	$PA = $getSupBlnsDetails[0][1];
	$AD = $getSupBlnsDetails[0][2];
	
	if( $AD == 0)
	{
	$newSupGrandTotal = $TA - $cp_amount;
	$newSupPaidAmount = $PA - $cp_amount;
	
	$updatedNTAandNPA = $qc->updateGTandPA($sup_id,$invoice_no,$newSupGrandTotal,$newSupPaidAmount);
	
	} // $AD==0  if end
	
	if($AD > 0 && $cp_amount > $AD )
	{
	$newSupGrandTotal = $TA - $cp_amount;
	$newSupBalAmount = $AD - $cp_amount;
	$newSupPaidAmount = $PA + $newSupBalAmount;
	
	$updateGTandPAandBA = $qc-> updateGTandPAandBA($sup_id,$invoice_no,$newSupGrandTotal,$newSupPaidAmount,$newSupBalAmount);
	} //  $AD > 0 && CP >$AD  if end 
	
	
	if($AD> 0 && $cp_amount < $AD )
	{
	$newSupGrandTotal = $TA - $cp_amount;
	$newSupBalAmount = $AD - $cp_amount;
	
	$updatedNTAandNPA = $qc->updateGTandAD($sup_id,$invoice_no,$newSupGrandTotal,$newSupBalAmount);
	
	}
	 

   $returnSupProduct = $qc->returnSupProduct($stock_id);	
   
   if($returnSupProduct)
   {
		header("Location: stock_add.php?status=return");
	}
	else{
    	header("Location: stock_add.php?status=not_return");
	
	}// if end 
	 
	
	} // function if end
	
	
	?>
