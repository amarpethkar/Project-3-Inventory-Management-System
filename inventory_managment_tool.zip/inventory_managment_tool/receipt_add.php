<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php  
require_once('auth.php');
include_once("classes/query_class.php");
$qc = new queryClass();
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Add Receipt</title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet" />
<link href="css/style.css" type="text/css" rel="stylesheet" />
<link href="css/menu.css" type="text/css" rel="stylesheet" />
<!--calender code-->
<link rel="stylesheet" href="css/jquery-ui.css">
<script src="js/jquery-1.10.2.js"></script>
<script src="js/jquery-ui.js"></script>
<!--calender code end -->
<script src="js/menu_script.js" type="text/javascript"></script>
<?php $receipt_idR = $qc->clean($_REQUEST[receipt_id]);
if($receipt_idR==''){$receipt_idR=0;}
?>
<script type="text/javascript">
var rowCount = 0;
var rowCount1;
function addMoreRows(frm) {

rowCount ++;
rowCount1 = $("#count").val();

var recRow = '<tr id="rowCount'+rowCount+'"><td>\
<input type="text"name="infitycode'+rowCount+'" id="infitycode'+rowCount+'"  onkeyup="return infinityCodeuse('+rowCount+');" placeholder="Code #"/>\
<input type="hidden" id="product'+rowCount+'" name="product'+rowCount+'" />';

recRow +='</td><td><input type="text" id="description'+rowCount+'" name="description'+rowCount+'"  placeholder="description"/></td>\
<td><input type="text" id="quantity'+rowCount+'" name="quantity'+rowCount+'" placeholder="quantity" /></td>\
<td><input id="unit_price'+rowCount+'" type="text" name="unit_price'+rowCount+'" placeholder="Unit Price" readonly /></td>\
<td><input type="text" id="discount'+rowCount+'" name="discount'+rowCount+'" placeholder="Discount"  onkeyUp="calculateDiscountAmount('+rowCount+');"/></td><td><input type="text" name="total'+rowCount+'" id="total'+rowCount+'" placeholder="total" /></td>\
<td><a href="javascript:void(0);" onclick="removeRow('+rowCount+');"><input type="button" style="width: 40px ! important; border: medium none;" value=" X " class="recBtn" /></a></td></tr>\
<tr height="15px;"><td></td></tr>';


jQuery('#addedRows').append(recRow);
rowCount1=rowCount;
$("#count").val(rowCount1+1);

}

function removeRow(removeNum) {
$('#rowCount'+removeNum).remove();
var use = $("#count").val();
var rowCount2 = use-1;
$("#count").val(rowCount2);


var grTotal =0;
var grand_total=0;
var discount = 0;

  for(var i=0; i<=rowCount; i++){

var unit_price = Number($('#unit_price'+i).val());
var discount = Number($('#discount'+i).val());

if(unit_price && discount){

grTotal = (unit_price-discount)

$('#total'+i).val(grTotal);

grand_total= (grand_total+grTotal);

if(grand_total){
$('#grand_total').val(grand_total);
}

  }

}

}

function chooseIcode(){
var receipt_id = <?php echo $receipt_idR; ?>;
if(receipt_id!=''){
var mycout = $('#count').val()-1;
//alert(mycout);

}else{
var mycout = rowCount;
}
//alert(mycout);
for(var i=0; i<=mycout; i++){
var code = $('#i_code'+i).val();

if(code!='')
{
<?php 

$stockInfo = $qc->getStockInfo('','','');
for($i=0;$i<count($stockInfo); $i++){
?>
var newcode = "<?php echo $stockInfo[$i][0];?>";
if(code == newcode){
$('#show_unitprice'+i).val('<?php echo $stockInfo[$i][8];?>');
$('#i_code'+i).css("border-color","black"); 
}
<?php  } ?>
}else{

$('#i_code'+i+'').css("border-color","red");

}

}//this for loop check mycout

}

/*this the calculating of infinity user iteam amount values save totale values*/

function calculateDiscountAmount(key){
var grTotal =0;
var grand_total=0;
var discount = 0;

  for(var i=0; i<=rowCount; i++){

var unit_price = Number($('#unit_price'+i).val());
var discount = Number($('#discount'+i).val());

if(unit_price && discount>=0){

grTotal = (unit_price-discount)

$('#total'+i).val(grTotal);

grand_total= (grand_total+grTotal);

$('#grand_total').val(grand_total);
  }
}

}

$(function() {
$( "#datepicker" ).datepicker();
// $( "#datepicker" ).datepicker("setDate", new Date());

});
function clickhere(){
//alert('jfdg');
$("#add_receiptDetails").addClass("i-hide");
$("#add_newId").html('<div style="width: 40px ! important; border: medium none;line-height: 30px;border-radius: 5px; cursor: pointer;float: right;margin-top: -5px;" onclick="clickhere1();" class="recBtn">+</div>');

}

function clickhere1(){
$("#add_receiptDetails").removeClass("i-hide");
$("#add_newId").html('<div style="width: 40px ! important; border: medium none;line-height: 30px;border-radius: 5px; cursor: pointer; float: right;margin-top: -5px;" onclick="clickhere();" class="recBtn">X</div>');

}
function infinityCodeuse(no) {
var no = no;
//alert(no);
var infitycode = $('#infitycode'+no).val(); 
//alert(infitycode);
var tabaledata=' ';
if(infitycode!=''){
//alert(infitycode);

					          
$.ajax({
	   type: 'POST',
	   url: 'query.php',
	   data: 'function=username_checjinfintycode&infitycode='+infitycode,
	   cache: false,
	   success: function(result) {
		var	response = result;
	
				var json_obj = $.parseJSON(response);//parse JSON  
		
   if(json_obj!=''){
      for (var i in json_obj) 
      {
	$('#description'+no).css('border-color','#DADADA');
$('#quantity'+no).css('border-color','#DADADA');
$('#unit_price'+no).css('border-color','#DADADA');
	
$('#product'+no).val(json_obj[i].stock_id);			
$('#description'+no).val(json_obj[i].description);
$('#quantity'+no).val(json_obj[i].quantity);
$('#unit_price'+no).val(json_obj[i].unit_price);

}
}else{
$('#description'+no).css('border-color','red');
$('#quantity'+no).css('border-color','red');
$('#unit_price'+no).css('border-color','red');

}
		}
	 });
}else{
$('#shoe_rec_inficode').html(tabaledata);
}

}

function calculateBalAmountUser(){
  var totalBal = 0;
var paid_amount = Number($('#paid_amount').val());
var grand_total = Number($('#grand_total').val());
totalBal = (grand_total - paid_amount);
$('#bal_amount').val(totalBal);

}	

function paymodecheque(val){
if(val==3){
$('#cheque_no').show();
}else{

  $('#cheque_no').hide();

}

}
</script>
</head>
<body>
<!-- wrapper start-->
<div class="esya_wrapper">
<!-- main container-->
<div class="container">
<!--herader container -->
<?php include_once('header.php'); ?>
<!--header container end-->
<!--menu container-->
<div class="menu_container">
<?php include_once('menu.php'); ?>
</div>
<!--menu container end-->
<!--middle container -->
<div class="middle_container">
<div class="middle_header">
  <div class="col-md-11" style="position: relative;left: 30px;">Add Receipt</div>
  <div class="col-md-1" id="add_newId">
    <?php  if($receipt_idR==''){
$classes ="i-hide";

?>
    <!--<div style="width: 40px ! important; border: medium none;line-height: 30px; cursor: pointer;border-radius: 5px;float: right;margin-top: -5px;" onclick="clickhere1();" class="recBtn">+</div>-->
    <?php }?>
  </div>
</div>
<div class="receipt_table" id="add_receiptDetails">
  <form name="receipt" method="post" action="query.php">
    <table width="98%" align="center">
      <tr>
        <?php if($receipt_idR!=''){
  $getCustReceiptInfo = $qc->getCustReceiptInfo($receipt_idR);
	$custReceiptInfo = $qc->viewCustReceiptandProdInfo($receipt_idR);
	$couNo = count($custReceiptInfo);
if($getCustReceiptInfo[0][2]!=''){
	$showdate = date('d/m/Y',strtotime($getCustReceiptInfo[0][2]));
}	
				
}else{$couNo = 1;$s=0;$showdate = date("d/m/Y");}?>
        <td>Date:</td>
        <td><input type="text" name="receipt_date" id="datepicker" style="float:left" value="<?php echo $showdate;?>" required/></td>
        <td>Recipient Name:</td>
        <td><input type="text" name="recipient_name" style="float:left" value="<?php echo $getCustReceiptInfo[0][1];?>" required/></td>
        <td>Mobile NO.</td>
        <td><input type="text" name="recipient_cont_no" style="float:left" value="<?php echo $getCustReceiptInfo[0][7];?>" /></td>
      </tr>
      <tr height="15px;">
        <td></td>
      </tr>
      <?php
for($s=0; $s<$couNo;$s++){
if($receipt_idR!=''){
$infinitycode = $qc->getStockInfo($custReceiptInfo[$s][2],'','');
}

 ?>
      <tr>
        <td><input type="text" id="infitycode0" name="infitycode<?php echo $s;?>" style="margin-top: 11px;" onkeyup="return infinityCodeuse(0);" placeholder="Code #" value="<?php echo $infinitycode[0][5];?>"/>
          <div id="infinty_code">
            <input type="hidden" id="product0" name="product<?php echo $s;?>" value="<?php echo $custReceiptInfo[$s][2];?>"/>
          </div></td>
        <td><input type="text" id="description0" name="description<?php echo $s;?>" placeholder="Description" value="<?php echo $custReceiptInfo[$s][3];?>" required/></td>
        <td><input type="text" id="quantity0" name="quantity<?php echo $s;?>" placeholder="Quantity" value="<?php echo $custReceiptInfo[$s][4];?>" required/></td>
        <td><input type="text" id="unit_price0" name="unit_price<?php echo $s;?>" id="show_unitprice<?php echo $s;?>" readonly placeholder="Unit Price" value="<?php echo $custReceiptInfo[$s][5];?>" /></td>
        <td>
        <input type="text" id="discount<?php echo $s;?>" name="discount<?php echo $s;?>" placeholder="Discount" value="<?php echo $custReceiptInfo[$s][6];?>" onkeyUp="calculateDiscountAmount(0);" required/></td>
        <td><input type="text" id="total<?php echo $s;?>" name="total<?php echo $s;?>" placeholder="Total" value="<?php echo $custReceiptInfo[$s][7];?>" required/></td>
        <?php if($receipt_idR!=''){?>
        <input type="hidden" name="product_old<?php echo $s;?>" placeholder="Quantity" value="<?php echo $custReceiptInfo[$s][2];?>"/>
        <input type="hidden" name="old_quantity<?php echo $s;?>" placeholder="Quantity" value="<?php echo $custReceiptInfo[$s][4];?>"/>
        <input type="hidden" id="count" name="prod_id<?php echo $s;?>" value="<?php echo $custReceiptInfo[$s][0];?>" />
        <?php }?>
        <td><?php  if($receipt_idR==''){?>
          <a href="#" onclick="addMoreRows(this.form);">
          <input type="button" name="add_more" value=" + " style="width: 40px ! important; border: medium none;" class="recBtn" />
          </a>
          <?php }?></td>
      </tr>
      <tr height="15px;">
        <td></td>
      </tr>
      <?php } ?>
      <tr>
        <td colspan="8"><table id="addedRows" class="stockAdd_table"  align="center"width="100%">
          </table></td>
      </tr>
      <tr>
        <td colspan="4"></td>
        <td>Grand Total:</td>
      <td><input type="text" name="grand_total" value="<?php echo $getCustReceiptInfo[0][4];?>" id="grand_total" required/></td>
      </tr>
      <tr height="15px;">
            <td></td>
          </tr>
      <tr>
            <td colspan="4"></td>
            <td>Paid Amount:</td>
            <td><input type="text" id="paid_amount" name="paid_amount" value="<?php echo $getCustReceiptInfo[0][5];?>" onKeyUp="calculateBalAmountUser();" required/></td>
          </tr>
          <tr height="15px;">
            <td></td>
          </tr>
          <tr>
            <td colspan="4"></td>
            <td>Balance Amount:</td>
            <td><input type="text" id="bal_amount" name="bal_amount" value="<?php echo $getCustReceiptInfo[0][6];?>" required/></td>
          </tr>
          <tr height="15px;">
            <td></td>
          </tr>
      <tr>
        <td colspan="4"></td>
        <td>Payment Mode:</td>
        <td><ul class="input_ul">
            <li>
              <input type="radio" name="pay_mode" value="cc" onclick="paymodecheque(1);"/>
              CC</li>
            <li>
              <input type="radio" name="pay_mode" value="cash" onclick="paymodecheque(2);"/>
              Cash</li>
            <li>
              <input type="radio" name="pay_mode" value="cheque" onclick="paymodecheque(3);" />
              Cheque</li>
          </ul></td>
      </tr>
      <tr height="15px;">
        <td></td>
      </tr>
      <tr id="cheque_no" style="display: none;">
      <td colspan="4"></td>
       <td>Cheque No:</td>
            <td><input type="text"  name="cheque_no" value=""/></td>
          </tr>
      <tr height="15px;">
        <td></td>
      </tr>
      <tr>
        <td colspan="5"></td>
        <td  style="text-align: center;"><input type="submit" name="add_receipt" value="Submit" style="width: 120px; margin-bottom: 30px; border: medium none;" class="recBtn"/>
          <input type="hidden" id="count" name="count" value="<?php echo $couNo;?>" />
          <input type="hidden" id="count" name="prod_id" value="<?php echo $prod_id;?>" />
          <input type="hidden" id="count" name="receipt_id" value="<?php echo $receipt_idR; ?>" />
          <input type="hidden" name="function" value="add_user_receipt"  /></td>
      </tr>
    </table>
  </form>
</div>
<br />
<br />
<!--middle container end-->
</div>
<!--main container end-->
</div>
</div>
<!--wrapper end-->
</body>
</html>
