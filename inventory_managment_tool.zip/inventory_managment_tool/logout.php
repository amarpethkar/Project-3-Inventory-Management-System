<?php
//Start session
include_once('classes/session_query.php');
$session = new dbSession();
$session->destroy($session_id);
$session->gc($session_id);

//Unset the variables stored in session
unset($_SESSION['SESS_USER_NAME']);
unset($_SESSION['SESS_USER_EMAIL']);
unset($_SESSION['SESS_USER_ID']);
unset($_SESSION['SESS_DATE']);

header("location: index.php?status=4");
exit();
?>
