<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Infinity by Ruchi | Add Stock</title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet" />
<link href="css/style.css" type="text/css" rel="stylesheet" />
<link href="css/menu.css" type="text/css" rel="stylesheet" />
<!--<link href="js/tool.css" type="text/css" rel="stylesheet" />-->
<!--calender code-->
<link rel="stylesheet" href="css/jquery-ui.css">
<script src="js/jquery-1.10.2.js"></script>
<script src="js/jquery-ui.js"></script>
<!--calender code end -->


</head>
<body>
<!-- wrapper start-->
<div class="esya_wrapper">
<!-- main container-->
<div class="container">
<!--herader container -->
<?php include_once('header.php'); ?>
<!--header container end-->
<!--menu container-->
<div class="menu_container">
  <?php include_once('menu.php'); 
  include_once("classes/query_class.php");
  $qc = new queryClass();
  
  
  
  $user_dimand = $qc->getDistinctCustRecInfoForPayments1();
   
  for($i=0; $i<count($user_dimand);$i++){
  $qc->addUserTotalPriceInfo($user_dimand[$i][3],$user_dimand[$i][4],$user_dimand[$i][5],$user_dimand[$i][0],$user_dimand[$i][1],$user_dimand[$i][2],$user_dimand[$i][6],$user_dimand[$i][7]);
   }
  ?>
</div>
<!--menu container end-->
<!--middle container -->
</div></div>
</body>
</html>
