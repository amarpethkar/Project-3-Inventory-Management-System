-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 25, 2016 at 07:22 AM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.5.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `infinity_by_ruchi`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `sr_no` int(11) NOT NULL,
  `name` varchar(500) NOT NULL,
  `username` varchar(500) NOT NULL,
  `password` varchar(500) NOT NULL,
  `added_date` datetime NOT NULL,
  `last_login` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`sr_no`, `name`, `username`, `password`, `added_date`, `last_login`) VALUES
(1, 'Ruchi Seth', 'satish', '12345', '2015-11-18 00:00:00', '2016-03-20 16:15:51');

-- --------------------------------------------------------

--
-- Table structure for table `infinity_customer_info`
--

CREATE TABLE `infinity_customer_info` (
  `cust_id` int(11) NOT NULL,
  `cust_name` varchar(500) NOT NULL,
  `cust_contact` varchar(20) NOT NULL,
  `cust_address` varchar(1000) NOT NULL,
  `tuks_pant` varchar(50) NOT NULL,
  `body_length` varchar(50) NOT NULL,
  `full_length` varchar(50) NOT NULL,
  `chest` varchar(50) NOT NULL,
  `upper_chest` varchar(50) NOT NULL,
  `waist` varchar(50) NOT NULL,
  `hips` varchar(50) NOT NULL,
  `shoulder` varchar(50) NOT NULL,
  `cross_front` varchar(50) NOT NULL,
  `arm_hole` varchar(50) NOT NULL,
  `sleeve` varchar(50) NOT NULL,
  `front_neck` varchar(50) NOT NULL,
  `back_neck` varchar(50) NOT NULL,
  `churidar` varchar(50) NOT NULL,
  `pant` varchar(50) NOT NULL,
  `added_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `infinity_customer_info`
--

INSERT INTO `infinity_customer_info` (`cust_id`, `cust_name`, `cust_contact`, `cust_address`, `tuks_pant`, `body_length`, `full_length`, `chest`, `upper_chest`, `waist`, `hips`, `shoulder`, `cross_front`, `arm_hole`, `sleeve`, `front_neck`, `back_neck`, `churidar`, `pant`, `added_date`) VALUES
(1, 'Emaa Watsan', '8976519293', 'US', 'tusk pant', 'body lenth', 'full lenth', 'chest', 'upper chest', 'waist', 'hips', 'sholder', 'cross front', 'arm hole', 'sleeve', 'front neck', 'back neck', 'chudirar', 'pant', '2016-01-23 16:36:58'),
(2, 'Emaa Watsan 2', '8976519293', 'UK', 'tusk pant', 'body lenth', 'full lenth', 'chest', 'upper chest', 'waist', 'hips', 'sholder', 'cross front', 'arm hole', 'sleeve', 'front neck', 'back neck', 'chudirar', 'pant1', '2016-02-08 14:45:31'),
(3, 'Emaa Watsan 1', '1111111111', 'UK', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', '2016-02-08 14:47:56');

-- --------------------------------------------------------

--
-- Table structure for table `infinity_cust_bal_amt_details`
--

CREATE TABLE `infinity_cust_bal_amt_details` (
  `bal_id` int(11) NOT NULL,
  `receipt_id` int(11) NOT NULL,
  `bal_amount` varchar(100) NOT NULL,
  `paid_amount` varchar(100) NOT NULL,
  `added_date` datetime NOT NULL,
  `installment_date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `infinity_cust_bal_amt_details`
--

INSERT INTO `infinity_cust_bal_amt_details` (`bal_id`, `receipt_id`, `bal_amount`, `paid_amount`, `added_date`, `installment_date`) VALUES
(1, 200, '300', '', '2016-02-04 07:04:35', '1'),
(2, 0, '00', '600', '2016-02-09 14:33:03', '2'),
(4, 4, '00', '200', '2016-02-09 14:53:12', '2016-02-09'),
(5, 5, '00', '600', '2016-02-09 14:56:09', '2016-02-09'),
(6, 6, '00', '500', '2016-02-09 14:58:22', '2016-02-09'),
(7, 7, '00', '400', '2016-02-09 15:00:03', '2016-02-09'),
(8, 8, '00', '100', '2016-02-09 15:03:23', '2016-02-09'),
(9, 0, '00', '100', '2016-02-09 15:07:14', '2016-02-09'),
(10, 0, '00', '100', '2016-02-09 15:08:00', '2016-02-09');

-- --------------------------------------------------------

--
-- Table structure for table `infinity_cust_receipt_info`
--

CREATE TABLE `infinity_cust_receipt_info` (
  `receipt_id` int(11) NOT NULL,
  `name` varchar(500) NOT NULL,
  `receipt_date` varchar(100) NOT NULL,
  `contact_no` varchar(20) NOT NULL,
  `grand_total` varchar(100) NOT NULL,
  `paid_amount` varchar(100) NOT NULL,
  `balance_amount` varchar(100) NOT NULL,
  `added_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `infinity_cust_receipt_info`
--

INSERT INTO `infinity_cust_receipt_info` (`receipt_id`, `name`, `receipt_date`, `contact_no`, `grand_total`, `paid_amount`, `balance_amount`, `added_date`) VALUES
(1, 'Amar Pethar1', '2016-02-04', '7845127845', '200', '200', '000', '2016-02-09 15:36:12'),
(2, 'abc', '1970-01-01', '1234567890', '700', '700', '000', '2016-02-06 17:17:04'),
(4, 'Satish Pethkar', '2016-02-09', '1535545', '200', '200', '00', '2016-02-09 14:53:12'),
(5, 'Satish Pethkar', '2016-02-09', '1234567890', '600', '600', '00', '2016-02-09 14:56:09'),
(6, 'abc2', '2016-02-09', '1234567890', '500', '500', '00', '2016-02-09 14:58:22'),
(7, 'Satish Pethkar', '2016-02-09', '1234567890', '400', '400', '00', '2016-02-09 15:00:03'),
(8, 'Prashant', '2016-02-09', '147852369', '100', '100', '00', '2016-02-09 15:03:23'),
(9, 'Amar Pethar', '2016-02-09', '1535545', '100', '100', '00', '2016-02-09 15:08:12'),
(10, 'Prashant', '2016-02-09', '1535545', '200', '200', '00', '2016-02-09 15:32:45');

-- --------------------------------------------------------

--
-- Table structure for table `infinity_cust_receipt_prod_info`
--

CREATE TABLE `infinity_cust_receipt_prod_info` (
  `prod_id` int(11) NOT NULL,
  `receipt_id` int(11) NOT NULL,
  `prod_code` varchar(100) NOT NULL,
  `prod_discription` varchar(500) NOT NULL,
  `prod_quantity` varchar(50) NOT NULL,
  `prod_unit_price` varchar(50) NOT NULL,
  `prod_discount` varchar(50) NOT NULL,
  `total` varchar(100) NOT NULL,
  `added_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `infinity_cust_receipt_prod_info`
--

INSERT INTO `infinity_cust_receipt_prod_info` (`prod_id`, `receipt_id`, `prod_code`, `prod_discription`, `prod_quantity`, `prod_unit_price`, `prod_discount`, `total`, `added_date`) VALUES
(1, 1, '6', 'test 88', '2', '100', '0', '200', '2016-02-09 15:36:12'),
(2, 2, '2', 'test 2', '1', '500', '100', '400', '2016-02-06 17:17:04'),
(3, 2, '2', 'test 3', '1', '400', '100', '300', '2016-02-05 11:10:44'),
(4, 0, '1', 'test 123', '1', '500', '100', '400', '2016-02-09 15:00:03'),
(5, 0, '5', 'fdf', '1', '100', '0', '100', '2016-02-09 15:03:23'),
(6, 9, '5', 'test 12', '1', '100', '00', '100', '2016-02-09 15:07:14'),
(7, 10, '5', 'test 123', '1', '100', '00', '100', '2016-02-09 15:08:00');

-- --------------------------------------------------------

--
-- Table structure for table `infinity_stock_info`
--

CREATE TABLE `infinity_stock_info` (
  `stock_id` int(11) NOT NULL,
  `sup_id` int(11) NOT NULL,
  `date` varchar(50) NOT NULL,
  `invoice_no` varchar(200) NOT NULL,
  `d_code` varchar(100) NOT NULL,
  `i_code` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL,
  `quantity` varchar(50) NOT NULL,
  `sold_quantity` varchar(100) NOT NULL DEFAULT '0',
  `unit_price` varchar(500) NOT NULL,
  `amount` varchar(500) NOT NULL,
  `added_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `infinity_stock_info`
--

INSERT INTO `infinity_stock_info` (`stock_id`, `sup_id`, `date`, `invoice_no`, `d_code`, `i_code`, `description`, `quantity`, `sold_quantity`, `unit_price`, `amount`, `added_date`) VALUES
(1, 1, '2016-02-01', '010216', 'd-101', 'i-101', 'cunari', '0', '2', '500', '1000', '2016-02-04 06:52:51'),
(2, 1, '2016-02-01', '010216', 'd-102', 'i-102', 'top', '0', '2', '400', '800', '2016-02-04 06:52:51'),
(3, 2, '2016-02-02', '020216', 'd-203', 'i-203', 'anarkali', '-1', '3', '300', '600', '2016-02-04 06:55:37'),
(4, 2, '2016-02-02', '020216', 'd-204', 'i-204', 'panjabi', '0', '2', '200', '400', '2016-02-04 06:55:38'),
(5, 3, '2016-02-03', '030216', 'd-205', 'i-205', 'toptop', '1', '4', '100', '500', '2016-02-04 06:57:26'),
(6, 2, '2016-02-09', 'T11', 'D-02222', 'I-02222', 'new test', '3', '2', '100', '500', '2016-02-09 15:35:43');

-- --------------------------------------------------------

--
-- Table structure for table `infinity_supplier_info`
--

CREATE TABLE `infinity_supplier_info` (
  `sup_id` int(11) NOT NULL,
  `sup_name` varchar(200) NOT NULL,
  `contact_no` varchar(20) NOT NULL,
  `mobile_no` varchar(20) NOT NULL,
  `email_id` varchar(200) NOT NULL,
  `address` varchar(2000) NOT NULL,
  `added_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `infinity_supplier_info`
--

INSERT INTO `infinity_supplier_info` (`sup_id`, `sup_name`, `contact_no`, `mobile_no`, `email_id`, `address`, `added_date`) VALUES
(1, 'Harsh Fabrics', '1234567891', '1234567895', 'harash@gmail.com', 'mumbai', '2016-01-22 17:38:06'),
(2, 'Om Fabrics', '7894561233', '9870533453', 'om@gmail.com', 'pune', '2016-01-22 17:38:37'),
(3, 'Nilam Apparel', '9870533453', '9637993333', 'nilam@gmail.com', 'Latur', '2016-01-22 17:39:28'),
(4, 'Shree Apparel', '9567891231', '735015265', 'shree@gmail.com', 'Dadar', '2016-01-22 17:40:38');

-- --------------------------------------------------------

--
-- Table structure for table `infinity_sup_bal_amt_details`
--

CREATE TABLE `infinity_sup_bal_amt_details` (
  `sup_bal_id` int(11) NOT NULL,
  `sup_id` int(11) NOT NULL,
  `date` varchar(50) NOT NULL,
  `invoice_no` varchar(50) NOT NULL,
  `sup_grand_total` varchar(100) NOT NULL,
  `sup_paid_amount` varchar(100) NOT NULL,
  `sup_bal_amount` varchar(100) NOT NULL,
  `added_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `infinity_sup_bal_amt_details`
--

INSERT INTO `infinity_sup_bal_amt_details` (`sup_bal_id`, `sup_id`, `date`, `invoice_no`, `sup_grand_total`, `sup_paid_amount`, `sup_bal_amount`, `added_date`) VALUES
(1, 1, '2016-02-01', '010216', '1800', '1500', '300', '2016-02-04 06:52:51'),
(2, 2, '2016-02-02', '020216', '1000', '950', '50', '2016-02-04 06:55:37'),
(3, 3, '2016-02-03', '030216', '1000', '600', '400', '2016-02-04 06:57:26'),
(4, 2, '2016-02-09', 'T11', '500', '950', '50', '2016-02-09 15:35:43');

-- --------------------------------------------------------

--
-- Table structure for table `infinity_sup_pay_installment`
--

CREATE TABLE `infinity_sup_pay_installment` (
  `sup_installment_id` int(11) NOT NULL,
  `sup_bal_id` int(11) NOT NULL,
  `installment_date` varchar(50) NOT NULL,
  `sup_new_paid_amt` varchar(50) NOT NULL,
  `added_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `infinity_sup_pay_installment`
--

INSERT INTO `infinity_sup_pay_installment` (`sup_installment_id`, `sup_bal_id`, `installment_date`, `sup_new_paid_amt`, `added_date`) VALUES
(1, 1, '2016-03-03', '500', '2016-03-03 11:48:39'),
(2, 2, '2016-03-03', '200', '2016-03-03 12:08:30'),
(3, 2, '2016-03-03', '200', '2016-03-03 12:08:47'),
(4, 2, '2016-03-03', '50', '2016-03-03 12:09:44');

-- --------------------------------------------------------

--
-- Table structure for table `session_data`
--

CREATE TABLE `session_data` (
  `session_id` varchar(200) NOT NULL,
  `http_user_agent` varchar(200) NOT NULL,
  `session_data` varchar(200) NOT NULL,
  `session_expire` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `session_data`
--

INSERT INTO `session_data` (`session_id`, `http_user_agent`, `session_data`, `session_expire`) VALUES
('rtgu2prb4bm2n01dlpfjsfor02', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:44.0) Gecko/20100101 Firefox/44.0', '1', '1458472191');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`sr_no`);

--
-- Indexes for table `infinity_customer_info`
--
ALTER TABLE `infinity_customer_info`
  ADD PRIMARY KEY (`cust_id`);

--
-- Indexes for table `infinity_cust_bal_amt_details`
--
ALTER TABLE `infinity_cust_bal_amt_details`
  ADD PRIMARY KEY (`bal_id`);

--
-- Indexes for table `infinity_cust_receipt_info`
--
ALTER TABLE `infinity_cust_receipt_info`
  ADD PRIMARY KEY (`receipt_id`);

--
-- Indexes for table `infinity_cust_receipt_prod_info`
--
ALTER TABLE `infinity_cust_receipt_prod_info`
  ADD PRIMARY KEY (`prod_id`);

--
-- Indexes for table `infinity_stock_info`
--
ALTER TABLE `infinity_stock_info`
  ADD PRIMARY KEY (`stock_id`);

--
-- Indexes for table `infinity_supplier_info`
--
ALTER TABLE `infinity_supplier_info`
  ADD PRIMARY KEY (`sup_id`);

--
-- Indexes for table `infinity_sup_bal_amt_details`
--
ALTER TABLE `infinity_sup_bal_amt_details`
  ADD PRIMARY KEY (`sup_bal_id`);

--
-- Indexes for table `infinity_sup_pay_installment`
--
ALTER TABLE `infinity_sup_pay_installment`
  ADD PRIMARY KEY (`sup_installment_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `sr_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `infinity_customer_info`
--
ALTER TABLE `infinity_customer_info`
  MODIFY `cust_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `infinity_cust_bal_amt_details`
--
ALTER TABLE `infinity_cust_bal_amt_details`
  MODIFY `bal_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `infinity_cust_receipt_info`
--
ALTER TABLE `infinity_cust_receipt_info`
  MODIFY `receipt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `infinity_cust_receipt_prod_info`
--
ALTER TABLE `infinity_cust_receipt_prod_info`
  MODIFY `prod_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `infinity_stock_info`
--
ALTER TABLE `infinity_stock_info`
  MODIFY `stock_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `infinity_supplier_info`
--
ALTER TABLE `infinity_supplier_info`
  MODIFY `sup_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `infinity_sup_bal_amt_details`
--
ALTER TABLE `infinity_sup_bal_amt_details`
  MODIFY `sup_bal_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `infinity_sup_pay_installment`
--
ALTER TABLE `infinity_sup_pay_installment`
  MODIFY `sup_installment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
