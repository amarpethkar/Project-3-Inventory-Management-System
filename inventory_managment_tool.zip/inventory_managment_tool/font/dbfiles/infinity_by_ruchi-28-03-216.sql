-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 28, 2016 at 10:52 AM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.5.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `infinity_by_ruchi`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `sr_no` int(11) NOT NULL,
  `name` varchar(500) NOT NULL,
  `username` varchar(500) NOT NULL,
  `password` varchar(500) NOT NULL,
  `added_date` datetime NOT NULL,
  `last_login` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`sr_no`, `name`, `username`, `password`, `added_date`, `last_login`) VALUES
(1, 'Ruchi Seth', 'infinity', '12345', '2015-11-18 00:00:00', '2016-03-28 10:03:55');

-- --------------------------------------------------------

--
-- Table structure for table `infinity_customer_info`
--

CREATE TABLE `infinity_customer_info` (
  `cust_id` int(11) NOT NULL,
  `cust_name` varchar(500) NOT NULL,
  `cust_contact` varchar(20) NOT NULL,
  `cust_address` varchar(1000) NOT NULL,
  `tuks_pant` varchar(50) NOT NULL,
  `body_length` varchar(50) NOT NULL,
  `full_length` varchar(50) NOT NULL,
  `chest` varchar(50) NOT NULL,
  `upper_chest` varchar(50) NOT NULL,
  `waist` varchar(50) NOT NULL,
  `hips` varchar(50) NOT NULL,
  `shoulder` varchar(50) NOT NULL,
  `cross_front` varchar(50) NOT NULL,
  `arm_hole` varchar(50) NOT NULL,
  `sleeve` varchar(50) NOT NULL,
  `front_neck` varchar(50) NOT NULL,
  `back_neck` varchar(50) NOT NULL,
  `churidar` varchar(50) NOT NULL,
  `pant` varchar(50) NOT NULL,
  `added_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `infinity_cust_bal_amt_details`
--

CREATE TABLE `infinity_cust_bal_amt_details` (
  `bal_id` int(11) NOT NULL,
  `receipt_id` int(11) NOT NULL,
  `bal_amount` varchar(100) NOT NULL,
  `paid_amount` varchar(100) NOT NULL,
  `added_date` datetime NOT NULL,
  `installment_date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `infinity_cust_receipt_info`
--

CREATE TABLE `infinity_cust_receipt_info` (
  `receipt_id` int(11) NOT NULL,
  `name` varchar(500) NOT NULL,
  `receipt_date` varchar(100) NOT NULL,
  `contact_no` varchar(20) NOT NULL,
  `grand_total` varchar(100) NOT NULL,
  `paid_amount` varchar(100) NOT NULL,
  `balance_amount` varchar(100) NOT NULL,
  `pay_mode` varchar(5000) NOT NULL,
  `cheque_no` varchar(5000) NOT NULL,
  `added_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `infinity_cust_receipt_info`
--

INSERT INTO `infinity_cust_receipt_info` (`receipt_id`, `name`, `receipt_date`, `contact_no`, `grand_total`, `paid_amount`, `balance_amount`, `pay_mode`, `cheque_no`, `added_date`) VALUES
(7, 'Raj', '2016-03-27', '258522', '3000', '3000', '000', 'cash', '', '2016-03-27 21:59:17'),
(8, 'Raj', '2016-03-27', '626223355', '1500', '1000', '500', 'cash', '', '2016-03-27 22:07:11');

-- --------------------------------------------------------

--
-- Table structure for table `infinity_cust_receipt_prod_info`
--

CREATE TABLE `infinity_cust_receipt_prod_info` (
  `prod_id` int(11) NOT NULL,
  `receipt_id` int(11) NOT NULL,
  `prod_code` varchar(100) NOT NULL,
  `prod_discription` varchar(500) NOT NULL,
  `prod_quantity` varchar(50) NOT NULL,
  `prod_unit_price` varchar(50) NOT NULL,
  `prod_discount` varchar(50) NOT NULL,
  `total` varchar(100) NOT NULL,
  `added_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `infinity_cust_receipt_prod_info`
--

INSERT INTO `infinity_cust_receipt_prod_info` (`prod_id`, `receipt_id`, `prod_code`, `prod_discription`, `prod_quantity`, `prod_unit_price`, `prod_discount`, `total`, `added_date`) VALUES
(1, 3, '1', 'p1', '1', '1100', '0', '1100', '2016-03-23 17:42:53'),
(2, 4, '2', 'P2', '1', '600', '0', '600', '2016-03-23 17:48:16'),
(3, 4, '3', 'P3', '1', '1000', '0', '1000', '2016-03-23 17:48:16'),
(4, 5, '4', 'p4', '1', '1700', '0', '1700', '2016-03-23 17:53:41'),
(6, 7, '6', 'DDDD', '1', '3000', '000', '3000', '2016-03-27 21:59:17'),
(7, 8, '4', 'p4', '1', '1700', '200', '1500', '2016-03-27 22:07:11');

-- --------------------------------------------------------

--
-- Table structure for table `infinity_expenses`
--

CREATE TABLE `infinity_expenses` (
  `exp_id` int(11) NOT NULL,
  `exp_date` varchar(50) NOT NULL,
  `exp_particulars` varchar(2000) NOT NULL,
  `exp_amount` varchar(100) NOT NULL,
  `added_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `infinity_old_stock`
--

CREATE TABLE `infinity_old_stock` (
  `sr_no` int(11) NOT NULL,
  `old_infinity_code` varchar(50) NOT NULL,
  `old_sp_amount` varchar(50) NOT NULL,
  `flag` int(1) NOT NULL DEFAULT '0',
  `added_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `infinity_old_stock`
--

INSERT INTO `infinity_old_stock` (`sr_no`, `old_infinity_code`, `old_sp_amount`, `flag`, `added_date`) VALUES
(1, 'ARS101', '100', 0, '2016-03-19 00:26:51'),
(2, 'ARS102', '100', 0, '2016-03-19 00:27:01'),
(3, 'ARS103', '1365', 0, '2016-03-19 00:32:53'),
(4, 'ARS104', '4520', 0, '2016-03-19 00:33:13'),
(5, '', '', 0, '2016-03-25 15:09:55');

-- --------------------------------------------------------

--
-- Table structure for table `infinity_stock_info`
--

CREATE TABLE `infinity_stock_info` (
  `stock_id` int(11) NOT NULL,
  `sup_id` int(11) NOT NULL,
  `date` varchar(50) NOT NULL,
  `invoice_no` varchar(200) NOT NULL,
  `d_code` varchar(100) NOT NULL,
  `i_code` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL,
  `quantity` varchar(50) NOT NULL,
  `sold_quantity` varchar(100) NOT NULL DEFAULT '0',
  `unit_price_dealer` varchar(50) NOT NULL,
  `unit_price` varchar(500) NOT NULL,
  `amount` varchar(500) NOT NULL,
  `flag` int(1) NOT NULL DEFAULT '0',
  `added_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `infinity_stock_info`
--

INSERT INTO `infinity_stock_info` (`stock_id`, `sup_id`, `date`, `invoice_no`, `d_code`, `i_code`, `description`, `quantity`, `sold_quantity`, `unit_price_dealer`, `unit_price`, `amount`, `flag`, `added_date`) VALUES
(1, 1, '2016-03-23', '123456', 'd1', 'i1', 'p1', '0', '1', '1000', '1100', '', 0, '2016-03-23 16:38:42'),
(2, 1, '2016-03-23', '1', 'd2', 'I2', 'P2', '0', '1', '500', '600', '', 0, '2016-03-23 17:45:42'),
(3, 1, '2016-03-23', '12', 'D3', 'I3', 'P3', '0', '1', '600', '1000', '', 0, '2016-03-23 17:46:42'),
(4, 1, '2016-03-27', '', 'd4', 'i4', 'p4', '0', '1', '1500', '1700', '', 1, '2016-03-23 17:53:10'),
(5, 2, '2016-03-25', 'A10025011', 'A0222', 'I0159753', 'SA', '1', '0', '2000', '3000', '', 0, '2016-03-25 15:09:55'),
(6, 1, '2016-03-26', '550552', 'S121q', 'I021555', 'DDDD', '0', '1', '2000', '3000', '', 0, '2016-03-26 12:32:51'),
(7, 1, '2016-03-26', '550552', 'S121s', 'I021556', 'SSSSS', '1', '0', '5000', '8000', '', 1, '2016-03-26 12:32:51'),
(8, 2, '2016-03-26', 'A666601', 'A02244', 'I0159744', 'AXAX', '1', '0', '100', '200', '', 1, '2016-03-26 15:38:05'),
(9, 2, '2016-03-26', 'A666601', 'S121s44', 'I021545', 'XAXA', '1', '0', '100', '200', '', 1, '2016-03-26 15:38:05'),
(10, 2, '2016-03-26', '55055277', 'A022211', 'I0159744dd', 'AXAXAAA', '1', '0', '1000', '2000', '', 1, '2016-03-26 15:51:04'),
(11, 2, '2016-03-27', '271727', 'S1', 'II1', 'SASA', '1', '0', '5000', '6000', '', 1, '2016-03-27 23:38:50'),
(12, 2, '2016-03-27', '271727', 'S2', 'II2', 'SASAD', '1', '0', '200', '300', '', 1, '2016-03-27 23:38:50');

-- --------------------------------------------------------

--
-- Table structure for table `infinity_supplier_info`
--

CREATE TABLE `infinity_supplier_info` (
  `sup_id` int(11) NOT NULL,
  `sup_name` varchar(200) NOT NULL,
  `contact_no` varchar(20) NOT NULL,
  `mobile_no` varchar(20) NOT NULL,
  `email_id` varchar(200) NOT NULL,
  `address` varchar(2000) NOT NULL,
  `added_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `infinity_supplier_info`
--

INSERT INTO `infinity_supplier_info` (`sup_id`, `sup_name`, `contact_no`, `mobile_no`, `email_id`, `address`, `added_date`) VALUES
(1, 'harash', '8463', '5623', 'har@ghjk', 'mumbai', '2016-03-18 12:26:32'),
(2, 'amar', '020202', '123456789', 'amar@gmail.com', 'kamothe', '2016-03-20 10:43:17');

-- --------------------------------------------------------

--
-- Table structure for table `infinity_sup_bal_amt_details`
--

CREATE TABLE `infinity_sup_bal_amt_details` (
  `sup_bal_id` int(11) NOT NULL,
  `sup_id` int(11) NOT NULL,
  `date` varchar(50) NOT NULL,
  `invoice_no` varchar(50) NOT NULL,
  `sup_grand_total` varchar(100) NOT NULL,
  `sup_paid_amount` varchar(100) NOT NULL,
  `sup_bal_amount` varchar(100) NOT NULL,
  `pay_mode` varchar(5000) NOT NULL,
  `cheque_no` varchar(5000) NOT NULL,
  `added_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `infinity_sup_bal_amt_details`
--

INSERT INTO `infinity_sup_bal_amt_details` (`sup_bal_id`, `sup_id`, `date`, `invoice_no`, `sup_grand_total`, `sup_paid_amount`, `sup_bal_amount`, `pay_mode`, `cheque_no`, `added_date`) VALUES
(1, 1, '2016-03-22', '220316A', '0', '', '', '', '', '2016-03-22 16:01:07'),
(2, 1, '2016-03-23', '123456', '1000', '', '', '', '', '2016-03-23 16:38:42'),
(3, 1, '2016-03-23', '1', '500', '', '', '', '', '2016-03-23 17:45:42'),
(4, 1, '2016-03-23', '12', '600', '', '', '', '', '2016-03-23 17:46:42'),
(5, 1, '2016-03-23', '', '1500', '', '', '', '', '2016-03-23 17:53:09'),
(6, 2, '2016-03-25', 'A10025011', '2000', '', '', '', '', '2016-03-25 15:09:55'),
(7, 1, '2016-03-26', '550552', '7000', '', '', '', '', '2016-03-26 12:32:51'),
(8, 2, '2016-03-26', 'A666601', '200', '', '', '', '', '2016-03-26 15:38:05'),
(9, 2, '2016-03-26', '55055277', '1000', '', '', '', '', '2016-03-26 15:51:04'),
(10, 2, '2016-03-27', '271727', '5200', '4000', '1200', 'cc, cash, cheque', '56465464', '2016-03-27 23:38:50');

-- --------------------------------------------------------

--
-- Table structure for table `infinity_sup_pay_installment`
--

CREATE TABLE `infinity_sup_pay_installment` (
  `sup_installment_id` int(11) NOT NULL,
  `sup_bal_id` int(11) NOT NULL,
  `installment_date` varchar(50) NOT NULL,
  `sup_new_paid_amt` varchar(50) NOT NULL,
  `added_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `infinity_sup_pay_installment`
--

INSERT INTO `infinity_sup_pay_installment` (`sup_installment_id`, `sup_bal_id`, `installment_date`, `sup_new_paid_amt`, `added_date`) VALUES
(1, 10, '2016-03-28', '1000', '2016-03-28 14:02:45');

-- --------------------------------------------------------

--
-- Table structure for table `session_data`
--

CREATE TABLE `session_data` (
  `session_id` varchar(200) NOT NULL,
  `http_user_agent` varchar(200) NOT NULL,
  `session_data` varchar(200) NOT NULL,
  `session_expire` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `session_data`
--

INSERT INTO `session_data` (`session_id`, `http_user_agent`, `session_data`, `session_expire`) VALUES
('i3fqv16a3frtu3pc92ud51bil2', 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0', '1', '1458713460'),
('oq0qqba1p2f51tb171si6strj3', 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0', '1', '1458887895'),
('1mi64e4sq48qsnmuar063519j4', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:44.0) Gecko/20100101 Firefox/44.0', '1', '1458975401'),
('gu4h2losvlp9nitf4qhpbnlk84', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:45.0) Gecko/20100101 Firefox/45.0', '1', '1459058940'),
('6hkg94gp6d8smu28avjjntjvs4', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:45.0) Gecko/20100101 Firefox/45.0', '1', '1459087657'),
('sv3rg0hfi5220skfhmtkrchpm1', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:45.0) Gecko/20100101 Firefox/45.0', '1', '1459095792'),
('qlkrnunmd8sjvsfr0beuk3cd90', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:45.0) Gecko/20100101 Firefox/45.0', '1', '1459141075');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`sr_no`);

--
-- Indexes for table `infinity_customer_info`
--
ALTER TABLE `infinity_customer_info`
  ADD PRIMARY KEY (`cust_id`);

--
-- Indexes for table `infinity_cust_bal_amt_details`
--
ALTER TABLE `infinity_cust_bal_amt_details`
  ADD PRIMARY KEY (`bal_id`);

--
-- Indexes for table `infinity_cust_receipt_info`
--
ALTER TABLE `infinity_cust_receipt_info`
  ADD PRIMARY KEY (`receipt_id`);

--
-- Indexes for table `infinity_cust_receipt_prod_info`
--
ALTER TABLE `infinity_cust_receipt_prod_info`
  ADD PRIMARY KEY (`prod_id`);

--
-- Indexes for table `infinity_expenses`
--
ALTER TABLE `infinity_expenses`
  ADD PRIMARY KEY (`exp_id`);

--
-- Indexes for table `infinity_old_stock`
--
ALTER TABLE `infinity_old_stock`
  ADD PRIMARY KEY (`sr_no`);

--
-- Indexes for table `infinity_stock_info`
--
ALTER TABLE `infinity_stock_info`
  ADD PRIMARY KEY (`stock_id`);

--
-- Indexes for table `infinity_supplier_info`
--
ALTER TABLE `infinity_supplier_info`
  ADD PRIMARY KEY (`sup_id`);

--
-- Indexes for table `infinity_sup_bal_amt_details`
--
ALTER TABLE `infinity_sup_bal_amt_details`
  ADD PRIMARY KEY (`sup_bal_id`);

--
-- Indexes for table `infinity_sup_pay_installment`
--
ALTER TABLE `infinity_sup_pay_installment`
  ADD PRIMARY KEY (`sup_installment_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `sr_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `infinity_customer_info`
--
ALTER TABLE `infinity_customer_info`
  MODIFY `cust_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `infinity_cust_bal_amt_details`
--
ALTER TABLE `infinity_cust_bal_amt_details`
  MODIFY `bal_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `infinity_cust_receipt_info`
--
ALTER TABLE `infinity_cust_receipt_info`
  MODIFY `receipt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `infinity_cust_receipt_prod_info`
--
ALTER TABLE `infinity_cust_receipt_prod_info`
  MODIFY `prod_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `infinity_expenses`
--
ALTER TABLE `infinity_expenses`
  MODIFY `exp_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `infinity_old_stock`
--
ALTER TABLE `infinity_old_stock`
  MODIFY `sr_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `infinity_stock_info`
--
ALTER TABLE `infinity_stock_info`
  MODIFY `stock_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `infinity_supplier_info`
--
ALTER TABLE `infinity_supplier_info`
  MODIFY `sup_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `infinity_sup_bal_amt_details`
--
ALTER TABLE `infinity_sup_bal_amt_details`
  MODIFY `sup_bal_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `infinity_sup_pay_installment`
--
ALTER TABLE `infinity_sup_pay_installment`
  MODIFY `sup_installment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
