-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 25, 2016 at 07:26 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `infinity_by_ruchi`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `sr_no` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(500) NOT NULL,
  `username` varchar(500) NOT NULL,
  `password` varchar(500) NOT NULL,
  `added_date` datetime NOT NULL,
  `last_login` datetime NOT NULL,
  PRIMARY KEY (`sr_no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`sr_no`, `name`, `username`, `password`, `added_date`, `last_login`) VALUES
(1, 'Ruchi Seth', 'infinity', '12345', '2015-11-18 00:00:00', '2016-03-25 11:44:15');

-- --------------------------------------------------------

--
-- Table structure for table `infinity_customer_info`
--

CREATE TABLE IF NOT EXISTS `infinity_customer_info` (
  `cust_id` int(11) NOT NULL AUTO_INCREMENT,
  `cust_name` varchar(500) NOT NULL,
  `cust_contact` varchar(20) NOT NULL,
  `cust_address` varchar(1000) NOT NULL,
  `tuks_pant` varchar(50) NOT NULL,
  `body_length` varchar(50) NOT NULL,
  `full_length` varchar(50) NOT NULL,
  `chest` varchar(50) NOT NULL,
  `upper_chest` varchar(50) NOT NULL,
  `waist` varchar(50) NOT NULL,
  `hips` varchar(50) NOT NULL,
  `shoulder` varchar(50) NOT NULL,
  `cross_front` varchar(50) NOT NULL,
  `arm_hole` varchar(50) NOT NULL,
  `sleeve` varchar(50) NOT NULL,
  `front_neck` varchar(50) NOT NULL,
  `back_neck` varchar(50) NOT NULL,
  `churidar` varchar(50) NOT NULL,
  `pant` varchar(50) NOT NULL,
  `added_date` datetime NOT NULL,
  PRIMARY KEY (`cust_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `infinity_cust_bal_amt_details`
--

CREATE TABLE IF NOT EXISTS `infinity_cust_bal_amt_details` (
  `bal_id` int(11) NOT NULL AUTO_INCREMENT,
  `receipt_id` int(11) NOT NULL,
  `bal_amount` varchar(100) NOT NULL,
  `paid_amount` varchar(100) NOT NULL,
  `added_date` datetime NOT NULL,
  `installment_date` varchar(50) NOT NULL,
  PRIMARY KEY (`bal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `infinity_cust_receipt_info`
--

CREATE TABLE IF NOT EXISTS `infinity_cust_receipt_info` (
  `receipt_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(500) NOT NULL,
  `receipt_date` varchar(100) NOT NULL,
  `contact_no` varchar(20) NOT NULL,
  `grand_total` varchar(100) NOT NULL,
  `paid_amount` varchar(100) NOT NULL,
  `balance_amount` varchar(100) NOT NULL,
  `pay_mode` varchar(100) NOT NULL,
  `added_date` datetime NOT NULL,
  PRIMARY KEY (`receipt_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `infinity_cust_receipt_info`
--

INSERT INTO `infinity_cust_receipt_info` (`receipt_id`, `name`, `receipt_date`, `contact_no`, `grand_total`, `paid_amount`, `balance_amount`, `pay_mode`, `added_date`) VALUES
(1, 'Amar', '2016-03-22', '8976519293', '0', '', '', 'cash', '2016-03-22 16:06:51'),
(2, 'Amar', '2016-03-22', '8976519293', '0', '', '', 'cash', '2016-03-22 16:27:36'),
(3, 'Amar', '2016-03-23', '1234567898', '1100', '', '', '', '2016-03-23 17:42:53'),
(4, 'ashwini', '2016-03-23', '785456123', '1600', '', '', 'cash', '2016-03-23 17:48:16'),
(5, 'ashwini', '2016-03-23', '987456', '1700', '', '', 'cheque', '2016-03-23 17:53:41');

-- --------------------------------------------------------

--
-- Table structure for table `infinity_cust_receipt_prod_info`
--

CREATE TABLE IF NOT EXISTS `infinity_cust_receipt_prod_info` (
  `prod_id` int(11) NOT NULL AUTO_INCREMENT,
  `receipt_id` int(11) NOT NULL,
  `prod_code` varchar(100) NOT NULL,
  `prod_discription` varchar(500) NOT NULL,
  `prod_quantity` varchar(50) NOT NULL,
  `prod_unit_price` varchar(50) NOT NULL,
  `prod_discount` varchar(50) NOT NULL,
  `total` varchar(100) NOT NULL,
  `added_date` datetime NOT NULL,
  PRIMARY KEY (`prod_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `infinity_cust_receipt_prod_info`
--

INSERT INTO `infinity_cust_receipt_prod_info` (`prod_id`, `receipt_id`, `prod_code`, `prod_discription`, `prod_quantity`, `prod_unit_price`, `prod_discount`, `total`, `added_date`) VALUES
(1, 3, '1', 'p1', '1', '1100', '0', '1100', '2016-03-23 17:42:53'),
(2, 4, '2', 'P2', '1', '600', '0', '600', '2016-03-23 17:48:16'),
(3, 4, '3', 'P3', '1', '1000', '0', '1000', '2016-03-23 17:48:16'),
(4, 5, '4', 'p4', '1', '1700', '0', '1700', '2016-03-23 17:53:41');

-- --------------------------------------------------------

--
-- Table structure for table `infinity_expenses`
--

CREATE TABLE IF NOT EXISTS `infinity_expenses` (
  `exp_id` int(11) NOT NULL AUTO_INCREMENT,
  `exp_date` varchar(50) NOT NULL,
  `exp_particulars` varchar(2000) NOT NULL,
  `exp_amount` varchar(100) NOT NULL,
  `added_date` datetime NOT NULL,
  PRIMARY KEY (`exp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `infinity_old_stock`
--

CREATE TABLE IF NOT EXISTS `infinity_old_stock` (
  `sr_no` int(11) NOT NULL AUTO_INCREMENT,
  `old_infinity_code` varchar(50) NOT NULL,
  `old_sp_amount` varchar(50) NOT NULL,
  `flag` int(1) NOT NULL DEFAULT '0',
  `added_date` datetime NOT NULL,
  PRIMARY KEY (`sr_no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `infinity_old_stock`
--

INSERT INTO `infinity_old_stock` (`sr_no`, `old_infinity_code`, `old_sp_amount`, `flag`, `added_date`) VALUES
(1, 'ARS101', '100', 0, '2016-03-19 00:26:51'),
(2, 'ARS102', '100', 0, '2016-03-19 00:27:01'),
(3, 'ARS103', '1365', 0, '2016-03-19 00:32:53'),
(4, 'ARS104', '4520', 0, '2016-03-19 00:33:13');

-- --------------------------------------------------------

--
-- Table structure for table `infinity_stock_info`
--

CREATE TABLE IF NOT EXISTS `infinity_stock_info` (
  `stock_id` int(11) NOT NULL AUTO_INCREMENT,
  `sup_id` int(11) NOT NULL,
  `date` varchar(50) NOT NULL,
  `invoice_no` varchar(200) NOT NULL,
  `d_code` varchar(100) NOT NULL,
  `i_code` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL,
  `quantity` varchar(50) NOT NULL,
  `sold_quantity` varchar(100) NOT NULL DEFAULT '0',
  `unit_price_dealer` varchar(50) NOT NULL,
  `unit_price` varchar(500) NOT NULL,
  `amount` varchar(500) NOT NULL,
  `added_date` datetime NOT NULL,
  PRIMARY KEY (`stock_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `infinity_stock_info`
--

INSERT INTO `infinity_stock_info` (`stock_id`, `sup_id`, `date`, `invoice_no`, `d_code`, `i_code`, `description`, `quantity`, `sold_quantity`, `unit_price_dealer`, `unit_price`, `amount`, `added_date`) VALUES
(1, 1, '2016-03-23', '123456', 'd1', 'i1', 'p1', '0', '1', '1000', '1100', '', '2016-03-23 16:38:42'),
(2, 1, '2016-03-23', '1', 'd2', 'I2', 'P2', '0', '1', '500', '600', '', '2016-03-23 17:45:42'),
(3, 1, '2016-03-23', '12', 'D3', 'I3', 'P3', '0', '1', '600', '1000', '', '2016-03-23 17:46:42'),
(4, 1, '2016-03-23', '113', 'd4', 'i4', 'p4', '0', '1', '1500', '1700', '', '2016-03-23 17:53:10');

-- --------------------------------------------------------

--
-- Table structure for table `infinity_supplier_info`
--

CREATE TABLE IF NOT EXISTS `infinity_supplier_info` (
  `sup_id` int(11) NOT NULL AUTO_INCREMENT,
  `sup_name` varchar(200) NOT NULL,
  `contact_no` varchar(20) NOT NULL,
  `mobile_no` varchar(20) NOT NULL,
  `email_id` varchar(200) NOT NULL,
  `address` varchar(2000) NOT NULL,
  `added_date` datetime NOT NULL,
  PRIMARY KEY (`sup_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `infinity_supplier_info`
--

INSERT INTO `infinity_supplier_info` (`sup_id`, `sup_name`, `contact_no`, `mobile_no`, `email_id`, `address`, `added_date`) VALUES
(1, 'harash', '8463', '5623', 'har@ghjk', 'mumbai', '2016-03-18 12:26:32'),
(2, 'amar', '020202', '123456789', 'amar@gmail.com', 'kamothe', '2016-03-20 10:43:17');

-- --------------------------------------------------------

--
-- Table structure for table `infinity_sup_bal_amt_details`
--

CREATE TABLE IF NOT EXISTS `infinity_sup_bal_amt_details` (
  `sup_bal_id` int(11) NOT NULL AUTO_INCREMENT,
  `sup_id` int(11) NOT NULL,
  `date` varchar(50) NOT NULL,
  `invoice_no` varchar(50) NOT NULL,
  `sup_grand_total` varchar(100) NOT NULL,
  `sup_paid_amount` varchar(100) NOT NULL,
  `sup_bal_amount` varchar(100) NOT NULL,
  `added_date` datetime NOT NULL,
  PRIMARY KEY (`sup_bal_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `infinity_sup_bal_amt_details`
--

INSERT INTO `infinity_sup_bal_amt_details` (`sup_bal_id`, `sup_id`, `date`, `invoice_no`, `sup_grand_total`, `sup_paid_amount`, `sup_bal_amount`, `added_date`) VALUES
(1, 1, '2016-03-22', '220316A', '0', '', '', '2016-03-22 16:01:07'),
(2, 1, '2016-03-23', '123456', '1000', '', '', '2016-03-23 16:38:42'),
(3, 1, '2016-03-23', '1', '500', '', '', '2016-03-23 17:45:42'),
(4, 1, '2016-03-23', '12', '600', '', '', '2016-03-23 17:46:42'),
(5, 1, '2016-03-23', '113', '1500', '', '', '2016-03-23 17:53:09');

-- --------------------------------------------------------

--
-- Table structure for table `infinity_sup_pay_installment`
--

CREATE TABLE IF NOT EXISTS `infinity_sup_pay_installment` (
  `sup_installment_id` int(11) NOT NULL AUTO_INCREMENT,
  `sup_bal_id` int(11) NOT NULL,
  `installment_date` varchar(50) NOT NULL,
  `sup_new_paid_amt` varchar(50) NOT NULL,
  `added_date` datetime NOT NULL,
  PRIMARY KEY (`sup_installment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `session_data`
--

CREATE TABLE IF NOT EXISTS `session_data` (
  `session_id` varchar(200) NOT NULL,
  `http_user_agent` varchar(200) NOT NULL,
  `session_data` varchar(200) NOT NULL,
  `session_expire` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `session_data`
--

INSERT INTO `session_data` (`session_id`, `http_user_agent`, `session_data`, `session_expire`) VALUES
('i3fqv16a3frtu3pc92ud51bil2', 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0', '1', '1458713460'),
('oq0qqba1p2f51tb171si6strj3', 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0', '1', '1458887895');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
