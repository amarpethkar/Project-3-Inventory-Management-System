-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 30, 2016 at 02:40 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `infinity_by_ruchi`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `sr_no` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(500) NOT NULL,
  `username` varchar(500) NOT NULL,
  `password` varchar(500) NOT NULL,
  `added_date` datetime NOT NULL,
  `last_login` datetime NOT NULL,
  PRIMARY KEY (`sr_no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`sr_no`, `name`, `username`, `password`, `added_date`, `last_login`) VALUES
(1, 'Ruchi Seth', 'infinity', '12345', '2015-11-18 00:00:00', '2016-03-29 17:49:35');

-- --------------------------------------------------------

--
-- Table structure for table `infinity_customer_info`
--

CREATE TABLE IF NOT EXISTS `infinity_customer_info` (
  `cust_id` int(11) NOT NULL AUTO_INCREMENT,
  `cust_name` varchar(500) NOT NULL,
  `cust_contact` varchar(20) NOT NULL,
  `cust_address` varchar(1000) NOT NULL,
  `tuks_pant` varchar(50) NOT NULL,
  `body_length` varchar(50) NOT NULL,
  `full_length` varchar(50) NOT NULL,
  `chest` varchar(50) NOT NULL,
  `upper_chest` varchar(50) NOT NULL,
  `waist` varchar(50) NOT NULL,
  `hips` varchar(50) NOT NULL,
  `shoulder` varchar(50) NOT NULL,
  `cross_front` varchar(50) NOT NULL,
  `arm_hole` varchar(50) NOT NULL,
  `sleeve` varchar(50) NOT NULL,
  `front_neck` varchar(50) NOT NULL,
  `back_neck` varchar(50) NOT NULL,
  `churidar` varchar(50) NOT NULL,
  `pant` varchar(50) NOT NULL,
  `added_date` datetime NOT NULL,
  PRIMARY KEY (`cust_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `infinity_cust_bal_amt_details`
--

CREATE TABLE IF NOT EXISTS `infinity_cust_bal_amt_details` (
  `bal_id` int(11) NOT NULL AUTO_INCREMENT,
  `receipt_id` int(11) NOT NULL,
  `bal_amount` varchar(100) NOT NULL,
  `paid_amount` varchar(100) NOT NULL,
  `added_date` datetime NOT NULL,
  `installment_date` varchar(50) NOT NULL,
  PRIMARY KEY (`bal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `infinity_cust_receipt_info`
--

CREATE TABLE IF NOT EXISTS `infinity_cust_receipt_info` (
  `receipt_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(500) NOT NULL,
  `receipt_date` varchar(100) NOT NULL,
  `contact_no` varchar(20) NOT NULL,
  `grand_total` varchar(100) NOT NULL,
  `paid_amount` varchar(100) NOT NULL,
  `balance_amount` varchar(100) NOT NULL,
  `pay_mode` varchar(5000) NOT NULL,
  `cheque_no` varchar(5000) NOT NULL,
  `added_date` datetime NOT NULL,
  PRIMARY KEY (`receipt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `infinity_cust_receipt_prod_info`
--

CREATE TABLE IF NOT EXISTS `infinity_cust_receipt_prod_info` (
  `prod_id` int(11) NOT NULL AUTO_INCREMENT,
  `receipt_id` int(11) NOT NULL,
  `prod_code` varchar(100) NOT NULL,
  `prod_discription` varchar(500) NOT NULL,
  `prod_quantity` varchar(50) NOT NULL,
  `prod_unit_price` varchar(50) NOT NULL,
  `prod_discount` varchar(50) NOT NULL,
  `total` varchar(100) NOT NULL,
  `added_date` datetime NOT NULL,
  PRIMARY KEY (`prod_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `infinity_expenses`
--

CREATE TABLE IF NOT EXISTS `infinity_expenses` (
  `exp_id` int(11) NOT NULL AUTO_INCREMENT,
  `exp_date` varchar(50) NOT NULL,
  `exp_particulars` varchar(2000) NOT NULL,
  `exp_amount` varchar(100) NOT NULL,
  `added_date` datetime NOT NULL,
  PRIMARY KEY (`exp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `infinity_old_stock`
--

CREATE TABLE IF NOT EXISTS `infinity_old_stock` (
  `sr_no` int(11) NOT NULL AUTO_INCREMENT,
  `old_infinity_code` varchar(50) NOT NULL,
  `old_sp_amount` varchar(50) NOT NULL,
  `flag` int(1) NOT NULL DEFAULT '0',
  `added_date` datetime NOT NULL,
  PRIMARY KEY (`sr_no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `infinity_old_stock`
--

INSERT INTO `infinity_old_stock` (`sr_no`, `old_infinity_code`, `old_sp_amount`, `flag`, `added_date`) VALUES
(1, 'ARS100', '1000', 0, '2016-03-29 17:19:45'),
(2, 'ARS101', '450', 0, '2016-03-29 17:26:08');

-- --------------------------------------------------------

--
-- Table structure for table `infinity_stock_info`
--

CREATE TABLE IF NOT EXISTS `infinity_stock_info` (
  `stock_id` int(11) NOT NULL AUTO_INCREMENT,
  `sup_id` int(11) NOT NULL,
  `date` varchar(50) NOT NULL,
  `invoice_no` varchar(200) NOT NULL,
  `d_code` varchar(100) NOT NULL,
  `i_code` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL,
  `quantity` varchar(50) NOT NULL,
  `sold_quantity` varchar(100) NOT NULL DEFAULT '0',
  `unit_price_dealer` varchar(50) NOT NULL,
  `unit_price` varchar(500) NOT NULL,
  `amount` varchar(500) NOT NULL,
  `flag` int(1) NOT NULL DEFAULT '0',
  `added_date` datetime NOT NULL,
  PRIMARY KEY (`stock_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `infinity_stock_info`
--

INSERT INTO `infinity_stock_info` (`stock_id`, `sup_id`, `date`, `invoice_no`, `d_code`, `i_code`, `description`, `quantity`, `sold_quantity`, `unit_price_dealer`, `unit_price`, `amount`, `flag`, `added_date`) VALUES
(3, 1, '2016-03-28', '280316A', 'd3', 'i3', 'des3', '1', '0', '3500', '4500', '', 0, '2016-03-28 15:01:19'),
(4, 1, '2016-03-28', '280316A', 'd4', 'i4', 'des4', '1', '0', '1400', '2000', '', 0, '2016-03-28 15:01:19'),
(5, 1, '2016-03-28', '280316A', 'd5', 'i5', 'des5', '1', '0', '1800', '2500', '', 0, '2016-03-28 15:01:19'),
(7, 1, '2016-03-28', '280316B', 'd7', 'i7', 'des7', '1', '0', '1200', '2000', '', 0, '2016-03-28 15:23:07');

-- --------------------------------------------------------

--
-- Table structure for table `infinity_supplier_info`
--

CREATE TABLE IF NOT EXISTS `infinity_supplier_info` (
  `sup_id` int(11) NOT NULL AUTO_INCREMENT,
  `sup_name` varchar(200) NOT NULL,
  `contact_no` varchar(20) NOT NULL,
  `mobile_no` varchar(20) NOT NULL,
  `email_id` varchar(200) NOT NULL,
  `address` varchar(2000) NOT NULL,
  `added_date` datetime NOT NULL,
  PRIMARY KEY (`sup_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `infinity_supplier_info`
--

INSERT INTO `infinity_supplier_info` (`sup_id`, `sup_name`, `contact_no`, `mobile_no`, `email_id`, `address`, `added_date`) VALUES
(1, 'harash', '02020202', '123456789', 'har@gmail.com', 'mumbai', '2016-03-28 14:54:29'),
(2, 'amar', '020202', '7894561231', 'amar@gmail.com', 'thane', '2016-03-28 14:54:57');

-- --------------------------------------------------------

--
-- Table structure for table `infinity_sup_bal_amt_details`
--

CREATE TABLE IF NOT EXISTS `infinity_sup_bal_amt_details` (
  `sup_bal_id` int(11) NOT NULL AUTO_INCREMENT,
  `sup_id` int(11) NOT NULL,
  `date` varchar(50) NOT NULL,
  `invoice_no` varchar(50) NOT NULL,
  `sup_grand_total` varchar(100) NOT NULL,
  `sup_paid_amount` varchar(100) NOT NULL,
  `sup_bal_amount` varchar(100) NOT NULL,
  `pay_mode` varchar(5000) NOT NULL,
  `cheque_no` varchar(5000) NOT NULL,
  `added_date` datetime NOT NULL,
  PRIMARY KEY (`sup_bal_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `infinity_sup_bal_amt_details`
--

INSERT INTO `infinity_sup_bal_amt_details` (`sup_bal_id`, `sup_id`, `date`, `invoice_no`, `sup_grand_total`, `sup_paid_amount`, `sup_bal_amount`, `pay_mode`, `cheque_no`, `added_date`) VALUES
(1, 1, '2016-03-28', '280316A', '6000', '', '0', 'cheque, cheque, cash, cc, cash', '123, 1234, , , ', '2016-03-28 15:01:18'),
(2, 1, '2016-03-28', '280316B', '1200', '', '0', 'cash, cheque, cash, cash, cc, cash, cash, , cc, cc, cash', '1234, , , , , , , , , ', '2016-03-28 15:23:07'),
(3, 1, '2016-03-28', '280316C', '-800', '', '0', 'cash, cc, cash, cash, , cc, cc, cash, cc', '', '2016-03-28 15:41:43'),
(4, 1, '2016-03-29', '', '1500', '', '500', 'cash', '', '2016-03-29 11:10:25'),
(5, 0, '--', '', '', '', '', '', '', '2016-03-29 17:10:29'),
(6, 0, '--', '', '', '', '', '', '', '2016-03-29 17:19:45');

-- --------------------------------------------------------

--
-- Table structure for table `infinity_sup_pay_installment`
--

CREATE TABLE IF NOT EXISTS `infinity_sup_pay_installment` (
  `sup_installment_id` int(11) NOT NULL AUTO_INCREMENT,
  `sup_bal_id` int(11) NOT NULL,
  `installment_date` varchar(50) NOT NULL,
  `sup_new_paid_amt` varchar(50) NOT NULL,
  `added_date` datetime NOT NULL,
  PRIMARY KEY (`sup_installment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `session_data`
--

CREATE TABLE IF NOT EXISTS `session_data` (
  `session_id` varchar(200) NOT NULL,
  `http_user_agent` varchar(200) NOT NULL,
  `session_data` varchar(200) NOT NULL,
  `session_expire` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `session_data`
--

INSERT INTO `session_data` (`session_id`, `http_user_agent`, `session_data`, `session_expire`) VALUES
('qbdi9scgg0s5l4vjthbetfrs82', 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0', '1', '1459255415');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
