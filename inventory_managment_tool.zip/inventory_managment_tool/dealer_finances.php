<?php
 include_once('auth.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Dealer Details</title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet" />
<link href="css/style.css" type="text/css" rel="stylesheet" />
<link href="css/menu.css" type="text/css" rel="stylesheet" />
<link href="css/pop_up_user_profile.css" type="text/css" rel="stylesheet" />
<!--calender code-->
<link rel="stylesheet" href="css/jquery-ui.css">
<script src="js/jquery-1.10.2.js"></script>
<script src="js/jquery-ui.js"></script>
<!--calender code end -->
<script src="js/menu_script.js" type="text/javascript"></script>
<script type="text/javascript">
$(document).ready(function(){

$('#show_pay1').click(function(e){  
  
      $("#profile_cam").show(); 
      
    });// open  profile img popup
$('#close').click(function(e){  
  
      $("#profile_cam").hide(); 
      
    });// open  profile img popup
	
	$('#show_supPayRecord').click(function(e){  
  
      $("#profile_supl").show(); 
      
    });
	$('#close1').click(function(e){  
  						$("#sup_id").val('');				
						$("#invo_date").val('');
						$("#invo_num").val('');
						$("#invo_total_amt").val('');
						$("#invo_amt_paid").val('');
					    $("#invo_bal_amt").val('');	
      $("#profile_supl").hide(); 
      
    });// open  profile img popup

});

function userIdinfo(userId){

 var userId = userId;
	 
	 $.ajax({
				   type: 'POST',
				   url: 'query.php',
				   data: 'function=pya_user_remAmount_permonth&userId=' + userId,
				   cache: false,
				   success: function(result) {
					var	response = result;
						//alert(response);					
						var values = response.split("##");						
						$("#user_rec_id").val(values[0]);				
						$("#rec_date").val(values[2]);
						$("#rec_num").val(values[0]);
						$("#rec_name").val(values[1]);
						$("#balance_amount").val(values[5]);
						$("#grand_total").val(values[4]);
						$("#paid_amount").val(values[6]);		   
					  
					 
					}
					
				 });
				 
$("#profile_cam").show();
}
/*****************************************************************************************/

function supplierPayInfo(supId,name){

 var supId = supId;
	var userName = name;
	
	$('#supplier_name').val(userName);
	
	 var temp='<option value="">~~Select Invoice~~</option>';
	 $.ajax({
				   type: 'POST',
				   url: 'query.php',
				   data: 'function=pya_supplier_remAmount_permonth&suppId=' + supId,
				   cache: false,
				   success: function(result) {
					var	response = result;
						//alert(response);			   
					var values = response.split("@~@");	
					  for(var i=0; i<values.length-1; i++){
						  
						  var lastval = values[i].split('##');
						  //alert(lastval);
						  temp +='<option value="'+ lastval[0] +'">' + lastval[1] + '</option>';	
					   
					  
					}
					$("#supplier_invoice_code").html(temp);
				   }
				 });
	
	$("#profile_supl").show();
}

	function suppInvoiceValuesSelect(){

 var suppInvoiceId = $('#supplier_invoice_code').val();
	 //alert(suppInvoiceId);
		if(suppInvoiceId!=''){
	
			$('#supplier_invoice_code').css('border-color','#DADADA');
			
	 $.ajax({
				   type: 'POST',
				   url: 'query.php',
				   data: 'function=getvalues_invice&sup_bal_id=' + suppInvoiceId,
				   cache: false,
				   success: function(result) {
					var	response = result;
						//alert(response);					
						var values = response.split("##");						
						$("#sup_id").val(values[0]);				
						$("#invo_date").val(values[2]);
						$("#invo_num").val(values[3]);
						$("#invo_total_amt").val(values[4]);
						$("#invo_amt_paid").val(values[5]);
					    $("#invo_bal_amt").val(values[6]);	
					  
					 
					}
					
				 });
		}else{
						$("#sup_id").val('');				
						$("#invo_date").val('');
						$("#invo_num").val('');
						$("#invo_total_amt").val('');
						$("#invo_amt_paid").val('');
					    $("#invo_bal_amt").val('');	
		$('#supplier_invoice_code').css('border-color','red');
			
		
		}
				 

}

$(function() {
    $( "#datepicker" ).datepicker();
      $( "#datepicker" ).datepicker("setDate", new Date());
	  
	 $( "#datepicker_cust" ).datepicker();
      $( "#datepicker_cust" ).datepicker( "setDate", new Date());
  });
 function paymodecheque(val){
if(val==3){

$('#cheque_no1').show();
}else{

  
  $('#cheque_no1').hide();

}
} 
</script>
<style>
.m-hide {
	display:none;
}
</style>
</head>
<body style="color:#">
<!-- wrapper start-->
<div class="esya_wrapper">
  <!-- main container-->
  <div class="container">
    <!--herader container -->
    <?php include_once('header.php'); ?>
    <!--header container end-->
    <!--menu container-->
    <div class="menu_container">
      <?php include_once('menu.php'); ?>
    </div>
    <!--menu container end-->
    <!--middle container -->
    <div class="middle_container_overview">
   
      <div class="middle_header"><span style="float:left; margin-left:500px">Supplier Personal Account</span></div>
      <div class="view_dealer">
        <table align="center" width="100%" class="ov_table">
          <tr style="background: rgb(241, 241, 241) none repeat scroll 0% 0%;">
          <td width="10px"></td>
            <td><span>Sr. No.</span></td>
            <td><span>Name</span></td>
           <td><span>Available Stock</span></td>
            <td><span>Products Sold</span></td>
            <td><span>Total Amount&nbsp;(&nbsp;<img src="images/rupee.png" width="10"/>&nbsp;)</span></td>
			<td><span>Paid Amount&nbsp;(&nbsp;<img src="images/rupee.png" width="10"/>&nbsp;)</span></td>
            <td><span>Amount Due&nbsp;(&nbsp;<img src="images/rupee.png" width="10"/>&nbsp;)</span></td>
          <td><span>Record Payments</span></td>
          	<td><span></span></td>
          </tr>
          <?php 
		  
		  $supplierInfo = $qc->getSupplierInfo(''); 
		for($s=0, $j=1;$s<count($supplierInfo);$s++, $j++)
		{
		  
  $stockInOutInfo = $qc->stockInOutInfo($supplierInfo[$s][0]);
  $supBalAmtInfo = $qc->supBalAmtInfo($supplierInfo[$s][0]);
   ?>
          <tr class="recordBox">
          <td></td>
            <td><?php echo $j ; ?></td>
            
            <td><?php echo $supplierInfo[$s][1];?> </td>   <!-- invoice no-->
          
            <td><?php echo $stockInOutInfo[0][0];?></td>   <!-- invoice date -->
         
            <td><?php echo $stockInOutInfo[0][1];?></td>   <!--  total product-->
        
            <td><?php echo $supBalAmtInfo[0][0];?></td>    <!--Toatal amount -->
          
			 <td><?php echo $supBalAmtInfo[0][1];?></td> <!--Paid amount -->
            
            <td><?php echo $supBalAmtInfo[0][2];?></td>  <!--Amount Due-->
           
           <td>
		   <?php 
		   if($supBalAmtInfo[0][2]!=='0'){
		   ?>
		   <a onclick=" supplierPayInfo(<?php echo $supplierInfo[$s][0];?>,'<?php echo $supplierInfo[$s][1];?>');"><img src="images/pay.png" style="cursor:pointer;" /></a>
		   <?php } ?>
		   
		   </td>
           
           <td><a href="invoice_view.php?sup_id=<?php echo $supplierInfo[$s][0];?>&name=<?php echo $supplierInfo[$s][1];?>"><img src="images/view.png" /></a></td>
          </tr>
          <?php } ?>
        </table>
      </div>
      <br/>
      <br />
   
    </div>
    <!--middle container end-->
  </div>
  <!--main container end-->
</div>
</div>
<!--wrapper end-->
<!-- popup1 start-->
<div class="c-pro-sp-PopupWrap m-hide" id="profile_cam">
  <div class="c-pro-sp-PopupNew">
    <!-- Header Text -->
    <div class="c-pro-sp-PpTxt">
      <div class="c-pro-sp-form"> <span class="c-pro-sp-closePp">
        <button type="button" class="close" id="close" data-dismiss="modal" aria-hidden="true">×</button>
        </span>
        <div class="c-pro-sp-Info">
          <div id="t-pro-sp-popup-image"  >
            <form name="userpayment" action="query.php" method="post" enctype="multipart/form-data">
              <table>
                <tr>
                  <td width="20%">Date</td>
                  <td width="20%">Receipt No.</td>
                  <td width="30%">Name</td>
                  <td width="20%">Amount Due</td>
                  <td width="20%">New Payment</td>
                </tr>
                <tr>
                  <td><input type="text" name="rec_date" id="datepicker_cust" required/></td>
                  <td><input type="text" name="rec_num" id="rec_num" readonly="readonly"/></td>
                  <td><input type="text" name="rec_name" id="rec_name" readonly="readonly"/></td>
                  <td><input type="text" name="balance_amount" id="balance_amount" readonly="readonly"/></td>
                  <td><input type="text" name="new_pay" required/></td>
                </tr>
                <tr><td height="20"></td></tr>
                <tr>
                  <td colspan="5" style="text-align: center;"><input type="hidden" name="paid_amount" id="paid_amount" />
                    <input type="hidden" name="receipt_id" id="user_rec_id" />
                    <input type="hidden" name="function" value="add_user_new_payment"  />
                    <input type="submit" name="Submit" value="Submit" title="Submit"  class="submit" style="width:200px!important;"/></td>
                </tr>
              </table>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<!--popup1 end-->
<!-- popup Supplier Pament Records start-->
<div class="c-pro-sp-PopupWrap m-hide" id="profile_supl">
  <div class="c-pro-sp-PopupNew">
    <!-- Header Text -->
    <div class="c-pro-sp-PpTxt">
      <div class="c-pro-sp-form"> <span class="c-pro-sp-closePp">
        <button type="button" class="close" id="close1" data-dismiss="modal" aria-hidden="true">×</button>
        </span>
        <div class="c-pro-sp-Info">
          <div id="t-pro-sp-popup-image"  >
            <form name="suplpayment" action="query.php" method="post" enctype="multipart/form-data">
              <table>
                <tr>
                   <!--<td width="25%">Cheque to be issued:</td>
                  <td width="25%"><input type="text" name="supplier_name" id="supplier_name" readonly="readonly" /></td>
                 <td width="15%">Select Inviove:</td>
                   <td width="35%"><select name="supplier_invoice_code" id="supplier_invoice_code" onchange="suppInvoiceValuesSelect();">
					  
                    </select>
                  </td> -->
                </tr>
                <tr><td height="15px;"></td></tr>
                <tr>
                  <td width="27%">Cheque to be issued:</td>
                  <td width="27%">Date</td>
                 <td width="32%">Amount</td>
          
                
            
                
                </tr>
                <tr>
                  <td><input type="text" name="supplier_name" id="supplier_name" readonly="readonly" /><!-- Cheque NO. -->
                    <td><input type="text" name="invo_date" id="datepicker" required/></td> 		<!-- Cheque Date -->
                
                     <td><input type="text" name="invo_new_pay" required/></td> <!-- Cheque Amount -->
                </tr>
                <tr><td colspan="3" height="20"></td></tr>
                <tr>
                <td>Payment Mode:</td><td><ul class="input_ul">
            <li>
              <input name="pay_mode" value="cc" onclick="paymodecheque(1);" type="radio" checked>
              CC</li>
            <li>
              <input name="pay_mode" value="cash" onclick="paymodecheque(2);" type="radio">
              Cash</li>
            <li>
              <input name="pay_mode" value="cheque" onclick="paymodecheque(3);" type="radio">
              Cheque</li>
          </ul></td>
          
          <td id="cheque_no1" style="display: none;">Cheque No: &nbsp;<input name="cheque_no" value=""  type="text"></td>
                </tr>
             
           
                </tr>
                <tr><td height="20px"></td></tr>
                <tr>
                  <td colspan="6" style="text-align: center;"><input type="hidden" name="invo_paid_amt" id="invo_paid_amt" />
                    <input type="hidden" name="sup_id" id="sup_id" />
                    <input type="hidden" name="function" value="add_supl_newpaymentNEW"  />
                    <input type="submit" name="Submit" value="Submit" title="Submit" style="width:200px !important;" class="submit"/></td>
                </tr>
              </table>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<!--popup Supplier Pament Records end-->
</body>
</html>
