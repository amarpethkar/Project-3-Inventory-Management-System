<!--<script src="js/jquery-latest.min.js" type="text/javascript"></script>-->
<script>
        $('.menu-item a').click(function(){
        $(this).addClass('active').siblings().removeClass('active');
        });
</script>

<div class="col-md-10" style="height: 61px ! important;">
  <div id='cssmenu'>
    <ul>
      <li class="menu-item"><a href='overview.php'>Overview</a></li>
      <li class="menu-item"><a href='stock_add.php'>Add Stock</a></li>
       <li class="menu-item"><a href='receipt_add.php'>Add receipt</a></li>
      <li class="menu-item"><a href='#'>Finances</a>
        <ul>
          <li><a href='cust_personal_acc.php'>Customer</a></li>
		  <li><a href='dealer_finances.php'>Dealer</a></li>
        </ul>
      </li>
      <li class="menu-item"><a href='cust_records.php'>Mesurements</a></li>
      </li>
      <li class="menu-item"><a href='supplier_add.php'>Dealer</a></li>
       <li class="menu-item"><a href='petty_cash.php'>Petty Cash</a></li>
       <li class="menu-item"><a href='old_stock_add.php'>Purchases</a></li>
          <li class="menu-item"><a href='old_stock.php'>Old Stock</a></li>

    </ul>
    
       <!--  <ul>
      <li class="menu-item"><a href='overview.php'>Overview</a></li>
      <li class="menu-item"><a href='#'>Add Stock</a></li>
       <li class="menu-item"><a href='#'>Add receipt</a></li>
      <li class="menu-item"><a href='#'>Finances</a>
        <ul>
          <li><a href='#'>Customer</a></li>
		  <li><a href='#'>Dealer</a></li>
        </ul>
      </li>
      <li class="menu-item"><a href='#'>Mesurements</a></li>
      </li>
      <li class="menu-item"><a href='supplier_add.php'>Dealer</a></li>
       <li class="menu-item"><a href='#'>Petty Cash</a></li>
        <li class="menu-item"><a href='old_stock_add.php'>Purchases</a></li>
          <li class="menu-item"><a href='old_stock.php'>Old Stock</a></li>
    </ul> -->
    
    
  </div>
</div>
<div class="col-md-2">
  <ul style="float: right; position: relative; top: 5px;">
    <li style="display: inline; padding: 20px;"><a href="setting.php" ><img src="images/gear74.png" /></a></li>
    <li style="display:inline"><a href="logout.php" style="position: relative; top: 7px; color: rgb(255, 255, 255) ! important;"><i class="fh icon-power-off" style="font-size:24px;"></i></a></li>
  </ul>
</div>
