<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Index.php</title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet" />
<link href="css/style.css" type="text/css" rel="stylesheet" />
<link href="css/font-awesome.css" type="text/css" rel="stylesheet"  />
<link href="css/font-awesome.min.css" type="text/css" rel="stylesheet"  />
</head>

<body style="background-color: rgb(64, 64, 64);">
<!-- wrapper start-->
<div class="esya_wrapper">
<!-- main container-->
<div class="container">
<!--login container-->
<div class="logIn_container">
<form name="login" method="post" action="check_login.php">
<div class="logIn_wrapper">
<div class="col-md-12"><img src="images/logo.png" width="350" /></div>
<div class="logIn_fileds col-md-12"><div class="i_user"><i class="fa icon-user user_icon"></i>
	<input type="text" name="username" placeholder="Username" style="margin-left: -20px ! important; width: 301px ! important;"/></div></div>
<div class="logIn_fileds col-md-12"><div class="i_user"><i class="fa icon-key user_icon"></i>
	<input type="password" name="password" placeholder="Password" style="margin-left: -20px ! important; width: 301px ! important;"/></div></div>
<div class="col-md-12"><input type="submit" name="login" value="Log In" class="loginBtn"/></div>
<table style="color:#FFFFFF; width:90%; margin:0px auto;">
<tr><td height="20px"></td></tr>
<?php
include("message.php");
?>
</table>
</div>
</div>
<!--login container end-->
</form>
<!-- <div class="col-md-12" style="text-align:center; color:#FFFFFF"><span><i>Powered by</i></span><span> <b>eSya Innovations</b></span></div>-->
</div>
<!--container end-->
</div>
<!--wrapper end-->
</body>
</html>
