<div class="header_container" class="col-md-12"  align="center">

  <div class="col-md-12"><img src="images/logo.png"  height="78px" /></div>
 <!-- <div class="col-md-8"><span style="position: relative; top: 27px; float: right;"><a href="setting.php"><img src="images/gear74.png" /></a>&nbsp;&nbsp;<a href="logout.php"><img src="images/electricity2.png" /></a></span></div>-->
</div>
<link href="css/font-awesome.css"  type="text/css" rel="stylesheet"/>