<?php
 include_once('auth.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title> Add Dealer/Supplier</title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet" />
<link href="css/style.css" type="text/css" rel="stylesheet" />
<link href="css/menu.css" type="text/css" rel="stylesheet" />
<link href="css/font-awesome.css" type="text/css" rel="stylesheet" />
<script src="js/menu_script.js" type="text/javascript"></script>
<script src="js/jquery-1.9.1.min.js" type="text/javascript"></script>
</head>
<body>
<!-- wrapper start-->
<div class="esya_wrapper">
  <!-- main container-->
  <div class="container">
    <!--herader container -->
    <?php include_once('header.php'); ?>
    <!--header container end-->
    <!--menu container-->
    <div class="menu_container">
      <?php include_once('menu.php'); ?>
    </div>
    <!--menu container end-->
    <!--middle container -->
    <div class="middle_container">
      <div class="middle_header"><span style="position: relative; right: 517px;">Add Supplier</span></div>
      <div class="add_dealer">
        <form name="add_supplier" method="post" action="query.php">
          <table align="center" width="98%" class="add_dealer_table">
            <?php
include_once("message.php");
$sup_idDB = $qc->clean($_REQUEST['sup_id']);
if($sup_idDB!=''){
$supplierDetails = $qc->getSupplierInfo($sup_idDB);
}

?>
            <tr>
              <td class="add_inputBox"><input type="text" name="name" value="<?php echo $supplierDetails[0][1]; ?>" placeholder="Name" required/></td>
              <td class="add_inputBox"><input type="text" name="address" value="<?php echo $supplierDetails[0][4]; ?>" placeholder="Address" /></td>
              <td class="add_inputBox"><input type="text" name="contact_no" value="<?php echo $supplierDetails[0][2]; ?>" placeholder="Phone No."/></td>
              <td class="add_inputBox"><input type="text" name="mobile_no" value="<?php echo $supplierDetails[0][5]; ?>" placeholder="Mobile No."/></td>
              <td class="add_inputBox"><input type="email" name="email_id" value="<?php echo $supplierDetails[0][3]; ?>" placeholder="Email Id"/></td>
              <td colspan="3"><input type="hidden" name="function" value="add_supplier" />
                <?php if($sup_idDB!=''){?>
                <input type="submit" class="input_Btn recBtn" name="" value="Save"  />
                <?php }else {?>
                <input type="submit" class="input_Btn recBtn" name="" style="border: medium none;" value="Submit"  />
                <?php } ?>
                <input type="hidden" name="sup_idDB" value="<?php echo $sup_idDB; ?>" />
              </td>
            </tr>
          </table>
        </form>
      </div>
      <!-- Add Dealer end-->
      <br />
      <div class="middle_header">
        <div class="col-md-7"><span style="position: relative;left: 184px;">View Supplier</span></div>
        <form name="stock_search" method="post" action="supplier_add.php">
          <div class="col-md-5"><span style="position: relative;  top: -7px;">Search by:&nbsp;
            <input type="text" name="search" style="width: 200px ! important; color: rgb(89, 86, 84) ! important; font-size: 12px;" placeholder="Enter name here" />
            <input type="submit" name="" value="" class="myBtn btn" />
            <input type="hidden" name="function" value="add_stock" />
            </span></div>
        </form>
      </div>
      <div class="view_dealer">
        <table align="center" width="100%" class="ov_table">
          <tr style="background: rgb(241, 241, 241) none repeat scroll 0% 0%;">
            <td width="10px"></td>
            <td><span>Sr. No.</span></td>
            <td><span>Name</span></td>
            <td><span>Amount Due</span></td>
            <td><span>Address</span></td>
            <td><span> Phone No.</span></td>
            <td><span>Mobile No.</span></td>
            <td><span> Email</span></td>
            <td><span></span></td>
            <td><span>
              <?php
$search =  $qc->clean($_REQUEST['search']);if($search !=''){?>
              <a href="supplier_add.php">
              <div class="fa icon-remove remove-sup"></div>
              </a>
              <?php }?>
              </span></td>
          </tr>
          <?php

if($search!=''){
$supplierDetails = $qc->getSupplierByNameInfo($search);
}else{
		$supplierDetails = $qc->getSupplierInfo('');
}
for($i=0,$j=1;$i<count($supplierDetails);$i++,$j++){
  $supBalAmtInfo = $qc->supBalAmtInfo($supplierInfo[$s][0]);
$supBalAmtInfo = $qc->supBalAmtInfo($supplierDetails[$i][0]);
		?>
          <tr class="recordBox">
            <td></td>
            <td><?php echo $j; ?></td>
            <td><?php echo $supplierDetails[$i][1];?></td>
            <td><?php echo $supBalAmtInfo[0][1];?></td>
            <td><?php echo $supplierDetails[$i][4];?></td>
            <td><?php echo $supplierDetails[$i][2];?></td>
            <td><?php echo $supplierDetails[$i][5];?></td>
            <td><?php echo $supplierDetails[$i][3];?></td>
            <td><a href="supplier_add.php?sup_id=<?php echo $supplierDetails[$i][0];?>"><img src="images/edit.png" /></a></td>
            <td><a href="query.php?function=delete_supplier_info&sup_id=<?php echo $supplierDetails[$i][0];?>"onclick="return confirm('Are you sure you want to Delete?')"><img src="images/delete.png" /></a></td>
            <td><span></span></td>
          </tr>
          <?php }?>
        </table>
      </div>
    </div>
    <!--middle container end-->
  </div>
  <!--main container end-->
</div>
</div>
<!--wrapper end-->
</body>
</html>
